from __future__ import annotations

import hmac
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from services.paper.models import CandidateTrade
from services.persistence.repository import (
    PaperCandidateRecord,
    PostgresPaperRepository,
    StoredMarketSnapshot,
)

ROOT = Path(__file__).resolve().parents[2]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
LIVE_EXECUTION_ENABLED = False


class MarketSnapshotIn(BaseModel):
    instrument_id: str = Field(min_length=1, max_length=128)
    market_code: str = Field(min_length=1, max_length=32)
    source_key: str = Field(min_length=1, max_length=128)
    reference_price: float = Field(gt=0)
    available_liquidity_notional: float = Field(ge=0)
    data_timestamp: datetime

    @field_validator("data_timestamp")
    @classmethod
    def require_tz(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("data_timestamp must be timezone-aware")
        return value


class CandidateIn(BaseModel):
    strategy_key: str = Field(min_length=1, max_length=128)
    candidate: dict[str, Any]


def _repo_from_env() -> PostgresPaperRepository:
    dsn = os.getenv("DATABASE_URL")
    if not dsn:
        raise RuntimeError("DATABASE_URL is required")
    return PostgresPaperRepository(dsn)


def create_app(repository=None, owner_token: str | None = None) -> FastAPI:
    repo = repository or _repo_from_env()
    expected_token = owner_token if owner_token is not None else os.getenv("OWNER_API_TOKEN", "")
    app = FastAPI(title="Global Market Command Centre", version=VERSION)

    def require_owner(authorization: str | None = Header(default=None)) -> None:
        if not expected_token:
            raise HTTPException(status_code=503, detail="OWNER_API_TOKEN is not configured")
        prefix = "Bearer "
        if not authorization or not authorization.startswith(prefix):
            raise HTTPException(status_code=401, detail="Bearer token required")
        supplied = authorization[len(prefix):]
        if not hmac.compare_digest(supplied, expected_token):
            raise HTTPException(status_code=403, detail="Invalid owner token")

    @app.get("/healthz")
    def healthz() -> dict[str, Any]:
        return {
            "status": "ok",
            "version": VERSION,
            "mode": "PAPER_VALIDATION",
            "live_execution_enabled": False,
        }

    @app.get("/readyz")
    def readyz() -> dict[str, Any]:
        try:
            repo.ping()
            return {"status": "ready", "database": "ok", "live_execution_enabled": False}
        except Exception as exc:
            raise HTTPException(status_code=503, detail=f"database_not_ready:{type(exc).__name__}") from exc

    @app.get("/api/v1/dashboard", dependencies=[Depends(require_owner)])
    def dashboard(service_key: str = "paper-validation-worker") -> dict[str, Any]:
        heartbeat = repo.get_worker_heartbeat(service_key)
        checkpoint = repo.load_runtime_checkpoint(service_key)
        reports = repo.recent_daily_reports(service_key=service_key, limit=8)
        candidates = repo.list_paper_candidates(limit=25)
        settlements = repo.list_prediction_settlements(limit=25)
        events = repo.recent_worker_events(service_key=service_key, limit=25)
        snapshots = repo.recent_market_snapshots(limit=30)
        return {
            "version": VERSION,
            "mode": "PAPER_VALIDATION",
            "live_execution_enabled": False,
            "heartbeat": None if heartbeat is None else {
                "service_key": heartbeat.service_key,
                "status": heartbeat.status,
                "heartbeat_at": heartbeat.heartbeat_at.isoformat(),
                "details": heartbeat.details,
            },
            "checkpoint": None if checkpoint is None else {
                "updated_at": checkpoint.updated_at.isoformat(),
                "portfolio": checkpoint.payload.get("portfolio", {}),
                "risk_day_date": checkpoint.payload.get("risk_day_date"),
            },
            "reports": reports,
            "candidates": candidates,
            "settlements": settlements,
            "events": events,
            "market_snapshots": snapshots,
        }

    @app.get("/api/v1/market-snapshots", dependencies=[Depends(require_owner)])
    def list_market_snapshots(limit: int = Query(50, ge=1, le=500)) -> list[dict[str, Any]]:
        return repo.recent_market_snapshots(limit=limit)

    @app.post("/api/v1/market-snapshots", dependencies=[Depends(require_owner)])
    def ingest_market_snapshot(payload: MarketSnapshotIn) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        snapshot = StoredMarketSnapshot(
            instrument_id=payload.instrument_id,
            market_code=payload.market_code,
            source_key=payload.source_key,
            reference_price=payload.reference_price,
            available_liquidity_notional=payload.available_liquidity_notional,
            data_timestamp=payload.data_timestamp,
            received_at=now,
        )
        repo.save_market_snapshot(snapshot)
        return {"status": "accepted", "received_at": now.isoformat(), "live_execution_enabled": False}

    @app.get("/api/v1/candidates", dependencies=[Depends(require_owner)])
    def list_candidates(status: str | None = None, limit: int = Query(100, ge=1, le=500)) -> list[dict[str, Any]]:
        return repo.list_paper_candidates(status=status, limit=limit)

    @app.post("/api/v1/candidates", dependencies=[Depends(require_owner)])
    def ingest_candidate(payload: CandidateIn) -> dict[str, Any]:
        # Strong validation by constructing the exact paper-worker dataclass.
        candidate = CandidateTrade(**payload.candidate)
        if candidate.direction.upper() != "LONG":
            raise HTTPException(status_code=422, detail="Phase 1.1 accepts LONG paper candidates only")
        record = PaperCandidateRecord(
            candidate_key=candidate.candidate_id,
            candidate_payload=payload.candidate,
            strategy_key=payload.strategy_key,
            created_at=datetime.now(timezone.utc),
        )
        repo.add_paper_candidate(record)
        return {"status": "queued_for_paper_worker", "candidate_key": candidate.candidate_id, "live_execution_enabled": False}

    @app.get("/api/v1/reports", dependencies=[Depends(require_owner)])
    def reports(market: str | None = None, limit: int = Query(30, ge=1, le=365)) -> list[dict[str, Any]]:
        return repo.recent_daily_reports(service_key="paper-validation-worker", market_code=market, limit=limit)

    @app.get("/api/v1/worker-events", dependencies=[Depends(require_owner)])
    def worker_events(limit: int = Query(100, ge=1, le=500)) -> list[dict[str, Any]]:
        return repo.recent_worker_events(service_key="paper-validation-worker", limit=limit)

    @app.get("/api/v1/settlements", dependencies=[Depends(require_owner)])
    def settlements(status: str | None = None, limit: int = Query(100, ge=1, le=500)) -> list[dict[str, Any]]:
        return repo.list_prediction_settlements(status=status, limit=limit)

    web_dir = ROOT / "apps" / "web"
    app.mount("/assets", StaticFiles(directory=web_dir), name="assets")

    @app.get("/")
    def index(request: Request):
        return FileResponse(web_dir / "index.html")

    return app

