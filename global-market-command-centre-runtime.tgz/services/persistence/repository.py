from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class StoredMarketSnapshot:
    instrument_id: str
    market_code: str
    source_key: str
    reference_price: float
    available_liquidity_notional: float
    data_timestamp: datetime
    received_at: datetime


@dataclass(frozen=True)
class PredictionSettlementRecord:
    prediction_id: str
    instrument_id: str
    market_code: str
    direction: str
    confidence: float
    expected_net_return: float
    horizon: str
    baseline_price: float
    due_at: datetime
    traded: bool = False
    realized_trade_pnl: float | None = None
    status: str = "PENDING"


@dataclass(frozen=True)
class RuntimeCheckpoint:
    service_key: str
    payload: dict[str, Any]
    updated_at: datetime


@dataclass(frozen=True)
class WorkerHeartbeat:
    service_key: str
    status: str
    heartbeat_at: datetime
    details: dict[str, Any]


@dataclass(frozen=True)
class PaperCandidateRecord:
    candidate_key: str
    candidate_payload: dict[str, Any]
    strategy_key: str
    created_at: datetime
    status: str = "PENDING"
    status_reason: str = "awaiting_worker_import"


class InMemoryPaperRepository:
    """Reference repository used by tests and local paper validation.

    It deliberately mirrors the persistence contract used by PostgreSQL without
    creating any live trading or broker dependency.
    """

    def __init__(self) -> None:
        self.scheduler_states: dict[str, dict[str, Any]] = {}
        self.runtime_checkpoints: dict[str, RuntimeCheckpoint] = {}
        self.market_snapshots: dict[str, list[StoredMarketSnapshot]] = {}
        self.prediction_settlements: dict[str, PredictionSettlementRecord] = {}
        self.settlement_results: dict[str, dict[str, Any]] = {}
        self.heartbeats: dict[str, WorkerHeartbeat] = {}
        self.worker_events: list[dict[str, Any]] = []
        self.daily_reports: list[dict[str, Any]] = []
        self.paper_candidates: dict[str, PaperCandidateRecord] = {}

    def load_scheduler_state(self, scheduler_key: str) -> dict[str, Any] | None:
        value = self.scheduler_states.get(scheduler_key)
        return None if value is None else json.loads(json.dumps(value))

    def save_scheduler_state(self, scheduler_key: str, state_payload: dict[str, Any], updated_at: datetime | None = None) -> None:
        self.scheduler_states[scheduler_key] = json.loads(json.dumps(state_payload))

    def save_runtime_checkpoint(self, service_key: str, payload: dict[str, Any], updated_at: datetime | None = None) -> None:
        ts = updated_at or datetime.now(timezone.utc)
        self.runtime_checkpoints[service_key] = RuntimeCheckpoint(service_key, json.loads(json.dumps(payload)), ts)

    def load_runtime_checkpoint(self, service_key: str) -> RuntimeCheckpoint | None:
        row = self.runtime_checkpoints.get(service_key)
        if row is None:
            return None
        return RuntimeCheckpoint(row.service_key, json.loads(json.dumps(row.payload)), row.updated_at)

    def save_market_snapshot(self, snapshot: StoredMarketSnapshot) -> None:
        rows = self.market_snapshots.setdefault(snapshot.instrument_id, [])
        rows.append(snapshot)
        rows.sort(key=lambda x: (x.data_timestamp, x.received_at))

    def latest_market_snapshot(self, instrument_id: str) -> StoredMarketSnapshot | None:
        rows = self.market_snapshots.get(instrument_id, [])
        return rows[-1] if rows else None

    def add_prediction_settlement(self, record: PredictionSettlementRecord) -> None:
        self.prediction_settlements.setdefault(record.prediction_id, record)

    def due_prediction_settlements(self, now: datetime) -> tuple[PredictionSettlementRecord, ...]:
        return tuple(sorted(
            (r for r in self.prediction_settlements.values() if r.status == "PENDING" and r.due_at <= now),
            key=lambda r: (r.due_at, r.prediction_id),
        ))

    def mark_prediction_settled(self, prediction_id: str, result: dict[str, Any]) -> None:
        current = self.prediction_settlements[prediction_id]
        self.prediction_settlements[prediction_id] = PredictionSettlementRecord(**{
            **asdict(current),
            "status": "SETTLED",
        })
        self.settlement_results[prediction_id] = json.loads(json.dumps(result, default=str))

    def update_prediction_trade_result(self, prediction_id: str, traded: bool = True, realized_trade_pnl: float | None = None) -> None:
        current = self.prediction_settlements.get(prediction_id)
        if current is None:
            return
        self.prediction_settlements[prediction_id] = PredictionSettlementRecord(**{
            **asdict(current),
            "traded": traded,
            "realized_trade_pnl": current.realized_trade_pnl if realized_trade_pnl is None else realized_trade_pnl,
        })

    def save_worker_heartbeat(self, heartbeat: WorkerHeartbeat) -> None:
        self.heartbeats[heartbeat.service_key] = heartbeat

    def save_worker_event(self, event: dict[str, Any]) -> None:
        self.worker_events.append(json.loads(json.dumps(event, default=str)))

    def save_daily_report(self, report: dict[str, Any]) -> None:
        self.daily_reports.append(json.loads(json.dumps(report, default=str)))

    def add_paper_candidate(self, record: PaperCandidateRecord) -> None:
        self.paper_candidates.setdefault(record.candidate_key, record)

    def pending_paper_candidates(self, limit: int = 100) -> tuple[PaperCandidateRecord, ...]:
        rows = [x for x in self.paper_candidates.values() if x.status == "PENDING"]
        return tuple(sorted(rows, key=lambda x: (x.created_at, x.candidate_key))[:limit])

    def mark_paper_candidate(self, candidate_key: str, status: str, reason: str) -> None:
        current = self.paper_candidates[candidate_key]
        self.paper_candidates[candidate_key] = PaperCandidateRecord(
            candidate_key=current.candidate_key, candidate_payload=current.candidate_payload,
            strategy_key=current.strategy_key, created_at=current.created_at, status=status, status_reason=reason,
        )

    def ping(self) -> bool:
        return True

    def get_worker_heartbeat(self, service_key: str) -> WorkerHeartbeat | None:
        return self.heartbeats.get(service_key)

    def recent_worker_events(self, service_key: str, limit: int = 100) -> list[dict[str, Any]]:
        rows = [x for x in self.worker_events if x.get("service_key") == service_key]
        return list(reversed(rows[-limit:]))

    def recent_daily_reports(self, service_key: str, market_code: str | None = None, limit: int = 30) -> list[dict[str, Any]]:
        rows = [x for x in self.daily_reports if x.get("service_key") == service_key]
        if market_code is not None:
            rows = [x for x in rows if x.get("market") == market_code]
        return list(reversed(rows[-limit:]))

    def recent_market_snapshots(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = [x for values in self.market_snapshots.values() for x in values]
        rows.sort(key=lambda x: (x.data_timestamp, x.received_at), reverse=True)
        return [{
            "instrument_id": x.instrument_id, "market_code": x.market_code, "source_key": x.source_key,
            "reference_price": x.reference_price, "available_liquidity_notional": x.available_liquidity_notional,
            "data_timestamp": x.data_timestamp.isoformat(), "received_at": x.received_at.isoformat(),
        } for x in rows[:limit]]

    def list_paper_candidates(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = list(self.paper_candidates.values())
        if status is not None:
            rows = [x for x in rows if x.status == status]
        rows.sort(key=lambda x: (x.created_at, x.candidate_key), reverse=True)
        return [{
            "candidate_key": x.candidate_key, "strategy_key": x.strategy_key, "created_at": x.created_at.isoformat(),
            "status": x.status, "status_reason": x.status_reason, "candidate": x.candidate_payload,
        } for x in rows[:limit]]

    def list_prediction_settlements(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = list(self.prediction_settlements.values())
        if status is not None:
            rows = [x for x in rows if x.status == status]
        rows.sort(key=lambda x: (x.due_at, x.prediction_id), reverse=True)
        return [{
            "prediction_id": x.prediction_id, "instrument_id": x.instrument_id, "market_code": x.market_code,
            "direction": x.direction, "confidence": x.confidence, "expected_net_return": x.expected_net_return,
            "horizon": x.horizon, "baseline_price": x.baseline_price, "due_at": x.due_at.isoformat(),
            "traded": x.traded, "realized_trade_pnl": x.realized_trade_pnl, "status": x.status,
        } for x in rows[:limit]]


class PostgresPaperRepository:
    """Minimal DB-API repository for the online paper-validation service.

    `connect` may be injected for tests. If omitted, psycopg is imported lazily.
    No broker or order-routing functionality is present here.
    """

    def __init__(self, dsn: str, connect: Callable[[str], Any] | None = None):
        self.dsn = dsn
        self._connect = connect

    def _connection(self):
        if self._connect is not None:
            return self._connect(self.dsn)
        try:
            import psycopg  # type: ignore
        except ImportError as exc:  # pragma: no cover - environment dependent
            raise RuntimeError("psycopg is required for PostgreSQL runtime persistence") from exc
        return psycopg.connect(self.dsn)

    @staticmethod
    def _column_names(description) -> list[str]:
        names = []
        for item in description:
            name = getattr(item, "name", None)
            names.append(name if name is not None else item[0])
        return names

    @classmethod
    def _fetchone_dict(cls, cursor) -> dict[str, Any] | None:
        row = cursor.fetchone()
        if row is None:
            return None
        if isinstance(row, dict):
            return row
        return dict(zip(cls._column_names(cursor.description), row))

    def load_scheduler_state(self, scheduler_key: str) -> dict[str, Any] | None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT state_payload FROM paper_scheduler_state WHERE scheduler_key = %s",
                (scheduler_key,),
            )
            row = self._fetchone_dict(cur)
            return None if row is None else row["state_payload"]

    def save_scheduler_state(self, scheduler_key: str, state_payload: dict[str, Any], updated_at: datetime | None = None) -> None:
        ts = updated_at or datetime.now(timezone.utc)
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_scheduler_state(scheduler_key, state_version, state_payload, updated_at, live_execution_enabled)
                VALUES (%s, 1, %s::jsonb, %s, FALSE)
                ON CONFLICT (scheduler_key) DO UPDATE
                SET state_payload = EXCLUDED.state_payload, updated_at = EXCLUDED.updated_at, live_execution_enabled = FALSE
                """,
                (scheduler_key, json.dumps(state_payload), ts),
            )

    def save_runtime_checkpoint(self, service_key: str, payload: dict[str, Any], updated_at: datetime | None = None) -> None:
        ts = updated_at or datetime.now(timezone.utc)
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_runtime_checkpoints(service_key, checkpoint_payload, updated_at, live_execution_enabled)
                VALUES (%s, %s::jsonb, %s, FALSE)
                ON CONFLICT (service_key) DO UPDATE
                SET checkpoint_payload = EXCLUDED.checkpoint_payload, updated_at = EXCLUDED.updated_at, live_execution_enabled = FALSE
                """,
                (service_key, json.dumps(payload), ts),
            )

    def load_runtime_checkpoint(self, service_key: str) -> RuntimeCheckpoint | None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT checkpoint_payload, updated_at FROM paper_runtime_checkpoints WHERE service_key = %s",
                (service_key,),
            )
            row = self._fetchone_dict(cur)
            if row is None:
                return None
            return RuntimeCheckpoint(service_key, row["checkpoint_payload"], row["updated_at"])

    def save_market_snapshot(self, snapshot: StoredMarketSnapshot) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_market_snapshots(
                  canonical_instrument_id, market_code, source_key, reference_price,
                  available_liquidity_notional, data_timestamp, received_at
                ) VALUES (%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    snapshot.instrument_id, snapshot.market_code, snapshot.source_key,
                    snapshot.reference_price, snapshot.available_liquidity_notional,
                    snapshot.data_timestamp, snapshot.received_at,
                ),
            )

    def latest_market_snapshot(self, instrument_id: str) -> StoredMarketSnapshot | None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT canonical_instrument_id, market_code, source_key, reference_price,
                       available_liquidity_notional, data_timestamp, received_at
                FROM paper_market_snapshots
                WHERE canonical_instrument_id = %s
                ORDER BY data_timestamp DESC, received_at DESC
                LIMIT 1
                """,
                (instrument_id,),
            )
            row = self._fetchone_dict(cur)
            if row is None:
                return None
            return StoredMarketSnapshot(
                instrument_id=row["canonical_instrument_id"],
                market_code=row["market_code"],
                source_key=row["source_key"],
                reference_price=float(row["reference_price"]),
                available_liquidity_notional=float(row["available_liquidity_notional"]),
                data_timestamp=row["data_timestamp"],
                received_at=row["received_at"],
            )

    def add_prediction_settlement(self, record: PredictionSettlementRecord) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO prediction_settlement_queue(
                  prediction_key, canonical_instrument_id, market_code, proposed_direction,
                  confidence, expected_net_return, horizon, baseline_price, due_at,
                  traded, realized_trade_pnl, settlement_status
                ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (prediction_key) DO NOTHING
                """,
                (
                    record.prediction_id, record.instrument_id, record.market_code,
                    record.direction, record.confidence, record.expected_net_return,
                    record.horizon, record.baseline_price, record.due_at,
                    record.traded, record.realized_trade_pnl, record.status,
                ),
            )

    def due_prediction_settlements(self, now: datetime) -> tuple[PredictionSettlementRecord, ...]:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT prediction_key, canonical_instrument_id, market_code, proposed_direction,
                       confidence, expected_net_return, horizon, baseline_price, due_at,
                       traded, realized_trade_pnl, settlement_status
                FROM prediction_settlement_queue
                WHERE settlement_status = 'PENDING' AND due_at <= %s
                ORDER BY due_at, prediction_key
                """,
                (now,),
            )
            rows = cur.fetchall()
            names = self._column_names(cur.description)
            out = []
            for raw in rows:
                row = raw if isinstance(raw, dict) else dict(zip(names, raw))
                out.append(PredictionSettlementRecord(
                    prediction_id=row["prediction_key"], instrument_id=row["canonical_instrument_id"],
                    market_code=row["market_code"], direction=row["proposed_direction"],
                    confidence=float(row["confidence"]), expected_net_return=float(row["expected_net_return"]),
                    horizon=row["horizon"], baseline_price=float(row["baseline_price"]), due_at=row["due_at"],
                    traded=bool(row["traded"]), realized_trade_pnl=None if row["realized_trade_pnl"] is None else float(row["realized_trade_pnl"]),
                    status=row["settlement_status"],
                ))
            return tuple(out)

    def mark_prediction_settled(self, prediction_id: str, result: dict[str, Any]) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE prediction_settlement_queue
                SET settlement_status='SETTLED', settled_at=%s, settlement_payload=%s::jsonb
                WHERE prediction_key=%s AND settlement_status='PENDING'
                """,
                (result["evaluated_at"], json.dumps(result, default=str), prediction_id),
            )

    def update_prediction_trade_result(self, prediction_id: str, traded: bool = True, realized_trade_pnl: float | None = None) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE prediction_settlement_queue
                SET traded=%s, realized_trade_pnl=COALESCE(%s, realized_trade_pnl)
                WHERE prediction_key=%s
                """,
                (traded, realized_trade_pnl, prediction_id),
            )

    def save_worker_heartbeat(self, heartbeat: WorkerHeartbeat) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_worker_heartbeats(service_key, worker_status, heartbeat_at, details, live_execution_enabled)
                VALUES (%s,%s,%s,%s::jsonb,FALSE)
                ON CONFLICT (service_key) DO UPDATE
                SET worker_status=EXCLUDED.worker_status, heartbeat_at=EXCLUDED.heartbeat_at,
                    details=EXCLUDED.details, live_execution_enabled=FALSE
                """,
                (heartbeat.service_key, heartbeat.status, heartbeat.heartbeat_at, json.dumps(heartbeat.details)),
            )

    def save_worker_event(self, event: dict[str, Any]) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "INSERT INTO paper_worker_events(service_key, event_type, event_at, event_payload) VALUES (%s,%s,%s,%s::jsonb)",
                (event["service_key"], event["event_type"], event["event_at"], json.dumps(event, default=str)),
            )

    def save_daily_report(self, report: dict[str, Any]) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_worker_daily_reports(service_key, market_code, report_date, generated_at, report_payload)
                VALUES (%s,%s,%s,%s,%s::jsonb)
                ON CONFLICT (service_key, market_code, report_date) DO UPDATE
                SET generated_at=EXCLUDED.generated_at, report_payload=EXCLUDED.report_payload
                """,
                (report["service_key"], report["market"], report["report_date"], report["generated_at"], json.dumps(report, default=str)),
            )
    def add_paper_candidate(self, record: PaperCandidateRecord) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO paper_candidate_inbox(candidate_key, candidate_payload, strategy_key, created_at, candidate_status, status_reason)
                VALUES (%s,%s::jsonb,%s,%s,%s,%s)
                ON CONFLICT (candidate_key) DO NOTHING
                """,
                (record.candidate_key, json.dumps(record.candidate_payload), record.strategy_key, record.created_at, record.status, record.status_reason),
            )

    def pending_paper_candidates(self, limit: int = 100) -> tuple[PaperCandidateRecord, ...]:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT candidate_key, candidate_payload, strategy_key, created_at, candidate_status, status_reason
                FROM paper_candidate_inbox
                WHERE candidate_status='PENDING'
                ORDER BY created_at, candidate_key
                LIMIT %s
                """,
                (limit,),
            )
            rows = cur.fetchall()
            names = self._column_names(cur.description)
            out = []
            for raw in rows:
                row = raw if isinstance(raw, dict) else dict(zip(names, raw))
                out.append(PaperCandidateRecord(
                    candidate_key=row["candidate_key"], candidate_payload=row["candidate_payload"], strategy_key=row["strategy_key"],
                    created_at=row["created_at"], status=row["candidate_status"], status_reason=row["status_reason"],
                ))
            return tuple(out)

    def mark_paper_candidate(self, candidate_key: str, status: str, reason: str) -> None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "UPDATE paper_candidate_inbox SET candidate_status=%s, status_reason=%s, updated_at=now() WHERE candidate_key=%s",
                (status, reason, candidate_key),
            )

    def ping(self) -> bool:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1")
            row = cur.fetchone()
            return bool(row and row[0] == 1)

    def get_worker_heartbeat(self, service_key: str) -> WorkerHeartbeat | None:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT service_key, worker_status, heartbeat_at, details FROM paper_worker_heartbeats WHERE service_key=%s",
                (service_key,),
            )
            row = self._fetchone_dict(cur)
            if row is None:
                return None
            return WorkerHeartbeat(row["service_key"], row["worker_status"], row["heartbeat_at"], row["details"])

    def recent_worker_events(self, service_key: str, limit: int = 100) -> list[dict[str, Any]]:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT event_type, event_at, event_payload FROM paper_worker_events WHERE service_key=%s ORDER BY event_at DESC, id DESC LIMIT %s",
                (service_key, limit),
            )
            rows = cur.fetchall(); names = self._column_names(cur.description)
            return [{**(r if isinstance(r, dict) else dict(zip(names, r))), "event_at": (r[1] if not isinstance(r, dict) else r["event_at"]).isoformat()} for r in rows]

    def recent_daily_reports(self, service_key: str, market_code: str | None = None, limit: int = 30) -> list[dict[str, Any]]:
        with self._connection() as conn, conn.cursor() as cur:
            if market_code is None:
                cur.execute(
                    "SELECT market_code, report_date, generated_at, report_payload FROM paper_worker_daily_reports WHERE service_key=%s ORDER BY report_date DESC, generated_at DESC LIMIT %s",
                    (service_key, limit),
                )
            else:
                cur.execute(
                    "SELECT market_code, report_date, generated_at, report_payload FROM paper_worker_daily_reports WHERE service_key=%s AND market_code=%s ORDER BY report_date DESC, generated_at DESC LIMIT %s",
                    (service_key, market_code, limit),
                )
            rows = cur.fetchall(); names = self._column_names(cur.description)
            out=[]
            for raw in rows:
                row=raw if isinstance(raw, dict) else dict(zip(names, raw))
                out.append({"market": row["market_code"], "report_date": row["report_date"].isoformat(), "generated_at": row["generated_at"].isoformat(), "report": row["report_payload"]})
            return out

    def recent_market_snapshots(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connection() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT canonical_instrument_id, market_code, source_key, reference_price, available_liquidity_notional, data_timestamp, received_at FROM paper_market_snapshots ORDER BY data_timestamp DESC, received_at DESC, id DESC LIMIT %s",
                (limit,),
            )
            rows=cur.fetchall(); names=self._column_names(cur.description); out=[]
            for raw in rows:
                row=raw if isinstance(raw, dict) else dict(zip(names,raw))
                out.append({"instrument_id":row["canonical_instrument_id"],"market_code":row["market_code"],"source_key":row["source_key"],"reference_price":float(row["reference_price"]),"available_liquidity_notional":float(row["available_liquidity_notional"]),"data_timestamp":row["data_timestamp"].isoformat(),"received_at":row["received_at"].isoformat()})
            return out

    def list_paper_candidates(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        with self._connection() as conn, conn.cursor() as cur:
            if status is None:
                cur.execute("SELECT candidate_key, candidate_payload, strategy_key, created_at, candidate_status, status_reason FROM paper_candidate_inbox ORDER BY created_at DESC LIMIT %s", (limit,))
            else:
                cur.execute("SELECT candidate_key, candidate_payload, strategy_key, created_at, candidate_status, status_reason FROM paper_candidate_inbox WHERE candidate_status=%s ORDER BY created_at DESC LIMIT %s", (status,limit))
            rows=cur.fetchall(); names=self._column_names(cur.description); out=[]
            for raw in rows:
                row=raw if isinstance(raw, dict) else dict(zip(names,raw))
                out.append({"candidate_key":row["candidate_key"],"strategy_key":row["strategy_key"],"created_at":row["created_at"].isoformat(),"status":row["candidate_status"],"status_reason":row["status_reason"],"candidate":row["candidate_payload"]})
            return out

    def list_prediction_settlements(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        with self._connection() as conn, conn.cursor() as cur:
            sql="SELECT prediction_key, canonical_instrument_id, market_code, proposed_direction, confidence, expected_net_return, horizon, baseline_price, due_at, traded, realized_trade_pnl, settlement_status, settled_at, settlement_payload FROM prediction_settlement_queue"
            params=[]
            if status is not None:
                sql += " WHERE settlement_status=%s"; params.append(status)
            sql += " ORDER BY due_at DESC, prediction_key DESC LIMIT %s"; params.append(limit)
            cur.execute(sql, tuple(params)); rows=cur.fetchall(); names=self._column_names(cur.description); out=[]
            for raw in rows:
                row=raw if isinstance(raw, dict) else dict(zip(names,raw))
                out.append({"prediction_id":row["prediction_key"],"instrument_id":row["canonical_instrument_id"],"market_code":row["market_code"],"direction":row["proposed_direction"],"confidence":float(row["confidence"]),"expected_net_return":float(row["expected_net_return"]),"horizon":row["horizon"],"baseline_price":float(row["baseline_price"]),"due_at":row["due_at"].isoformat(),"traded":bool(row["traded"]),"realized_trade_pnl":None if row["realized_trade_pnl"] is None else float(row["realized_trade_pnl"]),"status":row["settlement_status"],"settled_at":None if row["settled_at"] is None else row["settled_at"].isoformat(),"settlement":row["settlement_payload"]})
            return out

