from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

from .automation import MarketEntrySnapshot, run_entry_cycle
from .candidate_queue import CandidateQueue
from .equity_curve import EquityPoint, EquityCurveSummary, summarize_equity_curve
from .market_calendar import MarketCalendar
from .models import CandidateTrade, PaperOrder, PortfolioState, RiskPolicy
from .rollover import close_paper_day
from .session import PriceBar, process_bars, start_session


@dataclass(frozen=True)
class DailySimulationInput:
    session_date: date
    market: str
    candidates: tuple[tuple[CandidateTrade, str], ...]
    entry_snapshots: dict[str, MarketEntrySnapshot]
    bars: tuple[PriceBar, ...]


@dataclass(frozen=True)
class MultiDaySimulationResult:
    day_reports: tuple[object, ...]
    equity_points: tuple[EquityPoint, ...]
    equity_summary: EquityCurveSummary
    order_count: int
    closed_trade_count: int


def _default_entry_time(day: date, market: str) -> datetime:
    # Fixtures use UTC-safe timestamps chosen to land inside the configured entry windows.
    hour = {"IN": 4, "JP": 1, "HK": 3, "SG": 2, "US": 15, "UK": 9, "EU": 9}.get(market, 10)
    return datetime(day.year, day.month, day.day, hour, 0, tzinfo=timezone.utc)


def run_multi_day_simulation(
    calendar: MarketCalendar,
    portfolio: PortfolioState,
    risk_policy: RiskPolicy,
    days: tuple[DailySimulationInput, ...],
) -> MultiDaySimulationResult:
    queue = CandidateQueue(calendar)
    all_orders: list[PaperOrder] = []
    orders_by_instrument: dict[str, PaperOrder] = {}
    reports = []
    ordered_days = sorted(days, key=lambda d: d.session_date)
    points: list[EquityPoint] = []
    if ordered_days:
        points.append(EquityPoint(ordered_days[0].session_date - timedelta(days=1), portfolio.equity()))
    for day in ordered_days:
        entry_at = _default_entry_time(day.session_date, day.market)
        session = start_session(portfolio, day.session_date, entry_at - timedelta(minutes=35))
        day_orders: list[PaperOrder] = []
        for candidate, strategy_key in day.candidates:
            if candidate.instrument_id in portfolio.positions:
                continue
            queue.enqueue(candidate, strategy_key, entry_at - timedelta(minutes=30))
        _, new_orders = run_entry_cycle(queue, portfolio, risk_policy, day.entry_snapshots, entry_at)
        for order in new_orders:
            all_orders.append(order)
            day_orders.append(order)
            orders_by_instrument[order.instrument_id] = order
        process_bars(session, portfolio, orders_by_instrument, day.bars)
        rollover = close_paper_day(portfolio, day.session_date, session.start_equity, [], day_orders,
                                   entry_at + timedelta(hours=8))
        reports.append(rollover.report)
        points.append(EquityPoint(day.session_date, rollover.end_snapshot.equity))
    return MultiDaySimulationResult(
        day_reports=tuple(reports),
        equity_points=tuple(points),
        equity_summary=summarize_equity_curve(points),
        order_count=len(all_orders),
        closed_trade_count=len(portfolio.closed_trade_pnls),
    )
