"""Paper trading and portfolio simulation services.

Phase 0.x is simulation-only. Nothing in this package can reach a broker.
"""
