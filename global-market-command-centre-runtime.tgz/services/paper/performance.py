from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from statistics import mean, pstdev
from typing import Sequence


@dataclass(frozen=True)
class PerformanceSummary:
    trade_count: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    gross_profit: float
    gross_loss: float
    net_pnl: float
    profit_factor: float | None
    average_trade: float
    payoff_ratio: float | None
    expectancy: float
    trade_sharpe_like: float | None


def summarize_trade_pnls(pnls: Sequence[float]) -> PerformanceSummary:
    vals = [float(x) for x in pnls]
    wins = [x for x in vals if x > 0]
    losses = [x for x in vals if x < 0]
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))
    count = len(vals)
    win_rate = len(wins) / count if count else 0.0
    avg_win = mean(wins) if wins else 0.0
    avg_loss = abs(mean(losses)) if losses else 0.0
    # Undefined when there are no losses; use None rather than non-standard JSON Infinity.
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else None
    payoff = avg_win / avg_loss if avg_loss > 0 else None
    avg_trade = mean(vals) if vals else 0.0
    expectation = win_rate * avg_win - (1.0 - win_rate) * avg_loss if count else 0.0
    sd = pstdev(vals) if count > 1 else 0.0
    sharpe_like = (avg_trade / sd) * sqrt(count) if sd > 0 else None
    return PerformanceSummary(
        trade_count=count,
        winning_trades=len(wins),
        losing_trades=len(losses),
        win_rate=round(win_rate, 6),
        gross_profit=round(gross_profit, 8),
        gross_loss=round(gross_loss, 8),
        net_pnl=round(sum(vals), 8),
        profit_factor=None if profit_factor is None else round(profit_factor, 6),
        average_trade=round(avg_trade, 8),
        payoff_ratio=None if payoff is None else round(payoff, 6),
        expectancy=round(expectation, 8),
        trade_sharpe_like=None if sharpe_like is None else round(sharpe_like, 6),
    )
