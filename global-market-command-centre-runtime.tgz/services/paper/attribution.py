from __future__ import annotations

from dataclasses import dataclass
from statistics import mean
from typing import Iterable


@dataclass(frozen=True)
class PredictionOutcome:
    prediction_id: str
    instrument_id: str
    direction: str
    confidence: float
    expected_net_return: float
    actual_return: float
    traded: bool = False
    realized_trade_pnl: float | None = None


@dataclass(frozen=True)
class PredictionAttribution:
    prediction_id: str
    direction_hit: bool
    signed_actual_return: float
    return_error: float
    brier_score: float
    trade_profitable: bool | None


@dataclass(frozen=True)
class AttributionSummary:
    sample_count: int
    direction_accuracy: float
    mean_signed_actual_return: float
    mean_absolute_return_error: float
    brier_score: float
    traded_count: int
    profitable_trade_rate: float | None


def attribute_prediction(outcome: PredictionOutcome) -> PredictionAttribution:
    direction = outcome.direction.upper()
    if direction not in {"UP", "DOWN", "LONG", "SHORT"}:
        raise ValueError("unsupported prediction direction")
    if not (0.0 <= outcome.confidence <= 1.0):
        raise ValueError("confidence must be between 0 and 1")
    sign = 1.0 if direction in {"UP", "LONG"} else -1.0
    signed_actual = sign * outcome.actual_return
    hit = signed_actual > 0
    # Confidence is interpreted as probability that the proposed direction is correct.
    y = 1.0 if hit else 0.0
    brier = (outcome.confidence - y) ** 2
    expected_signed = abs(outcome.expected_net_return)
    return_error = signed_actual - expected_signed
    profitable = None
    if outcome.traded and outcome.realized_trade_pnl is not None:
        profitable = outcome.realized_trade_pnl > 0
    return PredictionAttribution(
        prediction_id=outcome.prediction_id,
        direction_hit=hit,
        signed_actual_return=round(signed_actual, 8),
        return_error=round(return_error, 8),
        brier_score=round(brier, 8),
        trade_profitable=profitable,
    )


def summarize_attribution(outcomes: Iterable[PredictionOutcome]) -> AttributionSummary:
    rows = [attribute_prediction(x) for x in outcomes]
    if not rows:
        return AttributionSummary(0, 0.0, 0.0, 0.0, 0.0, 0, None)
    traded = [r for r in rows if r.trade_profitable is not None]
    return AttributionSummary(
        sample_count=len(rows),
        direction_accuracy=round(sum(r.direction_hit for r in rows) / len(rows), 6),
        mean_signed_actual_return=round(mean(r.signed_actual_return for r in rows), 8),
        mean_absolute_return_error=round(mean(abs(r.return_error) for r in rows), 8),
        brier_score=round(mean(r.brier_score for r in rows), 8),
        traded_count=len(traded),
        profitable_trade_rate=None if not traded else round(sum(bool(r.trade_profitable) for r in traded) / len(traded), 6),
    )
