from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping


@dataclass(frozen=True)
class RiskPolicy:
    starting_capital: float = 1_000_000.0
    max_position_pct: float = 5.0
    max_sector_exposure_pct: float = 20.0
    max_daily_loss_pct: float = 1.0
    max_trade_risk_pct: float = 0.5
    max_portfolio_drawdown_pct: float = 8.0
    min_model_confidence: float = 0.65
    min_expected_reward_risk: float = 1.8
    max_open_positions: int = 12
    max_correlated_theme_positions: int = 3
    min_cash_reserve_pct: float = 20.0
    live_execution_enabled: bool = False
    allow_short: bool = False
    block_on_stale_data: bool = True
    block_on_model_disagreement: bool = True
    require_invalidation_level: bool = True


@dataclass(frozen=True)
class CandidateTrade:
    candidate_id: str
    instrument_id: str
    market: str
    sector: str
    theme: str
    direction: str
    entry_price: float
    stop_price: float
    target_price: float
    confidence: float
    expected_net_return: float
    horizon: str
    invalidation_level: float | None = None
    stale_data: bool = False
    model_disagreement: bool = False


@dataclass(frozen=True)
class RiskDecision:
    verdict: str
    max_notional: float
    suggested_quantity: int
    risk_amount: float
    reward_risk: float
    reasons: tuple[str, ...]


@dataclass
class PaperOrder:
    order_id: str
    candidate_id: str
    instrument_id: str
    direction: str
    quantity: int
    requested_price: float
    status: str = "NEW"
    created_at: datetime = field(default_factory=lambda: datetime.now(__import__("datetime").timezone.utc))
    filled_at: datetime | None = None
    fill_price: float | None = None
    rejected_reason: str | None = None
    exit_price: float | None = None
    closed_at: datetime | None = None


@dataclass
class Position:
    instrument_id: str
    sector: str
    theme: str
    direction: str
    quantity: int
    average_price: float
    last_price: float
    stop_price: float
    target_price: float
    opened_at: datetime
    strategy_key: str
    fees_paid: float = 0.0

    @property
    def market_value(self) -> float:
        return self.quantity * self.last_price

    @property
    def unrealized_pnl(self) -> float:
        sign = 1.0 if self.direction.upper() == "LONG" else -1.0
        return sign * self.quantity * (self.last_price - self.average_price) - self.fees_paid


@dataclass
class PortfolioState:
    starting_capital: float
    cash: float
    realized_pnl: float = 0.0
    day_realized_pnl: float = 0.0
    day_start_equity: float | None = None
    high_water_mark: float | None = None
    positions: dict[str, Position] = field(default_factory=dict)
    closed_trade_pnls: list[float] = field(default_factory=list)
    strategy_trade_pnls: dict[str, list[float]] = field(default_factory=dict)

    def equity(self) -> float:
        # Cash is reduced at entry for long positions, so add marked market value.
        long_value = sum(p.market_value for p in self.positions.values() if p.direction.upper() == "LONG")
        short_margin_value = 0.0
        short_unrealized = sum(p.unrealized_pnl for p in self.positions.values() if p.direction.upper() == "SHORT")
        return self.cash + long_value + short_margin_value + short_unrealized

    def exposures_by_sector(self) -> Mapping[str, float]:
        out: dict[str, float] = {}
        for p in self.positions.values():
            out[p.sector] = out.get(p.sector, 0.0) + abs(p.market_value)
        return out
