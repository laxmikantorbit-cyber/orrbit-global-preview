from __future__ import annotations

from dataclasses import dataclass
from math import ceil

from .models import PaperOrder


@dataclass(frozen=True)
class FillPolicy:
    half_spread_bps: float = 4.0
    base_slippage_bps: float = 3.0
    impact_bps_per_100k: float = 1.0
    max_total_slippage_bps: float = 35.0
    max_notional_to_liquidity_pct: float = 2.0
    minimum_fee: float = 0.0
    fee_bps: float = 0.0


@dataclass(frozen=True)
class FillResult:
    fillable: bool
    fill_price: float | None
    fee: float
    effective_slippage_bps: float
    reason: str


def simulate_market_fill(
    order: PaperOrder,
    reference_price: float,
    available_liquidity_notional: float,
    policy: FillPolicy | None = None,
) -> FillResult:
    p = policy or FillPolicy()
    if reference_price <= 0 or available_liquidity_notional <= 0:
        return FillResult(False, None, 0.0, 0.0, "invalid_market_inputs")
    notional = order.quantity * reference_price
    if notional <= 0:
        return FillResult(False, None, 0.0, 0.0, "invalid_order_notional")
    if notional > available_liquidity_notional * p.max_notional_to_liquidity_pct / 100.0:
        return FillResult(False, None, 0.0, 0.0, "paper_liquidity_limit")

    impact = p.impact_bps_per_100k * (notional / 100_000.0)
    total_bps = min(p.half_spread_bps + p.base_slippage_bps + impact, p.max_total_slippage_bps)
    sign = 1.0 if order.direction.upper() == "LONG" else -1.0
    fill_price = reference_price * (1.0 + sign * total_bps / 10_000.0)
    fee = max(p.minimum_fee, notional * p.fee_bps / 10_000.0)
    return FillResult(True, round(fill_price, 8), round(fee, 8), round(total_bps, 4), "simulated_market_fill")
