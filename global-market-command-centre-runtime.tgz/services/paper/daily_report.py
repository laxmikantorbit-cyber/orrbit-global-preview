from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone

from .models import PaperOrder, PortfolioState
from .performance import summarize_trade_pnls
from .session import PortfolioSnapshot


@dataclass(frozen=True)
class DailyPaperReport:
    report_date: date
    generated_at: datetime
    start_equity: float
    end_equity: float
    daily_return_pct: float
    realized_pnl: float
    unrealized_pnl: float
    max_drawdown_pct: float
    open_positions: int
    orders_created: int
    orders_filled: int
    orders_closed: int
    orders_cancelled_or_rejected: int
    trade_count_total: int
    win_rate_total: float
    net_pnl_total: float
    strategy_summaries: dict[str, dict]
    warnings: tuple[str, ...]


def build_daily_report(
    report_date: date,
    portfolio: PortfolioState,
    snapshots: list[PortfolioSnapshot],
    orders: list[PaperOrder],
    start_equity: float,
    generated_at: datetime | None = None,
) -> DailyPaperReport:
    ts = generated_at or datetime.now(timezone.utc)
    end_equity = portfolio.equity()
    daily_return = 100.0 * (end_equity / start_equity - 1.0) if start_equity > 0 else 0.0
    max_dd = max((s.drawdown_pct for s in snapshots), default=0.0)
    unrealized = sum(p.unrealized_pnl for p in portfolio.positions.values())
    total = summarize_trade_pnls(portfolio.closed_trade_pnls)
    strategies = {
        key: asdict(summarize_trade_pnls(vals))
        for key, vals in sorted(portfolio.strategy_trade_pnls.items())
    }
    warnings: list[str] = []
    if not orders:
        warnings.append("no_paper_orders_created")
    if total.trade_count < 5:
        warnings.append("insufficient_completed_trades_for_performance_inference")
    if max_dd >= 5.0:
        warnings.append("elevated_paper_drawdown")
    return DailyPaperReport(
        report_date=report_date,
        generated_at=ts,
        start_equity=round(start_equity, 8),
        end_equity=round(end_equity, 8),
        daily_return_pct=round(daily_return, 6),
        realized_pnl=round(portfolio.day_realized_pnl, 8),
        unrealized_pnl=round(unrealized, 8),
        max_drawdown_pct=round(max_dd, 6),
        open_positions=len(portfolio.positions),
        orders_created=len(orders),
        orders_filled=sum(o.status in {"FILLED", "CLOSED"} for o in orders),
        orders_closed=sum(o.status == "CLOSED" for o in orders),
        orders_cancelled_or_rejected=sum(o.status in {"CANCELLED", "REJECTED"} for o in orders),
        trade_count_total=total.trade_count,
        win_rate_total=total.win_rate,
        net_pnl_total=total.net_pnl,
        strategy_summaries=strategies,
        warnings=tuple(warnings),
    )
