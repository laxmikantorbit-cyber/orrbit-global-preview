from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from typing import Any

from .candidate_queue import CandidateQueue, CandidateQueueItem
from .models import CandidateTrade, PaperOrder, PortfolioState, Position


def _dt(value: str | None) -> datetime | None:
    return None if value is None else datetime.fromisoformat(value)


def encode_runtime_state(
    portfolio: PortfolioState,
    queue: CandidateQueue,
    orders_by_instrument: dict[str, PaperOrder],
) -> dict[str, Any]:
    positions = {}
    for key, position in portfolio.positions.items():
        row = asdict(position)
        row["opened_at"] = position.opened_at.isoformat()
        positions[key] = row

    orders = {}
    for key, order in orders_by_instrument.items():
        row = asdict(order)
        for dt_key in ("created_at", "filled_at", "closed_at"):
            value = row.get(dt_key)
            if isinstance(value, datetime):
                row[dt_key] = value.isoformat()
        orders[key] = row

    queue_rows = []
    for item in queue.items.values():
        queue_rows.append({
            "queue_id": item.queue_id,
            "candidate": asdict(item.candidate),
            "strategy_key": item.strategy_key,
            "created_at": item.created_at.isoformat(),
            "expires_at": item.expires_at.isoformat(),
            "status": item.status,
            "status_reason": item.status_reason,
            "last_checked_at": None if item.last_checked_at is None else item.last_checked_at.isoformat(),
        })

    return {
        "portfolio": {
            "starting_capital": portfolio.starting_capital,
            "cash": portfolio.cash,
            "realized_pnl": portfolio.realized_pnl,
            "day_realized_pnl": portfolio.day_realized_pnl,
            "day_start_equity": portfolio.day_start_equity,
            "high_water_mark": portfolio.high_water_mark,
            "positions": positions,
            "closed_trade_pnls": list(portfolio.closed_trade_pnls),
            "strategy_trade_pnls": {k: list(v) for k, v in portfolio.strategy_trade_pnls.items()},
        },
        "queue_items": queue_rows,
        "orders_by_instrument": orders,
    }


def restore_runtime_state(payload: dict[str, Any], queue: CandidateQueue) -> tuple[PortfolioState, dict[str, PaperOrder]]:
    raw = payload["portfolio"]
    portfolio = PortfolioState(
        starting_capital=float(raw["starting_capital"]),
        cash=float(raw["cash"]),
        realized_pnl=float(raw.get("realized_pnl", 0.0)),
        day_realized_pnl=float(raw.get("day_realized_pnl", 0.0)),
        day_start_equity=None if raw.get("day_start_equity") is None else float(raw["day_start_equity"]),
        high_water_mark=None if raw.get("high_water_mark") is None else float(raw["high_water_mark"]),
        closed_trade_pnls=[float(x) for x in raw.get("closed_trade_pnls", [])],
        strategy_trade_pnls={k: [float(x) for x in v] for k, v in raw.get("strategy_trade_pnls", {}).items()},
    )
    for key, row in raw.get("positions", {}).items():
        portfolio.positions[key] = Position(
            instrument_id=row["instrument_id"], sector=row["sector"], theme=row["theme"],
            direction=row["direction"], quantity=int(row["quantity"]), average_price=float(row["average_price"]),
            last_price=float(row["last_price"]), stop_price=float(row["stop_price"]), target_price=float(row["target_price"]),
            opened_at=datetime.fromisoformat(row["opened_at"]), strategy_key=row["strategy_key"], fees_paid=float(row.get("fees_paid", 0.0)),
        )

    queue.items.clear()
    for row in payload.get("queue_items", []):
        c = row["candidate"]
        candidate = CandidateTrade(
            candidate_id=c["candidate_id"], instrument_id=c["instrument_id"], market=c["market"], sector=c["sector"],
            theme=c["theme"], direction=c["direction"], entry_price=float(c["entry_price"]), stop_price=float(c["stop_price"]),
            target_price=float(c["target_price"]), confidence=float(c["confidence"]), expected_net_return=float(c["expected_net_return"]),
            horizon=c["horizon"], invalidation_level=None if c.get("invalidation_level") is None else float(c["invalidation_level"]),
            stale_data=bool(c.get("stale_data", False)), model_disagreement=bool(c.get("model_disagreement", False)),
        )
        item = CandidateQueueItem(
            queue_id=row["queue_id"], candidate=candidate, strategy_key=row["strategy_key"],
            created_at=datetime.fromisoformat(row["created_at"]), expires_at=datetime.fromisoformat(row["expires_at"]),
            status=row["status"], status_reason=row["status_reason"], last_checked_at=_dt(row.get("last_checked_at")),
        )
        queue.items[item.queue_id] = item

    orders: dict[str, PaperOrder] = {}
    for key, row in payload.get("orders_by_instrument", {}).items():
        orders[key] = PaperOrder(
            order_id=row["order_id"], candidate_id=row["candidate_id"], instrument_id=row["instrument_id"],
            direction=row["direction"], quantity=int(row["quantity"]), requested_price=float(row["requested_price"]),
            status=row.get("status", "NEW"), created_at=datetime.fromisoformat(row["created_at"]),
            filled_at=_dt(row.get("filled_at")), fill_price=None if row.get("fill_price") is None else float(row["fill_price"]),
            rejected_reason=row.get("rejected_reason"), exit_price=None if row.get("exit_price") is None else float(row["exit_price"]),
            closed_at=_dt(row.get("closed_at")),
        )
    return portfolio, orders
