from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .candidate_queue import CandidateQueue
from .capital_guardian import assess_candidate
from .fill_simulator import FillPolicy, simulate_market_fill
from .freshness import MarketDataFreshnessMonitor
from .models import PaperOrder, PortfolioState, RiskPolicy
from .portfolio import create_order, fill_order


@dataclass(frozen=True)
class MarketEntrySnapshot:
    instrument_id: str
    reference_price: float
    available_liquidity_notional: float
    data_timestamp: datetime | None = None
    received_at: datetime | None = None


@dataclass(frozen=True)
class PaperAutomationEvent:
    queue_id: str
    instrument_id: str
    status: str
    reason: str
    order_id: str | None = None
    fill_price: float | None = None
    quantity: int = 0


def run_entry_cycle(
    queue: CandidateQueue,
    portfolio: PortfolioState,
    risk_policy: RiskPolicy,
    market_snapshots: dict[str, MarketEntrySnapshot],
    now: datetime,
    fill_policy: FillPolicy | None = None,
    freshness_monitor: MarketDataFreshnessMonitor | None = None,
) -> tuple[list[PaperAutomationEvent], list[PaperOrder]]:
    events: list[PaperAutomationEvent] = []
    orders: list[PaperOrder] = []
    for item in queue.refresh(now):
        c = item.candidate
        market = market_snapshots.get(c.instrument_id)
        if market is None:
            events.append(PaperAutomationEvent(item.queue_id, c.instrument_id, "SKIP", "missing_market_snapshot"))
            continue
        if freshness_monitor is not None:
            if market.data_timestamp is None or market.received_at is None:
                events.append(PaperAutomationEvent(item.queue_id, c.instrument_id, "SKIP", "missing_market_freshness_timestamps"))
                continue
            freshness = freshness_monitor.check(c.instrument_id, market.data_timestamp, market.received_at, now)
            if not freshness.fresh:
                events.append(PaperAutomationEvent(item.queue_id, c.instrument_id, "SKIP", freshness.reason))
                continue
        decision = assess_candidate(c, portfolio, risk_policy)
        if decision.verdict != "ALLOW_PAPER":
            item.status = "REJECTED"
            item.status_reason = "capital_guardian_block"
            events.append(PaperAutomationEvent(item.queue_id, c.instrument_id, "BLOCK", ";".join(decision.reasons)))
            continue
        order = create_order(c, decision, created_at=now)
        fill = simulate_market_fill(order, market.reference_price, market.available_liquidity_notional, fill_policy)
        if not fill.fillable or fill.fill_price is None:
            item.status = "REJECTED"
            item.status_reason = fill.reason
            events.append(PaperAutomationEvent(item.queue_id, c.instrument_id, "NO_FILL", fill.reason, order.order_id, quantity=order.quantity))
            continue
        fill_order(order, c, portfolio, fill.fill_price, fee=fill.fee, strategy_key=item.strategy_key, filled_at=now)
        queue.mark_consumed(item.queue_id, "paper_order_filled")
        orders.append(order)
        events.append(PaperAutomationEvent(
            item.queue_id, c.instrument_id, "FILLED", fill.reason,
            order.order_id, fill.fill_price, order.quantity,
        ))
    return events, orders
