from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone

from .scheduler import SchedulerState


class RepositorySchedulerStore:
    """Scheduler store backed by the paper repository contract."""

    def __init__(self, repository, scheduler_key: str = "paper-validation-scheduler"):
        self.repository = repository
        self.scheduler_key = scheduler_key

    def load(self) -> SchedulerState:
        raw = self.repository.load_scheduler_state(self.scheduler_key)
        if not raw:
            return SchedulerState()
        return SchedulerState(
            version=int(raw.get("version", 1)),
            last_job_runs=dict(raw.get("last_job_runs", {})),
            completed_rollovers=list(raw.get("completed_rollovers", [])),
        )

    def save(self, state: SchedulerState) -> None:
        self.repository.save_scheduler_state(
            self.scheduler_key,
            asdict(state),
            datetime.now(timezone.utc),
        )
