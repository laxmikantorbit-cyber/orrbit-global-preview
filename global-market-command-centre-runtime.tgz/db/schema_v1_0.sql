-- Phase 1.0: persistent online paper-validation worker.
-- Research/paper only. There is intentionally no broker execution table or route.

CREATE TABLE IF NOT EXISTS paper_runtime_checkpoints (
  service_key TEXT PRIMARY KEY,
  checkpoint_payload JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  live_execution_enabled BOOLEAN NOT NULL DEFAULT FALSE CHECK (live_execution_enabled = FALSE)
);


CREATE TABLE IF NOT EXISTS paper_candidate_inbox (
  candidate_key TEXT PRIMARY KEY,
  candidate_payload JSONB NOT NULL,
  strategy_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  candidate_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (candidate_status IN ('PENDING','IMPORTED','REJECTED','CANCELLED')),
  status_reason TEXT NOT NULL DEFAULT 'awaiting_worker_import',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  live_execution_enabled BOOLEAN NOT NULL DEFAULT FALSE CHECK (live_execution_enabled = FALSE)
);

CREATE TABLE IF NOT EXISTS paper_market_snapshots (
  id BIGSERIAL PRIMARY KEY,
  canonical_instrument_id TEXT NOT NULL,
  market_code TEXT NOT NULL,
  source_key TEXT NOT NULL,
  reference_price NUMERIC NOT NULL CHECK (reference_price > 0),
  available_liquidity_notional NUMERIC NOT NULL DEFAULT 0 CHECK (available_liquidity_notional >= 0),
  data_timestamp TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS prediction_settlement_queue (
  prediction_key TEXT PRIMARY KEY,
  canonical_instrument_id TEXT NOT NULL,
  market_code TEXT NOT NULL,
  proposed_direction TEXT NOT NULL,
  confidence NUMERIC NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
  expected_net_return NUMERIC NOT NULL,
  horizon TEXT NOT NULL,
  baseline_price NUMERIC NOT NULL CHECK (baseline_price > 0),
  due_at TIMESTAMPTZ NOT NULL,
  traded BOOLEAN NOT NULL DEFAULT FALSE,
  realized_trade_pnl NUMERIC,
  settlement_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (settlement_status IN ('PENDING','SETTLED','CANCELLED')),
  settled_at TIMESTAMPTZ,
  settlement_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS paper_worker_heartbeats (
  service_key TEXT PRIMARY KEY,
  worker_status TEXT NOT NULL,
  heartbeat_at TIMESTAMPTZ NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  live_execution_enabled BOOLEAN NOT NULL DEFAULT FALSE CHECK (live_execution_enabled = FALSE)
);

CREATE TABLE IF NOT EXISTS paper_worker_events (
  id BIGSERIAL PRIMARY KEY,
  service_key TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_at TIMESTAMPTZ NOT NULL,
  event_payload JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS paper_worker_daily_reports (
  id BIGSERIAL PRIMARY KEY,
  service_key TEXT NOT NULL,
  market_code TEXT NOT NULL,
  report_date DATE NOT NULL,
  generated_at TIMESTAMPTZ NOT NULL,
  report_payload JSONB NOT NULL,
  UNIQUE(service_key, market_code, report_date)
);

CREATE INDEX IF NOT EXISTS ix_candidate_inbox_status_time
  ON paper_candidate_inbox(candidate_status, created_at);
CREATE INDEX IF NOT EXISTS ix_paper_snapshots_instrument_time
  ON paper_market_snapshots(canonical_instrument_id, data_timestamp DESC, received_at DESC);
CREATE INDEX IF NOT EXISTS ix_paper_snapshots_market_time
  ON paper_market_snapshots(market_code, data_timestamp DESC);
CREATE INDEX IF NOT EXISTS ix_prediction_settlement_due
  ON prediction_settlement_queue(settlement_status, due_at);
CREATE INDEX IF NOT EXISTS ix_worker_events_service_time
  ON paper_worker_events(service_key, event_at DESC);

-- Defense in depth: all Phase-1.0 runtime tables are paper-only by schema design.
