const state={token:sessionStorage.getItem('gmccOwnerToken')||'',dashboard:null};
const fmtMoney=v=>Number.isFinite(Number(v))?`₹${Number(v).toLocaleString('en-IN',{maximumFractionDigits:2})}`:'—';
const fmtTime=v=>v?new Date(v).toLocaleString():'—';
const esc=v=>String(v??'—').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

function authHeaders(){return state.token?{'Authorization':`Bearer ${state.token}`}:{}}
function setAuthStatus(text){document.querySelector('#authStatus').textContent=text}

async function api(path){
  const r=await fetch(path,{headers:authHeaders()});
  if(!r.ok) throw new Error(`${r.status} ${await r.text()}`);
  return r.json();
}

function renderDisconnected(){
  document.querySelector('#kpis').innerHTML=[['Capital','Not connected'],['Today Net P&L','—'],['Paper Service','DISCONNECTED'],['Execution','LOCKED']].map(x=>`<article class="card kpi"><span>${x[0]}</span><strong>${x[1]}</strong></article>`).join('');
  document.querySelector('#events').innerHTML='<div class="muted">Connect owner session to load worker events.</div>';
  document.querySelector('#opportunities').innerHTML='<div class="muted">Connect owner session to load paper candidates.</div>';
  document.querySelector('#audit').innerHTML='<div class="row"><span>Live orders</span><span>0</span><span class="muted">Execution</span><span>LOCKED</span></div>';
  document.querySelector('#performance').innerHTML='<p class="muted">No private runtime data loaded.</p>';
  document.querySelector('#equitySpark').innerHTML='';
  document.querySelector('#strategies').innerHTML='<div class="muted">Strategy performance will appear after paper reports accumulate.</div>';
}

function renderDashboard(d){
  const cp=d.checkpoint?.portfolio||{};
  const hb=d.heartbeat;
  const latestReport=d.reports?.[0]?.report||{};
  const capital=cp.starting_capital??cp.cash??null;
  const net=latestReport.realized_pnl??cp.realized_pnl??0;
  const kpis=[['Capital',capital==null?'Awaiting checkpoint':fmtMoney(capital)],['Latest P&L',fmtMoney(net)],['Paper Service',hb?.status||'NO HEARTBEAT'],['Execution','LOCKED']];
  document.querySelector('#kpis').innerHTML=kpis.map(x=>`<article class="card kpi"><span>${x[0]}</span><strong>${x[1]}</strong></article>`).join('');

  const events=(d.events||[]).slice(0,10);
  document.querySelector('#events').innerHTML=events.length?events.map(x=>`<div class="row"><span>${esc(x.event_type)}</span><span class="muted">${esc(x.event_payload?.market||x.event_payload?.job_type||'worker')}</span><span><i class="pill">${fmtTime(x.event_at)}</i></span><span>PAPER</span></div>`).join(''):'<div class="muted">No worker events yet.</div>';

  const candidates=(d.candidates||[]).slice(0,10);
  document.querySelector('#opportunities').innerHTML=candidates.length?candidates.map(x=>`<div class="row"><span>${esc(x.candidate?.instrument_id||x.candidate_key)}</span><span>${esc(x.strategy_key)}</span><span>${esc(x.candidate?.confidence??'—')}</span><span><i class="pill">${esc(x.status)}</i></span></div>`).join(''):'<div class="muted">No paper candidates yet.</div>';

  const snapshot=d.market_snapshots?.[0];
  document.querySelector('#audit').innerHTML=`
    <div class="row"><span>Worker heartbeat</span><span>${esc(hb?.status||'NONE')}</span><span class="muted">Last heartbeat</span><span>${fmtTime(hb?.heartbeat_at)}</span></div>
    <div class="row"><span>Market snapshots</span><span>${d.market_snapshots?.length||0}</span><span class="muted">Latest source</span><span>${esc(snapshot?.source_key||'—')}</span></div>
    <div class="row"><span>Settlement records</span><span>${d.settlements?.length||0}</span><span class="muted">Live orders</span><span>0</span></div>
    <div class="row"><span>Mode</span><span>PAPER</span><span class="muted">Version</span><span>${esc(d.version)}</span></div>`;

  const reports=d.reports||[];
  if(reports.length){
    const r=reports[0].report||{};
    document.querySelector('#performance').innerHTML=`<div class="metric-grid"><div class="mini-metric"><span>Market</span><strong>${esc(reports[0].market)}</strong></div><div class="mini-metric"><span>Equity</span><strong>${fmtMoney(r.end_equity??r.equity)}</strong></div><div class="mini-metric"><span>Realized P&L</span><strong>${fmtMoney(r.realized_pnl)}</strong></div><div class="mini-metric"><span>Open positions</span><strong>${esc(r.open_position_count??'—')}</strong></div></div><p class="muted">Private paper-validation data; not a live-money performance claim.</p>`;
  }else document.querySelector('#performance').innerHTML='<p class="muted">No EOD paper report yet.</p>';
  document.querySelector('#equitySpark').innerHTML='';
  document.querySelector('#strategies').innerHTML='<div class="muted">Evidence-gated strategy comparison remains available after enough closed paper trades accumulate.</div>';
}

async function connect(){
  const input=document.querySelector('#ownerToken');
  if(input.value) state.token=input.value.trim();
  if(!state.token){setAuthStatus('Token required');return}
  try{
    setAuthStatus('Connecting…');
    const d=await api('/api/v1/dashboard');
    sessionStorage.setItem('gmccOwnerToken',state.token);
    state.dashboard=d; renderDashboard(d); setAuthStatus('Connected • private paper-validation data loaded');
  }catch(e){setAuthStatus(`Connection failed: ${e.message}`); renderDisconnected()}
}
function disconnect(){state.token='';state.dashboard=null;sessionStorage.removeItem('gmccOwnerToken');document.querySelector('#ownerToken').value='';setAuthStatus('Disconnected');renderDisconnected()}

document.querySelector('#connectBtn').addEventListener('click',connect);
document.querySelector('#disconnectBtn').addEventListener('click',disconnect);
document.querySelector('#ownerToken').addEventListener('keydown',e=>{if(e.key==='Enter')connect()});
renderDisconnected(); if(state.token) connect();
