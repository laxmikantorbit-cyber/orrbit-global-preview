import assert from "node:assert/strict";
import test from "node:test";
import {
  extractWazokuChallengeLinks,
  parseWazokuChallenge,
  scanWazokuPublicChallenges
} from "./wazoku-adapter.js";

const wetGasHtml = `
<html><body>
<h1>Improving Wet Gas Measurement Accuracy across industry-standard Flow Meters</h1>
<div>52 Submissions</div><div>$25,000</div><div>USD</div>
<div>Due: 12th Oct 2026</div>
<p>Solutions with Technology Readiness Levels (TRL) 3-6 are invited.</p>
<p>Use of AI: Please note that any submissions produced solely with generative AI are not of interest.</p>
</body></html>`;

const aircraftHtml = `
<html><body>
<h1>Technological Barrier to Prevent Incorrect Aircraft Fueling at Airport Terminals</h1>
<div>15 Submissions</div><div>$20,000</div><div>Due: 19th Oct 2026</div>
<p>The challenge is open to companies and organizations with demonstrated technical, operational, and financial capability to execute a pilot implementation.</p>
<p>Proposals submitted by individuals or by organizations that do not demonstrate the technical, operational, and financial capability to execute a pilot implementation are out of scope.</p>
<p>Proposals must include a clear implementation approach, deployment capability, and the resources required to support the pilot phase.</p>
<p>The Challenge offers an award of a paid pilot with a budget of $20,000 USD.</p>
<p>Use of AI: Please note that any submissions produced solely with generative AI are not of interest.</p>
</body></html>`;

test("Wazoku parser marks Wet Gas as review-fit and extracts public fields", () => {
  const result = parseWazokuChallenge(
    "https://www.innocentive.com/challenges/improving-wet-gas-measurement-accuracy-across-industry-standard-flow-meters/",
    wetGasHtml,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.prizeUsd, 25000);
  assert.equal(result.deadline, "2026-10-12");
  assert.equal(result.submissionCount, 52);
  assert.equal(result.fitStatus, "review");
  assert.match(result.automation, /solely with generative AI/);
});

test("Wazoku parser blocks Aircraft Fueling under zero-work execution constraints", () => {
  const result = parseWazokuChallenge(
    "https://www.innocentive.com/challenges/technological-barrier-to-prevent-incorrect-aircraft-fueling-at-airport-terminals/",
    aircraftHtml,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.prizeUsd, 20000);
  assert.equal(result.deadline, "2026-10-19");
  assert.equal(result.submissionCount, 15);
  assert.equal(result.fitStatus, "blocked");
  assert.ok(result.fitReasons.some((reason) => /individual submissions are out of scope/.test(reason)));
  assert.ok(result.fitReasons.some((reason) => /deployment\/pilot execution capability/.test(reason)));
});

test("Wazoku listing link parser excludes FAQ and pagination", () => {
  const links = extractWazokuChallengeLinks(`
    <a href="/challenges/wet-gas/">Wet Gas</a>
    <a href="https://www.innocentive.com/challenges/aircraft-fueling/">Aircraft</a>
    <a href="/challenges/faq/">FAQ</a>
    <a href="/challenges/page/2/">Page 2</a>
  `);

  assert.deepEqual(links, [
    "https://www.innocentive.com/challenges/wet-gas/",
    "https://www.innocentive.com/challenges/aircraft-fueling/"
  ]);
});

test("Wazoku scanner keeps active cash challenges and skips non-cash pages", async () => {
  const listing = `
    <a href="/challenges/wet-gas/">Wet Gas</a>
    <a href="/challenges/noncash/">Noncash</a>
  `;

  const fakeFetch = async (input: string | URL | Request) => {
    const url = String(input);

    if (url.includes("/page/2/")) {
      return new Response("<html></html>", { status: 200 });
    }
    if (url.endsWith("/challenges/")) {
      return new Response(listing, { status: 200 });
    }
    if (url.includes("/wet-gas/")) {
      return new Response(wetGasHtml, { status: 200 });
    }
    return new Response("<h1>Invitation Only</h1><p>Due: 1st Oct 2026</p>", { status: 200 });
  };

  const result = await scanWazokuPublicChallenges(
    fakeFetch,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.discoveredLinks, 2);
  assert.equal(result.challenges.length, 1);
  assert.equal(result.challenges[0]?.fitStatus, "review");
});


test("Wazoku parser rejects non-cash delegation page even when body mentions dollars", () => {
  const html = [
    "<html><body>",
    "<h1>Applications to Join Wazoku’s CIIE 2026 China Technology Transfer Delegation</h1>",
    "<div>16 Submissions</div><div>Due: 25th Sep 2026</div>",
    "<div>View Opportunity Details</div>",
    "<p>The expo represents more than $60 billion in trade opportunities.</p>",
    "</body></html>"
  ].join("");

  assert.throws(
    () => parseWazokuChallenge(
      "https://www.innocentive.com/challenges/applications-to-join-wazokus-ciie-2026-china-technology-transfer-delegation/",
      html,
      new Date("2026-09-23T00:00:00Z")
    ),
    /wazoku_cash_prize_missing/
  );
});
