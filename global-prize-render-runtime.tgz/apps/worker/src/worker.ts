import { execFile as execFileCallback } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readdir, rm, stat } from "node:fs/promises";
import { join } from "node:path";
import { promisify } from "node:util";
import pg from "pg";
import {
  backupOutcome,
  deadlineWatchOutcome,
  submissionIntegrityOutcome,
  type DeadlineOpportunity,
  type JobOutcome,
  type SubmissionViolation
} from "./jobs.js";
import {
  scanMetaculusFutureEvalTournaments,
  type MetaculusTournament
} from "./metaculus-adapter.js";
import {
  scanPatrollPublicContests,
  type PatrollContest
} from "./patroll-adapter.js";
import {
  scanWazokuPublicChallenges,
  type WazokuChallenge
} from "./wazoku-adapter.js";
import { scanDrivenDataPrizeCompetitions } from "./drivendata-adapter.js";
import { scanDevpostHighValueHackathons } from "./devpost-adapter.js";
import { ingestWorkerScannedOpportunity } from "./scanner-ingestion.js";

const { Pool } = pg;
const execFile = promisify(execFileCallback);

type ClaimedJob = {
  id: string;
  jobType: string;
  scheduleMinutes: number;
};

type DueJobRow = {
  id: string;
  job_type: string;
  schedule_minutes: number;
};

type DeadlineRow = {
  id: string;
  title: string;
  platform: string;
  deadline: Date | string;
  score: number;
};

type ViolationRow = {
  id: string;
  status: string;
  issue: string;
};

const configuredConnectionString = process.env.DATABASE_URL;
if (!configuredConnectionString) {
  throw new Error("DATABASE_URL is required by the automation worker");
}
const connectionString: string = configuredConnectionString;

const backupRoot = process.env.BACKUP_ROOT_PATH ?? "/backups";
const fileStoragePath = process.env.FILE_STORAGE_PATH ?? "/data/files";
const backupRetentionCount = Math.max(
  1,
  Math.trunc(Number(process.env.BACKUP_RETENTION_COUNT ?? "10"))
);

function postgresCommandEnv(): NodeJS.ProcessEnv {
  const url = new URL(connectionString);
  return {
    ...process.env,
    PGHOST: url.hostname,
    PGPORT: url.port || "5432",
    PGUSER: decodeURIComponent(url.username),
    PGPASSWORD: decodeURIComponent(url.password),
    PGDATABASE: decodeURIComponent(url.pathname.replace(/^\//, ""))
  };
}

function backupKey(now = new Date()): string {
  return now.toISOString().replace(/[-:.]/g, "");
}

const pollSeconds = Math.max(Number(process.env.WORKER_POLL_SECONDS ?? "60"), 5);
const pool = new Pool({
  connectionString,
  max: 3,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000
});

let stopping = false;

function dateOnly(value: Date | string): string {
  return value instanceof Date
    ? value.toISOString().slice(0, 10)
    : String(value).slice(0, 10);
}

async function claimDueJob(): Promise<ClaimedJob | undefined> {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query<DueJobRow>(
      "SELECT id,job_type,schedule_minutes FROM automation_jobs WHERE enabled = TRUE AND next_run_at <= NOW() ORDER BY next_run_at ASC, id ASC FOR UPDATE SKIP LOCKED LIMIT 1"
    );

    const row = result.rows[0];
    if (!row) {
      await client.query("COMMIT");
      return undefined;
    }

    await client.query(
      "UPDATE automation_jobs SET last_started_at = NOW(), next_run_at = NOW() + ($2::int * INTERVAL '1 minute'), last_status = 'running', last_message = 'Worker started', updated_at = NOW() WHERE id = $1",
      [row.id, row.schedule_minutes]
    );

    await client.query("COMMIT");

    return {
      id: row.id,
      jobType: row.job_type,
      scheduleMinutes: row.schedule_minutes
    };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function runDeadlineWatch(): Promise<JobOutcome> {
  const result = await pool.query<DeadlineRow>(
    "SELECT id,title,platform,deadline,score FROM opportunities WHERE deadline >= CURRENT_DATE AND deadline <= CURRENT_DATE + 21 ORDER BY deadline ASC, score DESC, id ASC"
  );

  const items: DeadlineOpportunity[] = result.rows.map((row) => ({
    id: row.id,
    title: row.title,
    platform: row.platform,
    deadline: dateOnly(row.deadline),
    score: row.score
  }));

  return deadlineWatchOutcome(items, 21);
}

async function runSubmissionIntegrity(): Promise<JobOutcome> {
  const result = await pool.query<ViolationRow>(
    "SELECT id,status,CASE WHEN status IN ('submitted','result') AND submitted_at IS NULL THEN 'submitted/result status without submitted_at' WHEN status = 'draft' AND submitted_at IS NOT NULL THEN 'draft status has submitted_at' WHEN award_usd IS NOT NULL AND COALESCE(result_status,'') <> 'won' THEN 'award recorded without won result' ELSE 'unknown lifecycle inconsistency' END AS issue FROM submissions WHERE (status IN ('submitted','result') AND submitted_at IS NULL) OR (status = 'draft' AND submitted_at IS NOT NULL) OR (award_usd IS NOT NULL AND COALESCE(result_status,'') <> 'won') ORDER BY id ASC"
  );

  const violations: SubmissionViolation[] = result.rows.map((row) => ({
    id: row.id,
    status: row.status,
    issue: row.issue
  }));

  return submissionIntegrityOutcome(violations);
}

async function pruneOldBackups(): Promise<number> {
  await mkdir(backupRoot, { recursive: true });

  const entries = await readdir(backupRoot, { withFileTypes: true });
  const directories = entries
    .filter(
      (entry) =>
        entry.isDirectory() && /^\d{8}T\d{9}Z$/.test(entry.name)
    )
    .map((entry) => entry.name)
    .sort()
    .reverse();

  const stale = directories.slice(backupRetentionCount);
  if (stale.length === 0) return 0;

  for (const key of stale) {
    await rm(join(backupRoot, key), { recursive: true, force: true });
  }

  await pool.query(
    "UPDATE backup_records SET status = 'pruned',database_file = NULL,files_archive = NULL,message = 'Pruned by retention policy' WHERE backup_key = ANY($1::text[])",
    [stale]
  );

  return stale.length;
}

async function runDailyBackup(): Promise<JobOutcome> {
  const key = backupKey();
  const directory = join(backupRoot, key);
  const databaseFile = join(directory, "database.dump");
  const filesArchive = join(directory, "files.tar.gz");
  const startedAt = new Date();
  const pgEnv = postgresCommandEnv();

  await mkdir(directory, { recursive: true });
  await mkdir(fileStoragePath, { recursive: true });

  await pool.query(
    "INSERT INTO backup_records (backup_key,status,database_file,files_archive,started_at,message) VALUES ($1,'running',$2,$3,$4,'Backup started')",
    [key, databaseFile, filesArchive, startedAt]
  );

  try {
    await execFile(
      "pg_dump",
      [
        "--format=custom",
        "--no-owner",
        "--no-privileges",
        "--file",
        databaseFile
      ],
      { env: pgEnv }
    );

    await execFile("pg_restore", ["--list", databaseFile], { env: pgEnv });

    await execFile(
      "tar",
      ["-czf", filesArchive, "-C", fileStoragePath, "."]
    );
    await execFile("tar", ["-tzf", filesArchive]);

    const [databaseStat, filesStat] = await Promise.all([
      stat(databaseFile),
      stat(filesArchive)
    ]);

    const finishedAt = new Date();

    await pool.query(
      "UPDATE backup_records SET status='completed',database_bytes=$2,files_bytes=$3,finished_at=$4,verified_at=$4,verification_status='verified',message='Backup completed and verified' WHERE backup_key=$1",
      [key, databaseStat.size, filesStat.size, finishedAt]
    );

    const prunedCount = await pruneOldBackups();

    return backupOutcome({
      backupKey: key,
      databaseBytes: databaseStat.size,
      filesBytes: filesStat.size,
      retentionCount: backupRetentionCount,
      prunedCount
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE backup_records SET status='failed',finished_at=NOW(),verification_status='failed',message=$2 WHERE backup_key=$1",
      [key, message]
    );

    throw error;
  }
}

type PatrollOpportunityRow = {
  id: string;
  source_id: string | null;
  external_key: string | null;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: Date | string;
  eligibility: string;
  automation: string;
  source_status: string | null;
  source_url: string | null;
};

function patrollCanonicalId(externalKey: string): string {
  return "scan-patroll-public-" + createHash("sha256")
    .update("patroll-public:" + externalKey)
    .digest("hex")
    .slice(0, 14);
}

function patrollPayload(contest: PatrollContest): Record<string, unknown> {
  return {
    sourceId: "patroll-public",
    externalKey: contest.externalKey,
    patentNumber: contest.patentNumber,
    platform: "PATROLL",
    title: contest.title,
    prizeUsd: contest.prizeUsd,
    deadline: contest.deadline,
    eligibility: contest.eligibility,
    automation: contest.automation,
    status: contest.status,
    sourceUrl: contest.sourceUrl,
    verificationStatus: "source-observed"
  };
}

function patrollHash(contest: PatrollContest): string {
  return createHash("sha256")
    .update(JSON.stringify(patrollPayload(contest)))
    .digest("hex");
}

function patrollChanges(
  current: PatrollOpportunityRow,
  contest: PatrollContest
): string[] {
  const changes: string[] = [];

  if (current.platform !== "PATROLL") changes.push("platform");
  if (current.title !== contest.title) changes.push("title");
  if (Number(current.prize_usd) !== contest.prizeUsd) changes.push("prizeUsd");
  if (dateOnly(current.deadline) !== contest.deadline) changes.push("deadline");
  if (current.eligibility !== contest.eligibility) changes.push("eligibility");
  if (current.automation !== contest.automation) changes.push("automation");
  if ((current.source_status ?? "") !== contest.status) changes.push("sourceStatus");
  if ((current.source_url ?? "") !== contest.sourceUrl) changes.push("sourceUrl");
  if (!current.source_id || !current.external_key) changes.unshift("sourceLink");

  return changes;
}

async function ingestPatrollContest(
  contest: PatrollContest
): Promise<"created" | "updated" | "unchanged"> {
  const client = await pool.connect();
  const observedAt = new Date();
  const hash = patrollHash(contest);
  const payload = patrollPayload(contest);

  try {
    await client.query("BEGIN");

    let existing = await client.query<PatrollOpportunityRow>(
      "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url FROM opportunities WHERE source_id='patroll-public' AND external_key=$1 LIMIT 1 FOR UPDATE",
      [contest.externalKey]
    );

    if (!existing.rows[0] && contest.patentNumber) {
      existing = await client.query<PatrollOpportunityRow>(
        "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url FROM opportunities WHERE platform='PATROLL' AND (id ILIKE $1 OR title ILIKE $1) ORDER BY score DESC LIMIT 1 FOR UPDATE",
        ["%" + contest.patentNumber + "%"]
      );
    }

    const current = existing.rows[0];
    let opportunityId: string;
    let action: "created" | "updated" | "unchanged";
    let changes: string[];

    if (!current) {
      opportunityId = patrollCanonicalId(contest.externalKey);
      action = "created";
      changes = [
        "platform",
        "title",
        "prizeUsd",
        "deadline",
        "eligibility",
        "automation",
        "sourceStatus",
        "sourceUrl"
      ];

      await client.query(
        "INSERT INTO opportunities (id,platform,title,prize_usd,deadline,eligibility,automation,score,status,source_status,source_id,external_key,source_url,first_seen_at,last_seen_at,source_hash,source_observed_at,verification_status) VALUES ($1,'PATROLL',$2,$3,$4,$5,$6,50,'triage',$7,'patroll-public',$8,$9,$10,$10,$11,$10,'source-observed')",
        [
          opportunityId,
          contest.title,
          contest.prizeUsd,
          contest.deadline,
          contest.eligibility,
          contest.automation,
          contest.status,
          contest.externalKey,
          contest.sourceUrl,
          observedAt,
          hash
        ]
      );
    } else {
      if (
        current.source_id &&
        (current.source_id !== "patroll-public" || current.external_key !== contest.externalKey)
      ) {
        throw new Error("patroll_existing_opportunity_link_conflict:" + current.id);
      }

      opportunityId = current.id;
      changes = patrollChanges(current, contest);
      action = changes.length > 0 ? "updated" : "unchanged";

      await client.query(
        "UPDATE opportunities SET source_id='patroll-public',external_key=$2,platform='PATROLL',title=$3,prize_usd=$4,deadline=$5,eligibility=$6,automation=$7,source_status=$8,source_url=$9,last_seen_at=$10,source_hash=$11,source_observed_at=$10,verification_status='source-observed',updated_at=CASE WHEN $12::boolean THEN NOW() ELSE updated_at END WHERE id=$1",
        [
          opportunityId,
          contest.externalKey,
          contest.title,
          contest.prizeUsd,
          contest.deadline,
          contest.eligibility,
          contest.automation,
          contest.status,
          contest.sourceUrl,
          observedAt,
          hash,
          changes.length > 0
        ]
      );
    }

    await client.query(
      "INSERT INTO opportunity_observations (source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload) VALUES ('patroll-public',$1,$2,$3,$4,$5,$6::jsonb,$7::jsonb) ON CONFLICT (source_id,external_key,snapshot_hash) DO NOTHING",
      [
        contest.externalKey,
        opportunityId,
        observedAt,
        hash,
        action === "created",
        JSON.stringify(changes),
        JSON.stringify(payload)
      ]
    );

    await client.query("COMMIT");
    return action;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function runPatrollPublicScan(): Promise<JobOutcome> {
  const sourceId = "patroll-public";

  await pool.query(
    "UPDATE opportunity_sources SET last_started_at=NOW(),last_status='running',last_message='Public browser scan started',updated_at=NOW() WHERE id=$1",
    [sourceId]
  );

  try {
    const result = await scanPatrollPublicContests();
    const counts = {
      created: 0,
      updated: 0,
      unchanged: 0,
      failed: 0
    };

    for (const contest of result.contests) {
      try {
        const action = await ingestPatrollContest(contest);
        counts[action] += 1;
      } catch (error) {
        counts.failed += 1;
        console.error(
          "PATROLL contest ingest failed",
          contest.sourceUrl,
          error
        );
      }
    }

    const message =
      result.contests.length + " active contest(s) parsed; " +
      counts.created + " new, " +
      counts.updated + " changed, " +
      counts.unchanged + " unchanged, " +
      counts.failed + " failed";

    const status = counts.failed > 0 ? "warning" : "ok";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '360 minutes',last_status=$2,last_message=$3,updated_at=NOW() WHERE id=$1",
      [sourceId, status, message]
    );

    return {
      status,
      message,
      summary: {
        sourceId,
        discoveredLinks: result.discoveredLinks,
        activeContests: result.contests.length,
        ...counts
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '360 minutes',last_status='error',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    throw error;
  }
}

type MetaculusOpportunityRow = {
  id: string;
  source_id: string | null;
  external_key: string | null;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: Date | string;
  eligibility: string;
  automation: string;
  source_status: string | null;
  source_url: string | null;
};

function metaculusCanonicalId(externalKey: string): string {
  return "scan-metaculus-public-" + createHash("sha256")
    .update("metaculus-public:" + externalKey)
    .digest("hex")
    .slice(0, 14);
}

function metaculusPayload(tournament: MetaculusTournament): Record<string, unknown> {
  return {
    sourceId: "metaculus-public",
    externalKey: tournament.externalKey,
    platform: "Metaculus FutureEval",
    title: tournament.title,
    prizeUsd: tournament.prizeUsd,
    deadline: tournament.deadline,
    eligibility: tournament.eligibility,
    automation: tournament.automation,
    status: tournament.status,
    sourceUrl: tournament.sourceUrl,
    verificationStatus: "source-observed"
  };
}

function metaculusHash(tournament: MetaculusTournament): string {
  return createHash("sha256")
    .update(JSON.stringify(metaculusPayload(tournament)))
    .digest("hex");
}

function metaculusChanges(
  current: MetaculusOpportunityRow,
  tournament: MetaculusTournament
): string[] {
  const changes: string[] = [];

  if (current.platform !== "Metaculus FutureEval") changes.push("platform");
  if (current.title !== tournament.title) changes.push("title");
  if (Number(current.prize_usd) !== tournament.prizeUsd) changes.push("prizeUsd");
  if (dateOnly(current.deadline) !== tournament.deadline) changes.push("deadline");
  if (current.eligibility !== tournament.eligibility) changes.push("eligibility");
  if (current.automation !== tournament.automation) changes.push("automation");
  if ((current.source_status ?? "") !== tournament.status) changes.push("sourceStatus");
  if ((current.source_url ?? "") !== tournament.sourceUrl) changes.push("sourceUrl");
  if (!current.source_id || !current.external_key) changes.unshift("sourceLink");

  return changes;
}

async function ingestMetaculusTournament(
  tournament: MetaculusTournament
): Promise<"created" | "updated" | "unchanged"> {
  const client = await pool.connect();
  const observedAt = new Date();
  const hash = metaculusHash(tournament);
  const payload = metaculusPayload(tournament);

  try {
    await client.query("BEGIN");

    let existing = await client.query<MetaculusOpportunityRow>(
      "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url FROM opportunities WHERE source_id='metaculus-public' AND external_key=$1 LIMIT 1 FOR UPDATE",
      [tournament.externalKey]
    );

    if (!existing.rows[0]) {
      existing = await client.query<MetaculusOpportunityRow>(
        "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url FROM opportunities WHERE id=$1 OR (platform='Metaculus FutureEval' AND lower(title)=lower($2)) ORDER BY score DESC LIMIT 1 FOR UPDATE",
        ["metaculus-futureeval-" + tournament.externalKey.replace(/-futureeval-/i, "-"), tournament.title]
      );
    }

    const current = existing.rows[0];
    let opportunityId: string;
    let action: "created" | "updated" | "unchanged";
    let changes: string[];

    if (!current) {
      opportunityId = metaculusCanonicalId(tournament.externalKey);
      action = "created";
      changes = [
        "platform",
        "title",
        "prizeUsd",
        "deadline",
        "eligibility",
        "automation",
        "sourceStatus",
        "sourceUrl"
      ];

      await client.query(
        "INSERT INTO opportunities (id,platform,title,prize_usd,deadline,eligibility,automation,score,status,source_status,source_id,external_key,source_url,first_seen_at,last_seen_at,source_hash,source_observed_at,verification_status) VALUES ($1,'Metaculus FutureEval',$2,$3,$4,$5,$6,50,'triage',$7,'metaculus-public',$8,$9,$10,$10,$11,$10,'source-observed')",
        [
          opportunityId,
          tournament.title,
          tournament.prizeUsd,
          tournament.deadline,
          tournament.eligibility,
          tournament.automation,
          tournament.status,
          tournament.externalKey,
          tournament.sourceUrl,
          observedAt,
          hash
        ]
      );
    } else {
      if (
        current.source_id &&
        (current.source_id !== "metaculus-public" || current.external_key !== tournament.externalKey)
      ) {
        throw new Error("metaculus_existing_opportunity_link_conflict:" + current.id);
      }

      opportunityId = current.id;
      changes = metaculusChanges(current, tournament);
      action = changes.length > 0 ? "updated" : "unchanged";

      await client.query(
        "UPDATE opportunities SET source_id='metaculus-public',external_key=$2,platform='Metaculus FutureEval',title=$3,prize_usd=$4,deadline=$5,eligibility=$6,automation=$7,source_status=$8,source_url=$9,last_seen_at=$10,source_hash=$11,source_observed_at=$10,verification_status='source-observed',updated_at=CASE WHEN $12::boolean THEN NOW() ELSE updated_at END WHERE id=$1",
        [
          opportunityId,
          tournament.externalKey,
          tournament.title,
          tournament.prizeUsd,
          tournament.deadline,
          tournament.eligibility,
          tournament.automation,
          tournament.status,
          tournament.sourceUrl,
          observedAt,
          hash,
          changes.length > 0
        ]
      );
    }

    await client.query(
      "INSERT INTO opportunity_observations (source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload) VALUES ('metaculus-public',$1,$2,$3,$4,$5,$6::jsonb,$7::jsonb) ON CONFLICT (source_id,external_key,snapshot_hash) DO NOTHING",
      [
        tournament.externalKey,
        opportunityId,
        observedAt,
        hash,
        action === "created",
        JSON.stringify(changes),
        JSON.stringify(payload)
      ]
    );

    await client.query("COMMIT");
    return action;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function runMetaculusPublicScan(): Promise<JobOutcome> {
  const sourceId = "metaculus-public";

  if (!process.env.METACULUS_TOKEN?.trim()) {
    const message =
      "METACULUS_TOKEN is not configured; owner bot/API token is required for official API scans";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '360 minutes',last_status='pending',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    return {
      status: "warning",
      message,
      summary: {
        sourceId,
        requiresMetaculusToken: true
      }
    };
  }

  await pool.query(
    "UPDATE opportunity_sources SET last_started_at=NOW(),last_status='running',last_message='Official FutureEval API scan started',updated_at=NOW() WHERE id=$1",
    [sourceId]
  );

  try {
    const result = await scanMetaculusFutureEvalTournaments();
    const counts = {
      created: 0,
      updated: 0,
      unchanged: 0,
      failed: 0
    };

    for (const tournament of result.tournaments) {
      try {
        const action = await ingestMetaculusTournament(tournament);
        counts[action] += 1;
      } catch (error) {
        counts.failed += 1;
        console.error(
          "Metaculus tournament ingest failed",
          tournament.sourceUrl,
          error
        );
      }
    }

    const message =
      result.tournaments.length + " open FutureEval tournament(s) parsed; " +
      counts.created + " new, " +
      counts.updated + " changed, " +
      counts.unchanged + " unchanged, " +
      counts.failed + " failed";

    const status = counts.failed > 0 ? "warning" : "ok";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '360 minutes',last_status=$2,last_message=$3,updated_at=NOW() WHERE id=$1",
      [sourceId, status, message]
    );

    return {
      status,
      message,
      summary: {
        sourceId,
        discoveredProjects: result.discoveredProjects,
        openFutureEvalTournaments: result.tournaments.length,
        ...counts
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '360 minutes',last_status='error',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    throw error;
  }
}

type WazokuOpportunityRow = {
  id: string;
  source_id: string | null;
  external_key: string | null;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: Date | string;
  eligibility: string;
  automation: string;
  source_status: string | null;
  source_url: string | null;
  status: string;
};

const knownWazokuIds: Record<string, string> = {
  "improving-wet-gas-measurement-accuracy-across-industry-standard-flow-meters":
    "wazoku-wetgas-2026",
  "technological-barrier-to-prevent-incorrect-aircraft-fueling-at-airport-terminals":
    "wazoku-aircraftfuel-2026"
};

function wazokuCanonicalId(externalKey: string): string {
  return "scan-wazoku-public-" + createHash("sha256")
    .update("wazoku-public:" + externalKey)
    .digest("hex")
    .slice(0, 14);
}

function wazokuPayload(challenge: WazokuChallenge): Record<string, unknown> {
  return {
    sourceId: "wazoku-public",
    externalKey: challenge.externalKey,
    platform: "InnoCentive/Wazoku",
    title: challenge.title,
    prizeUsd: challenge.prizeUsd,
    deadline: challenge.deadline,
    submissionCount: challenge.submissionCount,
    eligibility: challenge.eligibility,
    automation: challenge.automation,
    status: challenge.status,
    fitStatus: challenge.fitStatus,
    fitReasons: challenge.fitReasons,
    sourceUrl: challenge.sourceUrl,
    verificationStatus: "source-observed"
  };
}

function wazokuHash(challenge: WazokuChallenge): string {
  return createHash("sha256")
    .update(JSON.stringify(wazokuPayload(challenge)))
    .digest("hex");
}

function wazokuChanges(
  current: WazokuOpportunityRow,
  challenge: WazokuChallenge
): string[] {
  const changes: string[] = [];

  if (current.platform !== "InnoCentive/Wazoku") changes.push("platform");
  if (current.title !== challenge.title) changes.push("title");
  if (Number(current.prize_usd) !== challenge.prizeUsd) changes.push("prizeUsd");
  if (dateOnly(current.deadline) !== challenge.deadline) changes.push("deadline");
  if (current.eligibility !== challenge.eligibility) changes.push("eligibility");
  if (current.automation !== challenge.automation) changes.push("automation");
  if ((current.source_status ?? "") !== challenge.status) changes.push("sourceStatus");
  if ((current.source_url ?? "") !== challenge.sourceUrl) changes.push("sourceUrl");
  if (challenge.fitStatus === "blocked" && current.status !== "blocked") {
    changes.push("projectFit");
  }
  if (!current.source_id || !current.external_key) changes.unshift("sourceLink");

  return changes;
}

async function ingestWazokuChallenge(
  challenge: WazokuChallenge
): Promise<"created" | "updated" | "unchanged"> {
  const client = await pool.connect();
  const observedAt = new Date();
  const hash = wazokuHash(challenge);
  const payload = wazokuPayload(challenge);

  try {
    await client.query("BEGIN");

    let existing = await client.query<WazokuOpportunityRow>(
      "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url,status FROM opportunities WHERE source_id='wazoku-public' AND external_key=$1 LIMIT 1 FOR UPDATE",
      [challenge.externalKey]
    );

    const knownId = knownWazokuIds[challenge.externalKey];
    if (!existing.rows[0] && knownId) {
      existing = await client.query<WazokuOpportunityRow>(
        "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url,status FROM opportunities WHERE id=$1 LIMIT 1 FOR UPDATE",
        [knownId]
      );
    }

    const current = existing.rows[0];
    let opportunityId: string;
    let action: "created" | "updated" | "unchanged";
    let changes: string[];

    if (!current) {
      opportunityId = wazokuCanonicalId(challenge.externalKey);
      action = "created";
      changes = [
        "platform",
        "title",
        "prizeUsd",
        "deadline",
        "eligibility",
        "automation",
        "sourceStatus",
        "sourceUrl",
        "projectFit"
      ];

      await client.query(
        "INSERT INTO opportunities (id,platform,title,prize_usd,deadline,eligibility,automation,score,status,source_status,source_id,external_key,source_url,first_seen_at,last_seen_at,source_hash,source_observed_at,verification_status) VALUES ($1,'InnoCentive/Wazoku',$2,$3,$4,$5,$6,50,$7,$8,'wazoku-public',$9,$10,$11,$11,$12,$11,'source-observed')",
        [
          opportunityId,
          challenge.title,
          challenge.prizeUsd,
          challenge.deadline,
          challenge.eligibility,
          challenge.automation,
          challenge.fitStatus === "blocked" ? "blocked" : "triage",
          challenge.status,
          challenge.externalKey,
          challenge.sourceUrl,
          observedAt,
          hash
        ]
      );
    } else {
      if (
        current.source_id &&
        (current.source_id !== "wazoku-public" || current.external_key !== challenge.externalKey)
      ) {
        throw new Error("wazoku_existing_opportunity_link_conflict:" + current.id);
      }

      opportunityId = current.id;
      changes = wazokuChanges(current, challenge);
      action = changes.length > 0 ? "updated" : "unchanged";

      const nextInternalStatus =
        challenge.fitStatus === "blocked" ? "blocked" : current.status;

      await client.query(
        "UPDATE opportunities SET source_id='wazoku-public',external_key=$2,platform='InnoCentive/Wazoku',title=$3,prize_usd=$4,deadline=$5,eligibility=$6,automation=$7,source_status=$8,source_url=$9,last_seen_at=$10,source_hash=$11,source_observed_at=$10,verification_status='source-observed',status=$12,updated_at=CASE WHEN $13::boolean THEN NOW() ELSE updated_at END WHERE id=$1",
        [
          opportunityId,
          challenge.externalKey,
          challenge.title,
          challenge.prizeUsd,
          challenge.deadline,
          challenge.eligibility,
          challenge.automation,
          challenge.status,
          challenge.sourceUrl,
          observedAt,
          hash,
          nextInternalStatus,
          changes.length > 0
        ]
      );
    }

    await client.query(
      "INSERT INTO opportunity_observations (source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload) VALUES ('wazoku-public',$1,$2,$3,$4,$5,$6::jsonb,$7::jsonb) ON CONFLICT (source_id,external_key,snapshot_hash) DO NOTHING",
      [
        challenge.externalKey,
        opportunityId,
        observedAt,
        hash,
        action === "created",
        JSON.stringify(changes),
        JSON.stringify(payload)
      ]
    );

    await client.query("COMMIT");
    return action;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function runWazokuPublicScan(): Promise<JobOutcome> {
  const sourceId = "wazoku-public";

  await pool.query(
    "UPDATE opportunity_sources SET last_started_at=NOW(),last_status='running',last_message='Public Innocentive challenge scan started',updated_at=NOW() WHERE id=$1",
    [sourceId]
  );

  try {
    const result = await scanWazokuPublicChallenges();
    const counts = {
      created: 0,
      updated: 0,
      unchanged: 0,
      blocked: 0,
      review: 0,
      eligible: 0,
      failed: 0
    };

    for (const challenge of result.challenges) {
      counts[challenge.fitStatus] += 1;

      try {
        const action = await ingestWazokuChallenge(challenge);
        counts[action] += 1;
      } catch (error) {
        counts.failed += 1;
        console.error("Wazoku challenge ingest failed", challenge.sourceUrl, error);
      }
    }

    const message =
      result.challenges.length + " active cash challenge(s) parsed; " +
      counts.eligible + " eligible, " +
      counts.review + " review, " +
      counts.blocked + " blocked; " +
      counts.created + " new, " +
      counts.updated + " changed, " +
      counts.unchanged + " unchanged, " +
      counts.failed + " failed";

    const status = counts.failed > 0 ? "warning" : "ok";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status=$2,last_message=$3,updated_at=NOW() WHERE id=$1",
      [sourceId, status, message]
    );

    return {
      status,
      message,
      summary: {
        sourceId,
        discoveredLinks: result.discoveredLinks,
        activeCashChallenges: result.challenges.length,
        ...counts
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status='error',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    throw error;
  }
}

async function runDrivenDataPublicScan(): Promise<JobOutcome> {
  const sourceId = "drivendata-public";

  await pool.query(
    "UPDATE opportunity_sources SET last_started_at=NOW(),last_status='running',last_message='DrivenData active prize scan started',updated_at=NOW() WHERE id=$1",
    [sourceId]
  );

  try {
    const result = await scanDrivenDataPrizeCompetitions();
    const counts = { created: 0, updated: 0, unchanged: 0, blocked: 0, review: 0, eligible: 0, failed: 0 };

    for (const competition of result.competitions) {
      counts[competition.fitStatus] += 1;

      try {
        const ingested = await ingestWorkerScannedOpportunity(pool, {
          sourceId,
          externalKey: competition.externalKey,
          platform: "DrivenData",
          title: competition.title,
          prizeUsd: competition.prizeUsd,
          deadline: competition.deadline,
          eligibility: competition.eligibility,
          automation: competition.automation,
          sourceStatus: competition.status,
          sourceUrl: competition.sourceUrl,
          initialStatus: competition.fitStatus === "blocked" ? "blocked" : "triage",
          extra: {
            fitStatus: competition.fitStatus,
            fitReasons: competition.fitReasons
          }
        });
        counts[ingested.action] += 1;
      } catch (error) {
        counts.failed += 1;
        console.error("DrivenData competition ingest failed", competition.sourceUrl, error);
      }
    }

    const message =
      result.competitions.length + " active prize competition(s) parsed; " +
      counts.eligible + " eligible, " +
      counts.review + " review, " +
      counts.blocked + " blocked; " +
      counts.created + " new, " +
      counts.updated + " changed, " +
      counts.unchanged + " unchanged, " +
      counts.failed + " failed";

    const status = counts.failed > 0 ? "warning" : "ok";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status=$2,last_message=$3,updated_at=NOW() WHERE id=$1",
      [sourceId, status, message]
    );

    return {
      status,
      message,
      summary: {
        sourceId,
        discoveredCards: result.discoveredCards,
        activePrizeCompetitions: result.competitions.length,
        ...counts
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status='error',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    throw error;
  }
}

async function runDevpostPublicScan(): Promise<JobOutcome> {
  const sourceId = "devpost-public";

  await pool.query(
    "UPDATE opportunity_sources SET last_started_at=NOW(),last_status='running',last_message='Devpost high-value public scan started',updated_at=NOW() WHERE id=$1",
    [sourceId]
  );

  try {
    const result = await scanDevpostHighValueHackathons();
    const counts = { created: 0, updated: 0, unchanged: 0, review: 0, failed: 0 };

    for (const hackathon of result.hackathons) {
      counts.review += 1;

      try {
        const ingested = await ingestWorkerScannedOpportunity(pool, {
          sourceId,
          externalKey: hackathon.externalKey,
          platform: "Devpost",
          title: hackathon.title,
          prizeUsd: hackathon.prizeUsd,
          deadline: hackathon.deadline,
          eligibility: hackathon.eligibility,
          automation: hackathon.automation,
          sourceStatus: hackathon.status,
          sourceUrl: hackathon.sourceUrl,
          initialStatus: "triage",
          extra: {
            fitStatus: hackathon.fitStatus,
            fitReasons: hackathon.fitReasons,
            selectiveMinimumPrizeUsd: 20000
          }
        });
        counts[ingested.action] += 1;
      } catch (error) {
        counts.failed += 1;
        console.error("Devpost hackathon ingest failed", hackathon.sourceUrl, error);
      }
    }

    const message =
      result.hackathons.length + " active high-value online hackathon(s) parsed; " +
      counts.created + " new, " +
      counts.updated + " changed, " +
      counts.unchanged + " unchanged, " +
      counts.failed + " failed";

    const status = counts.failed > 0 ? "warning" : "ok";

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status=$2,last_message=$3,updated_at=NOW() WHERE id=$1",
      [sourceId, status, message]
    );

    return {
      status,
      message,
      summary: {
        sourceId,
        discoveredCards: result.discoveredCards,
        activeHighValueHackathons: result.hackathons.length,
        ...counts
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    await pool.query(
      "UPDATE opportunity_sources SET last_finished_at=NOW(),next_scan_at=NOW() + INTERVAL '720 minutes',last_status='error',last_message=$2,updated_at=NOW() WHERE id=$1",
      [sourceId, message]
    );

    throw error;
  }
}

async function executeJob(job: ClaimedJob): Promise<JobOutcome> {
  if (job.jobType === "deadline-watch") {
    return runDeadlineWatch();
  }

  if (job.jobType === "submission-integrity") {
    return runSubmissionIntegrity();
  }

  if (job.jobType === "daily-backup") {
    return runDailyBackup();
  }

  if (job.jobType === "patroll-public-scan") {
    return runPatrollPublicScan();
  }

  if (job.jobType === "metaculus-public-scan") {
    return runMetaculusPublicScan();
  }

  if (job.jobType === "wazoku-public-scan") {
    return runWazokuPublicScan();
  }

  if (job.jobType === "drivendata-public-scan") {
    return runDrivenDataPublicScan();
  }

  if (job.jobType === "devpost-public-scan") {
    return runDevpostPublicScan();
  }

  return {
    status: "warning",
    message: "Unknown automation job type: " + job.jobType,
    summary: {
      jobType: job.jobType
    }
  };
}

async function finishJob(
  job: ClaimedJob,
  startedAt: Date,
  status: string,
  message: string,
  summary: Record<string, unknown>
): Promise<void> {
  const finishedAt = new Date();

  await pool.query(
    "INSERT INTO automation_runs (job_id,started_at,finished_at,status,message,summary) VALUES ($1,$2,$3,$4,$5,$6::jsonb)",
    [job.id, startedAt, finishedAt, status, message, JSON.stringify(summary)]
  );

  await pool.query(
    "UPDATE automation_jobs SET last_finished_at = $2,last_status = $3,last_message = $4,updated_at = NOW() WHERE id = $1",
    [job.id, finishedAt, status, message]
  );
}

async function runOneDueJob(): Promise<boolean> {
  const job = await claimDueJob();
  if (!job) return false;

  const startedAt = new Date();

  try {
    const outcome = await executeJob(job);
    await finishJob(job, startedAt, outcome.status, outcome.message, outcome.summary);
    console.log(job.id + ": " + outcome.status + " — " + outcome.message);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await finishJob(job, startedAt, "error", message, { error: message });
    console.error(job.id + ": error — " + message);
  }

  return true;
}

async function poll(): Promise<void> {
  if (stopping) return;

  try {
    let processed = 0;
    while (processed < 10 && await runOneDueJob()) {
      processed += 1;
    }
  } catch (error) {
    console.error("Automation poll failed", error);
  }
}

async function shutdown(signal: string): Promise<void> {
  if (stopping) return;
  stopping = true;
  console.log("Received " + signal + "; shutting down worker.");
  await pool.end();
}

console.log("Global Prize automation worker started; poll interval " + pollSeconds + "s");
await poll();

const timer = setInterval(() => {
  void poll();
}, pollSeconds * 1000);

process.on("SIGTERM", () => {
  clearInterval(timer);
  void shutdown("SIGTERM");
});

process.on("SIGINT", () => {
  clearInterval(timer);
  void shutdown("SIGINT");
});
