import assert from "node:assert/strict";
import test from "node:test";
import {
  workerChangedFields,
  type WorkerScannedOpportunity
} from "./scanner-ingestion.js";

const item: WorkerScannedOpportunity = {
  sourceId: "devpost-public",
  externalKey: "example",
  platform: "Devpost",
  title: "Example Challenge",
  prizeUsd: 50000,
  deadline: "2026-10-30",
  eligibility: "Review rules",
  automation: "AI-assisted work requires rules review",
  sourceStatus: "active",
  sourceUrl: "https://example.devpost.com/",
  initialStatus: "triage",
  extra: {
    fitStatus: "review",
    selectiveMinimumPrizeUsd: 20000
  }
};

const current = {
  id: "scan-devpost-public-example",
  source_id: item.sourceId,
  external_key: item.externalKey,
  platform: item.platform,
  title: item.title,
  prize_usd: item.prizeUsd,
  deadline: item.deadline,
  eligibility: item.eligibility,
  automation: item.automation,
  source_status: item.sourceStatus,
  source_url: item.sourceUrl,
  source_hash: "stable-hash"
};

test("scanner ingestion treats identical material snapshot as unchanged", () => {
  assert.deepEqual(workerChangedFields(current, item, "stable-hash"), []);
});

test("scanner ingestion reports a changed source snapshot when payload hash changes", () => {
  assert.deepEqual(
    workerChangedFields(current, item, "new-hash"),
    ["sourceSnapshot"]
  );
});
