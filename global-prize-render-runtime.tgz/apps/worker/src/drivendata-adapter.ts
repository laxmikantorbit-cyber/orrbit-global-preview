import { htmlToText } from "./wazoku-adapter.js";

export type DrivenDataFitStatus = "eligible" | "review" | "blocked";

export type DrivenDataCompetition = {
  externalKey: string;
  sourceUrl: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  status: "active" | "closed";
  fitStatus: DrivenDataFitStatus;
  fitReasons: string[];
  eligibility: string;
  automation: string;
};

export type DrivenDataScanResult = {
  competitions: DrivenDataCompetition[];
  discoveredCards: number;
};

type PrizeCard = {
  sourceUrl: string;
  title: string;
  prizeUsd: number;
  deadlineHint: string | null;
};

type FetchLike = (
  input: string | URL | Request,
  init?: RequestInit
) => Promise<Response>;

function decode(value: string): string {
  return value
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#039;|&apos;/gi, "'")
    .replace(/&nbsp;|&#160;/gi, " ");
}

function monthNumber(name: string): string {
  const months: Record<string, string> = {
    jan: "01", feb: "02", mar: "03", apr: "04",
    may: "05", jun: "06", jul: "07", aug: "08",
    sep: "09", oct: "10", nov: "11", dec: "12"
  };
  const value = months[name.replace(".", "").slice(0, 3).toLowerCase()];
  if (!value) throw new Error("drivendata_month_invalid:" + name);
  return value;
}

function parseMonthDate(value: string): string {
  const match = value.trim().match(/^([A-Za-z]+)\.?\s+(\d{1,2}),?\s+(\d{4})$/);
  if (!match) throw new Error("drivendata_date_invalid:" + value);
  return `${match[3]}-${monthNumber(match[1])}-${match[2].padStart(2, "0")}`;
}

function externalKey(sourceUrl: string): string {
  const url = new URL(sourceUrl);
  const parts = url.pathname.split("/").filter(Boolean);

  if (/drivendata\.org$/i.test(url.hostname) && parts[0] === "competitions" && /^\d+$/.test(parts[1] ?? "")) {
    return "competition-" + parts[1];
  }

  if (parts[0] === "competitions" && parts[1] === "group" && parts[2]) {
    return parts[2];
  }

  return parts.at(-1) ?? "";
}

export function extractDrivenDataPrizeCards(html: string): PrizeCard[] {
  const chunks = html.split(/(?=<div class="[^"]*panel-container[^"]*active-comp[^"]*prize-comp)/gi);
  const cards: PrizeCard[] = [];

  for (const chunk of chunks) {
    if (!/panel-container[^"]*active-comp[^"]*prize-comp/i.test(chunk)) continue;

    const attributeBlock = chunk.match(/^<div\b([^>]*)>/i)?.[1] ?? "";
    const prizeMatch = attributeBlock.match(/data-total_prize_purse="([\d.]+)"/i);
    if (!prizeMatch) continue;

    const prizeUsd = Number(prizeMatch[1]);
    if (!Number.isFinite(prizeUsd) || prizeUsd <= 0) continue;

    const titleBlock = chunk.match(
      /panel-competition-title[\s\S]*?<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i
    );
    if (!titleBlock) continue;

    const sourceUrl = new URL(decode(titleBlock[1]), "https://www.drivendata.org/competitions/").toString();
    const title = htmlToText(titleBlock[2]).trim();
    if (!title) continue;

    const text = htmlToText(chunk.slice(0, 8000));
    const closes = text.match(/Closes\s+([A-Za-z]+\.?\s+\d{1,2},?\s+\d{4})/i);

    cards.push({
      sourceUrl,
      title,
      prizeUsd: Math.round(prizeUsd),
      deadlineHint: closes ? parseMonthDate(closes[1]) : null
    });
  }

  return cards;
}

function detailDeadline(text: string, hint: string | null): string {
  const match =
    text.match(/Competition End Date:?\s*([A-Za-z]+\.?\s+\d{1,2},\s+\d{4})/i) ??
    text.match(/Closes\s+([A-Za-z]+\.?\s+\d{1,2},?\s+\d{4})/i);

  if (match) return parseMonthDate(match[1]);
  if (hint) return hint;
  throw new Error("drivendata_deadline_missing");
}

export function parseDrivenDataCompetition(
  card: PrizeCard,
  detailHtml: string,
  now = new Date()
): DrivenDataCompetition {
  const text = htmlToText(detailHtml);
  const key = externalKey(card.sourceUrl);
  if (!key) throw new Error("drivendata_external_key_missing");

  const deadline = detailDeadline(text, card.deadlineHint);
  const today = now.toISOString().slice(0, 10);
  const status: DrivenDataCompetition["status"] =
    deadline < today ? "closed" : "active";

  const usRestricted =
    /must be U\.S\. citizens or permanent residents/i.test(text) ||
    /Individual competitors must be U\.S\. citizens or permanent residents/i.test(text) ||
    /Entity shall be incorporated in and maintain a primary place of business in the US/i.test(text);

  const hostedModelDataProhibited =
    /may not send competition data to third-party hosted models, model APIs, or inference services/i.test(text) ||
    /may not use tools like Codex and ChatGPT that store or retain uploaded data/i.test(text);

  const externalRules =
    !/drivendata\.org$/i.test(new URL(card.sourceUrl).hostname);

  const fitReasons: string[] = [];
  if (usRestricted) {
    fitReasons.push("monetary prize eligibility is restricted to qualifying U.S. participants/entities");
  }
  if (hostedModelDataProhibited) {
    fitReasons.push("competition data cannot be sent to third-party hosted model/API services; local execution is required");
  }
  if (externalRules) {
    fitReasons.push("competition is hosted on an external DrivenData-powered platform; track rules must be rechecked before submission");
  }

  const fitStatus: DrivenDataFitStatus =
    usRestricted
      ? "blocked"
      : hostedModelDataProhibited || externalRules
        ? "review"
        : "eligible";

  const eligibility =
    fitStatus === "blocked"
      ? "Project fit blocked: " + fitReasons.join("; ") + "."
      : fitStatus === "review"
        ? "Project fit requires review: " + fitReasons.join("; ") + "."
        : "Project fit eligible for technical triage; verify current competition rules before submission.";

  const automation = hostedModelDataProhibited
    ? "Local-only ML execution for competition data; do not upload competition data to ChatGPT/OpenAI/Anthropic/other hosted model APIs"
    : "Automated local ML experimentation is allowed only within current competition data, external-data, reproducibility, and submission rules";

  return {
    externalKey: key,
    sourceUrl: card.sourceUrl,
    title: card.title,
    prizeUsd: card.prizeUsd,
    deadline,
    status,
    fitStatus,
    fitReasons,
    eligibility,
    automation
  };
}

async function fetchText(fetchImpl: FetchLike, url: string): Promise<string> {
  const response = await fetchImpl(url, {
    headers: {
      accept: "text/html,application/xhtml+xml",
      "user-agent": "GlobalPrizeResearchEngine/1.0"
    },
    signal: AbortSignal.timeout(30_000)
  });

  if (!response.ok) {
    throw new Error("drivendata_fetch_failed:" + response.status + ":" + url);
  }

  return await response.text();
}

export async function scanDrivenDataPrizeCompetitions(
  fetchImpl: FetchLike = fetch,
  now = new Date()
): Promise<DrivenDataScanResult> {
  const listingUrl = "https://www.drivendata.org/competitions/";
  const listingHtml = await fetchText(fetchImpl, listingUrl);
  const cards = extractDrivenDataPrizeCards(listingHtml);

  if (cards.length === 0) {
    throw new Error("drivendata_no_active_prize_cards");
  }

  const competitions: DrivenDataCompetition[] = [];

  for (const card of cards.slice(0, 20)) {
    try {
      let detailHtml = await fetchText(fetchImpl, card.sourceUrl);

      if (externalKey(card.sourceUrl) === "lost-in-transcription") {
        const trackUrl =
          "https://competitions.mozilladatacollective.com/competitions/2/lost-in-transcription-sp-en/";
        const trackRules = await fetchText(fetchImpl, trackUrl);
        detailHtml += "\n" + trackRules;
      }

      const competition = parseDrivenDataCompetition(card, detailHtml, now);
      if (competition.status === "active") competitions.push(competition);
    } catch {
      // Skip cards whose current public detail/rules contract cannot be verified.
    }
  }

  if (competitions.length === 0) {
    throw new Error("drivendata_no_active_prize_competitions_parsed");
  }

  return {
    competitions,
    discoveredCards: cards.length
  };
}
