import assert from "node:assert/strict";
import test from "node:test";
import {
  parseMetaculusFutureEvalProject,
  scanMetaculusFutureEvalTournaments
} from "./metaculus-adapter.js";

const fall2026 = {
  id: 33100,
  slug: "fall-futureeval-2026",
  name: "Fall 2026 FutureEval Bot Tournament",
  prize_pool: "50000.00",
  start_date: "2026-09-28T00:00:00Z",
  close_date: "2027-01-06T23:59:59Z",
  is_ongoing: true,
  bot_leaderboard_status: "bots_only"
};

test("Metaculus project parser extracts prize-eligible Fall 2026 FutureEval fields", () => {
  const result = parseMetaculusFutureEvalProject(
    fall2026,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.externalKey, "fall-futureeval-2026");
  assert.equal(result.prizeUsd, 50000);
  assert.equal(result.deadline, "2027-01-06");
  assert.equal(result.status, "upcoming");
  assert.match(result.eligibility, /bots_only/);
});

test("Metaculus project parser marks tournament active after start", () => {
  const result = parseMetaculusFutureEvalProject(
    fall2026,
    new Date("2026-10-01T00:00:00Z")
  );

  assert.equal(result.status, "active");
});

test("Metaculus project parser rejects a tournament where bots cannot win", () => {
  assert.throws(
    () => parseMetaculusFutureEvalProject({
      ...fall2026,
      bot_leaderboard_status: "exclude_and_show"
    }),
    /metaculus_bots_not_prize_eligible/
  );
});

test("Metaculus API scanner requires a token", async () => {
  await assert.rejects(
    scanMetaculusFutureEvalTournaments(async () => {
      throw new Error("fetch should not run without token");
    }, ""),
    /metaculus_token_not_configured/
  );
});

test("Metaculus API scanner filters to open prize-eligible FutureEval projects", async () => {
  const fakeFetch = async () => new Response(JSON.stringify([
    fall2026,
    {
      id: 33021,
      slug: "metaculus-cup-fall-2026",
      name: "Metaculus Cup Fall 2026",
      prize_pool: "5000.00",
      start_date: "2026-08-28T00:00:00Z",
      close_date: "2027-01-01T00:00:00Z",
      bot_leaderboard_status: "exclude_and_show"
    },
    {
      id: 33022,
      slug: "summer-futureeval-2026",
      name: "Summer 2026 FutureEval Bot Tournament",
      prize_pool: "50000.00",
      start_date: "2026-05-01T00:00:00Z",
      close_date: "2026-09-16T00:00:00Z",
      bot_leaderboard_status: "bots_only"
    }
  ]), {
    status: 200,
    headers: { "content-type": "application/json" }
  });

  const result = await scanMetaculusFutureEvalTournaments(fakeFetch, "test-token");

  assert.equal(result.discoveredProjects, 3);
  assert.equal(result.tournaments.length, 1);
  assert.equal(result.tournaments[0]?.externalKey, "fall-futureeval-2026");
});
