import assert from "node:assert/strict";
import test from "node:test";
import {
  backupOutcome,
  deadlineWatchOutcome,
  submissionIntegrityOutcome
} from "./jobs.js";

test("deadline watch reports due opportunity count without predicting wins", () => {
  const result = deadlineWatchOutcome([
    {
      id: "arc",
      title: "Arc Link",
      platform: "PATROLL",
      deadline: "2026-10-10",
      score: 92
    }
  ]);

  assert.equal(result.status, "ok");
  assert.match(result.message, /1 opportunity due within 21 days/);
  assert.deepEqual(result.summary, {
    windowDays: 21,
    count: 1,
    items: [
      {
        id: "arc",
        title: "Arc Link",
        platform: "PATROLL",
        deadline: "2026-10-10",
        score: 92
      }
    ]
  });
});

test("submission integrity is ok when no lifecycle violations exist", () => {
  const result = submissionIntegrityOutcome([]);
  assert.equal(result.status, "ok");
  assert.equal(result.summary.violations, 0);
});

test("submission integrity warns on inconsistent external-submission state", () => {
  const result = submissionIntegrityOutcome([
    {
      id: "bad-submission",
      status: "submitted",
      issue: "submitted status without submitted_at"
    }
  ]);

  assert.equal(result.status, "warning");
  assert.equal(result.summary.violations, 1);
  assert.match(result.message, /1 submission lifecycle violation detected/);
});


test("backup outcome records verified sizes and retention pruning", () => {
  const result = backupOutcome({
    backupKey: "20260923T050000Z",
    databaseBytes: 4096,
    filesBytes: 8192,
    retentionCount: 10,
    prunedCount: 2
  });

  assert.equal(result.status, "ok");
  assert.equal(result.summary.verified, true);
  assert.equal(result.summary.retentionCount, 10);
  assert.equal(result.summary.prunedCount, 2);
  assert.match(result.message, /completed and verified/);
});
