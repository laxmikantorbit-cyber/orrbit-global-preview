import puppeteer from "puppeteer-core";

export type PatrollContest = {
  externalKey: string;
  sourceUrl: string;
  title: string;
  patentNumber: string | null;
  prizeUsd: number;
  deadline: string;
  status: "active" | "finished";
  eligibility: string;
  automation: string;
};

export type PatrollScanResult = {
  contests: PatrollContest[];
  discoveredLinks: number;
};

export function parsePatrollContest(
  sourceUrl: string,
  bodyText: string,
  headingText = ""
): PatrollContest {
  const url = new URL(sourceUrl);
  const externalKey = url.pathname.split("/").filter(Boolean).at(-1) ?? "";
  if (!externalKey) throw new Error("patroll_external_key_missing");

  const text = bodyText.replace(/\r/g, "");
  const heading = headingText.trim() || firstUsefulLine(text);

  const prizeMatch = text.match(/Prize:\s*\$\s*([\d,]+)/i);
  if (!prizeMatch) throw new Error("patroll_prize_missing");
  const prizeUsd = Number(prizeMatch[1].replace(/,/g, ""));
  if (!Number.isFinite(prizeUsd) || prizeUsd < 0) {
    throw new Error("patroll_prize_invalid");
  }

  const endMatch = text.match(/End Date:\s*([^\n]+)/i);
  if (!endMatch) throw new Error("patroll_end_date_missing");

  const endDate = new Date(endMatch[1].trim());
  if (Number.isNaN(endDate.getTime())) {
    throw new Error("patroll_end_date_invalid");
  }

  const patentMatch = (heading + "\n" + text).match(/US[-\s]?(\d{7,8})[-\s]?B2/i);
  const patentNumber = patentMatch?.[1] ?? null;

  const active = /(^|\n)\s*Active\s*(\n|$)/i.test(text);
  const finished = /(^|\n)\s*Finished\s*(\n|$)/i.test(text);

  if (!active && !finished) {
    throw new Error("patroll_status_missing");
  }

  const automation = /Pearl|AI-Assisted Claim Chart/i.test(text)
    ? "Pearl AI-assisted claim chart required; verify current contest rules before submission"
    : "Verify current PATROLL automation and submission rules before submission";

  return {
    externalKey,
    sourceUrl,
    title: heading,
    patentNumber,
    prizeUsd,
    deadline: endDate.toISOString().slice(0, 10),
    status: active ? "active" : "finished",
    eligibility: "PATROLL researcher account; verify contest-specific eligibility before submission",
    automation
  };
}

function firstUsefulLine(text: string): string {
  const lines = text
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);

  const preferred = lines.find((line) => /US[-\s]?\d{7,8}[-\s]?B2/i.test(line));
  if (preferred) return preferred;

  const fallback = lines.find(
    (line) =>
      !/^(Active|Finished|Overview|Rules|Known References|Support|Login)$/i.test(line) &&
      !/^Prize:/i.test(line)
  );

  if (!fallback) throw new Error("patroll_title_missing");
  return fallback;
}

function browserExecutable(): string {
  return process.env.CHROMIUM_PATH ?? "/usr/bin/chromium-browser";
}

async function configureFastPage(page: import("puppeteer-core").Page): Promise<void> {
  await page.setViewport({ width: 1365, height: 900 });
  await page.setUserAgent(
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
    "(KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"
  );
  await page.setRequestInterception(true);
  page.on("request", (request) => {
    const type = request.resourceType();
    if (["image", "media", "font", "stylesheet"].includes(type)) {
      void request.abort();
      return;
    }
    void request.continue();
  });
}

async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  task: (item: T) => Promise<R>
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;

  async function worker(): Promise<void> {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await task(items[index]);
    }
  }

  await Promise.all(
    Array.from(
      { length: Math.min(Math.max(concurrency, 1), items.length) },
      () => worker()
    )
  );

  return results;
}

export async function scanPatrollPublicContests(): Promise<PatrollScanResult> {
  const listingUrl =
    process.env.PATROLL_LISTING_URL ??
    "https://patroll.unifiedpatents.com/contests?category=all";

  const browser = await puppeteer.launch({
    executablePath: browserExecutable(),
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu"
    ]
  });

  try {
    const listingPage = await browser.newPage();
    await configureFastPage(listingPage);

    await listingPage.goto(listingUrl, {
      waitUntil: "domcontentloaded",
      timeout: 25_000
    });

    try {
      await listingPage.waitForSelector('a[href*="/contests/"]', { timeout: 12_000 });
    } catch {
      // Continue to extraction so the caller gets a precise empty-list failure.
    }

    const links = await listingPage.$$eval('a[href*="/contests/"]', (anchors) =>
      anchors
        .map((anchor) => (anchor as HTMLAnchorElement).href)
        .filter(Boolean)
    );
    await listingPage.close();

    const unique = [...new Set(links)]
      .filter((href) => /^https:\/\/patroll\.unifiedpatents\.com\/contests\/[^/?#]+/i.test(href))
      .slice(0, 30);

    if (unique.length === 0) {
      throw new Error("patroll_no_contest_links_discovered");
    }

    const parsed = await mapWithConcurrency(unique, 3, async (sourceUrl) => {
      const page = await browser.newPage();
      await configureFastPage(page);

      try {
        await page.goto(sourceUrl, {
          waitUntil: "domcontentloaded",
          timeout: 25_000
        });

        try {
          await page.waitForFunction(
            () => document.body?.innerText.includes("Prize:"),
            { timeout: 8_000 }
          );
        } catch {
          // Parser below will decide whether the public detail contract is usable.
        }

        const detail = await page.evaluate(() => ({
          bodyText: document.body?.innerText ?? "",
          headingText: document.querySelector("h1")?.textContent ?? ""
        }));

        try {
          const contest = parsePatrollContest(
            sourceUrl,
            detail.bodyText,
            detail.headingText
          );
          return contest.status === "active" ? contest : null;
        } catch {
          return null;
        }
      } finally {
        await page.close();
      }
    });

    const contests = parsed.filter((item): item is PatrollContest => item !== null);

    if (contests.length === 0) {
      throw new Error("patroll_no_active_contests_parsed");
    }

    return {
      contests,
      discoveredLinks: unique.length
    };
  } finally {
    await browser.close();
  }
}
