import assert from "node:assert/strict";
import test from "node:test";
import {
  parseDevpostRenderedCard,
  parseDevpostRenderedCards
} from "./devpost-adapter.js";

const amazon = {
  href: "https://amazonappdev2026.devpost.com/?ref_feature=challenge&ref_medium=discover",
  text: [
    "Online",
    "Build, Ship, Shape: Amazon Developer Hackathon",
    "about 1 month left",
    "Aug 31 - Oct 23, 2026",
    "$138,000 in prizes",
    "11956 participants",
    "Amazon",
    "Managed by Devpost",
    "Machine Learning/AI Open Ended Productivity"
  ].join("\n")
};

const nebius = {
  href: "https://nebiusglobalaihackathon.devpost.com/?ref_feature=challenge&ref_medium=discover",
  text: [
    "Online",
    "Nebius x NVIDIA Global AI Hackathon",
    "about 1 month left",
    "Aug 26 - Oct 30, 2026",
    "$50,000 in prizes",
    "10651 participants",
    "nebius",
    "Managed by Devpost"
  ].join("\n")
};

const ended = {
  href: "https://webmcp.devpost.com/?ref_feature=challenge&ref_medium=discover",
  text: [
    "Online",
    "The WebMCP Challenge",
    "Ended",
    "Aug 25 - Sep 04, 2026",
    "$35,000 in prizes",
    "7070 participants",
    "OpenAI",
    "Managed by Devpost"
  ].join("\n")
};

test("Devpost parser extracts active managed online hackathon fields", () => {
  const item = parseDevpostRenderedCard(
    amazon,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.ok(item);
  assert.equal(item.externalKey, "amazonappdev2026");
  assert.equal(item.prizeUsd, 138000);
  assert.equal(item.deadline, "2026-10-23");
  assert.equal(item.participants, 11956);
  assert.equal(item.status, "active");
  assert.equal(item.fitStatus, "review");
});

test("Devpost parser rejects ended hackathons from active queue", () => {
  const items = parseDevpostRenderedCards(
    [amazon, ended],
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(items.length, 1);
  assert.equal(items[0]?.externalKey, "amazonappdev2026");
});

test("Devpost selective lane keeps current high-value active cards", () => {
  const items = parseDevpostRenderedCards(
    [amazon, nebius, ended],
    new Date("2026-09-23T00:00:00Z"),
    20_000
  );

  assert.deepEqual(items.map((item) => item.prizeUsd), [138000, 50000]);
  assert.ok(items.every((item) => item.fitStatus === "review"));
});

test("Devpost threshold filters low-value cards", () => {
  const low = {
    ...amazon,
    href: "https://smallhack.devpost.com/",
    text: amazon.text.replace("$138,000", "$8,000")
  };

  const item = parseDevpostRenderedCard(
    low,
    new Date("2026-09-23T00:00:00Z"),
    20_000
  );

  assert.equal(item, null);
});
