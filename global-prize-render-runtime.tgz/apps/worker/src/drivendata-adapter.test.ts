import assert from "node:assert/strict";
import test from "node:test";
import {
  extractDrivenDataPrizeCards,
  parseDrivenDataCompetition,
  scanDrivenDataPrizeCompetitions
} from "./drivendata-adapter.js";

const listingHtml = `
<div class="d-flex panel-container active-comp prize-comp" data-total_prize_purse="20000.0">
  <h3 class="panel-competition-title"><a href="https://competitions.mozilladatacollective.com/competitions/group/lost-in-transcription/">Lost in Transcription: Advancing Speech Recognition for Underserved Linguistic Contexts</a></h3>
  <div>$20,000 in prizes</div><div>Closes Oct 2, 2026</div>
</div>
<div class="d-flex panel-container active-comp prize-comp" data-total_prize_purse="300000.0">
  <h3 class="panel-competition-title"><a href="/competitions/306/competition-doe-gems/page/966/">The Geologic Enhanced Mapping System (GEMS) Prize Challenge</a></h3>
  <div>$300,000 in prizes</div><div>2 months left</div>
</div>`;

const lostRules = `
<h1>Lost in Transcription: Spanish-English Track</h1>
<p>Competition End Date: Oct. 2, 2026, midnight UTC</p>
<p>The Competition is open to all natural persons who are a legal resident of a country within the Territory.</p>
<p>Legal entities and organizations are not eligible for entry. There is no purchase necessary.</p>
<p>Participants may not send competition data to third-party hosted models, model APIs, or inference services (e.g., OpenAI, Anthropic).</p>`;

const gemsRules = `
<h1>The Geologic Enhanced Mapping System (GEMS) Prize Challenge</h1>
<p>Competition End Date: Dec. 3, 2026, 11:59 p.m. UTC</p>
<p>Individual competitors must be U.S. citizens or permanent residents.</p>
<p>Private entities must be incorporated in and maintain a primary place of business in the United States.</p>`;

test("DrivenData listing parser extracts active prize cards and external links", () => {
  const cards = extractDrivenDataPrizeCards(listingHtml);
  assert.equal(cards.length, 2);
  assert.equal(cards[0]?.prizeUsd, 20000);
  assert.equal(cards[0]?.deadlineHint, "2026-10-02");
  assert.equal(cards[1]?.prizeUsd, 300000);
});

test("Lost in Transcription is review-fit because competition data must stay local", () => {
  const card = extractDrivenDataPrizeCards(listingHtml)[0]!;
  const result = parseDrivenDataCompetition(
    card,
    lostRules,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.externalKey, "lost-in-transcription");
  assert.equal(result.deadline, "2026-10-02");
  assert.equal(result.fitStatus, "review");
  assert.match(result.automation, /Local-only ML execution/);
});

test("GEMS is blocked because prize eligibility is U.S.-restricted", () => {
  const card = extractDrivenDataPrizeCards(listingHtml)[1]!;
  const result = parseDrivenDataCompetition(
    card,
    gemsRules,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.externalKey, "competition-306");
  assert.equal(result.deadline, "2026-12-03");
  assert.equal(result.fitStatus, "blocked");
  assert.match(result.eligibility, /U\.S\./);
});

test("DrivenData scanner returns both current prize competitions with rule filtering", async () => {
  const fakeFetch = async (input: string | URL | Request) => {
    const url = String(input);
    if (url === "https://www.drivendata.org/competitions/") {
      return new Response(listingHtml, { status: 200 });
    }
    if (url.includes("lost-in-transcription-sp-en")) {
      return new Response(lostRules, { status: 200 });
    }
    if (url.includes("lost-in-transcription")) {
      return new Response("<h1>Lost in Transcription group</h1>", { status: 200 });
    }
    if (url.includes("/competitions/306/")) {
      return new Response(gemsRules, { status: 200 });
    }
    return new Response("not found", { status: 404 });
  };

  const result = await scanDrivenDataPrizeCompetitions(
    fakeFetch,
    new Date("2026-09-23T00:00:00Z")
  );

  assert.equal(result.discoveredCards, 2);
  assert.equal(result.competitions.length, 2);
  assert.equal(result.competitions.find((x) => x.externalKey === "lost-in-transcription")?.fitStatus, "review");
  assert.equal(result.competitions.find((x) => x.externalKey === "competition-306")?.fitStatus, "blocked");
});
