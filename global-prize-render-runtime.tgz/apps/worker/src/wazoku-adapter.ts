export type WazokuFitStatus = "eligible" | "review" | "blocked";

export type WazokuChallenge = {
  externalKey: string;
  sourceUrl: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  status: "active" | "closed";
  submissionCount: number | null;
  eligibility: string;
  automation: string;
  fitStatus: WazokuFitStatus;
  fitReasons: string[];
};

export type WazokuScanResult = {
  challenges: WazokuChallenge[];
  discoveredLinks: number;
};

type FetchLike = (
  input: string | URL | Request,
  init?: RequestInit
) => Promise<Response>;

function decodeHtml(value: string): string {
  return value
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#039;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_, code: string) =>
      String.fromCodePoint(Number(code))
    )
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) =>
      String.fromCodePoint(Number.parseInt(code, 16))
    );
}

export function htmlToText(html: string): string {
  return decodeHtml(
    html
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(?:p|div|li|h1|h2|h3|tr|section|article)>/gi, "\n")
      .replace(/<[^>]+>/g, " ")
  )
    .replace(/[ \t]+/g, " ")
    .replace(/(?:\r?\n\s*){2,}/g, "\n")
    .trim();
}

function headingFromHtml(html: string): string {
  const match = html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);
  return match ? htmlToText(match[1]).trim() : "";
}

function parseOrdinalDate(value: string): string {
  const normalized = value
    .replace(/(\d{1,2})(?:st|nd|rd|th)/i, "$1")
    .replace(/,/g, "")
    .trim();

  const parsed = new Date(normalized + " UTC");
  if (Number.isNaN(parsed.getTime())) {
    throw new Error("wazoku_deadline_invalid");
  }

  return parsed.toISOString().slice(0, 10);
}

function fitSignals(text: string): {
  fitStatus: WazokuFitStatus;
  fitReasons: string[];
  automation: string;
} {
  const aiOnlyProhibited =
    /submissions produced solely with generative AI are not of interest/i.test(text);

  const organizationOnly =
    /open to companies and organizations[\s\S]{0,500}proposals submitted by individuals[\s\S]{0,350}out of scope/i.test(text) ||
    /proposals submitted by individuals[^.]{0,300}out of scope/i.test(text);

  const deploymentCapability =
    /demonstrated technical, operational, and financial capability to execute a pilot implementation/i.test(text) ||
    /clear implementation approach, deployment capability, and the resources required to support the pilot phase/i.test(text);

  const paidPilot =
    /award of a paid pilot/i.test(text) ||
    /running a pilot followed by full implementation/i.test(text);

  const physicalTravel =
    /on-site assignment|in-person participation|physical presence required|must travel to|travel to the/i.test(text);

  const paidEntry =
    /entry fee is required|required registration fee|paid entry required/i.test(text);

  const fitReasons: string[] = [];

  if (aiOnlyProhibited) {
    fitReasons.push("solely generative-AI-produced submissions are not of interest");
  }
  if (organizationOnly) {
    fitReasons.push("individual submissions are out of scope; organization capability is required");
  }
  if (deploymentCapability) {
    fitReasons.push("demonstrated deployment/pilot execution capability is required");
  }
  if (paidPilot) {
    fitReasons.push("award is tied to a paid pilot/collaboration rather than a standalone cash prize");
  }
  if (physicalTravel) {
    fitReasons.push("physical/in-person participation is required");
  }
  if (paidEntry) {
    fitReasons.push("paid entry/registration is required");
  }

  const blocked =
    paidEntry ||
    physicalTravel ||
    (organizationOnly && deploymentCapability);

  const fitStatus: WazokuFitStatus =
    blocked ? "blocked" : aiOnlyProhibited || paidPilot ? "review" : "eligible";

  const automation = aiOnlyProhibited
    ? "AI-assisted research only; the challenge states that submissions produced solely with generative AI are not of interest"
    : "AI-assisted research permitted subject to the current challenge agreement and submission rules";

  return {
    fitStatus,
    fitReasons,
    automation
  };
}

export function parseWazokuChallenge(
  sourceUrl: string,
  html: string,
  now = new Date()
): WazokuChallenge {
  const url = new URL(sourceUrl);
  const externalKey = url.pathname.split("/").filter(Boolean).at(-1) ?? "";
  if (!externalKey) throw new Error("wazoku_external_key_missing");

  const text = htmlToText(html);
  const title = headingFromHtml(html) ||
    text.split("\n").map((line) => line.trim()).find(Boolean) ||
    "";

  if (!title) throw new Error("wazoku_title_missing");

  const lines = text.split("\n").map((line) => line.trim()).filter(Boolean);
  const titleIndex = lines.findIndex((line) => line === title);
  const headerText = lines
    .slice(titleIndex >= 0 ? titleIndex : 0, (titleIndex >= 0 ? titleIndex : 0) + 10)
    .join("\n");

  const prizeMatch = headerText.match(/^\$\s*([\d,]+)(?:\s*USD)?$/im);
  if (!prizeMatch) throw new Error("wazoku_cash_prize_missing");

  const prizeUsd = Number(prizeMatch[1].replace(/,/g, ""));
  if (!Number.isFinite(prizeUsd) || prizeUsd <= 0) {
    throw new Error("wazoku_prize_invalid");
  }

  const dueMatch = text.match(
    /Due:\s*(\d{1,2}(?:st|nd|rd|th)\s+[A-Za-z]{3,9}\s+\d{4})/i
  );
  if (!dueMatch) throw new Error("wazoku_deadline_missing");
  const deadline = parseOrdinalDate(dueMatch[1]);

  const submissionsMatch = text.match(/(\d[\d,]*)\s+Submissions/i);
  const submissionCount = submissionsMatch
    ? Number(submissionsMatch[1].replace(/,/g, ""))
    : null;

  const fit = fitSignals(text);
  const today = now.toISOString().slice(0, 10);
  const status: WazokuChallenge["status"] =
    deadline < today ? "closed" : "active";

  const eligibilityPrefix =
    fit.fitStatus === "blocked"
      ? "Project fit blocked"
      : fit.fitStatus === "review"
        ? "Project fit requires review"
        : "Project fit eligible for automated research triage";

  const eligibility =
    eligibilityPrefix +
    (fit.fitReasons.length > 0 ? ": " + fit.fitReasons.join("; ") : "") +
    ". Verify the current challenge agreement and solver eligibility before submission.";

  return {
    externalKey,
    sourceUrl,
    title,
    prizeUsd,
    deadline,
    status,
    submissionCount,
    eligibility,
    automation: fit.automation,
    fitStatus: fit.fitStatus,
    fitReasons: fit.fitReasons
  };
}

export function extractWazokuChallengeLinks(
  html: string,
  baseUrl = "https://www.innocentive.com/challenges/"
): string[] {
  const links: string[] = [];

  for (const match of html.matchAll(/href=["']([^"']+)["']/gi)) {
    try {
      const url = new URL(match[1], baseUrl);
      const parts = url.pathname.split("/").filter(Boolean);

      if (
        /^https?:$/.test(url.protocol) &&
        /(^|\.)innocentive\.com$/i.test(url.hostname) &&
        parts[0] === "challenges" &&
        parts.length === 2 &&
        !["faq"].includes(parts[1].toLowerCase())
      ) {
        url.hash = "";
        url.search = "";
        links.push(url.toString());
      }
    } catch {
      // Ignore malformed links.
    }
  }

  return [...new Set(links)];
}

async function fetchText(
  fetchImpl: FetchLike,
  url: string
): Promise<string> {
  const response = await fetchImpl(url, {
    headers: {
      accept: "text/html,application/xhtml+xml",
      "user-agent": "GlobalPrizeResearchEngine/1.0"
    },
    signal: AbortSignal.timeout(30_000)
  });

  if (!response.ok) {
    throw new Error("wazoku_fetch_failed:" + response.status + ":" + url);
  }

  return await response.text();
}

export async function scanWazokuPublicChallenges(
  fetchImpl: FetchLike = fetch,
  now = new Date()
): Promise<WazokuScanResult> {
  const listingUrls = [
    "https://www.innocentive.com/challenges/",
    "https://www.innocentive.com/challenges/page/2/"
  ];

  const discovered = new Set<string>();

  for (const listingUrl of listingUrls) {
    const html = await fetchText(fetchImpl, listingUrl);
    for (const link of extractWazokuChallengeLinks(html, listingUrl)) {
      discovered.add(link);
    }
  }

  if (discovered.size === 0) {
    throw new Error("wazoku_no_challenge_links_discovered");
  }

  const challenges: WazokuChallenge[] = [];

  for (const sourceUrl of [...discovered].slice(0, 50)) {
    try {
      const html = await fetchText(fetchImpl, sourceUrl);
      const challenge = parseWazokuChallenge(sourceUrl, html, now);

      if (challenge.status === "active") {
        challenges.push(challenge);
      }
    } catch {
      // Skip non-cash, closed, malformed, or non-standard challenge pages.
    }
  }

  if (challenges.length === 0) {
    throw new Error("wazoku_no_active_cash_challenges_parsed");
  }

  return {
    challenges,
    discoveredLinks: discovered.size
  };
}
