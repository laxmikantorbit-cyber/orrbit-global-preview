import assert from "node:assert/strict";
import test from "node:test";
import { parsePatrollContest } from "./patroll-adapter.js";

test("PATROLL parser extracts active contest fields from public detail text", () => {
  const result = parsePatrollContest(
    "https://patroll.unifiedpatents.com/contests/D7vWADzNGp9JNiQAp",
    [
      "Arc Link: US-11563655-B2 (Software Defined Network)",
      "Active",
      "11563655 - Software Defined Network",
      "Prize: $2000",
      "AI-Assisted Claim Charting",
      "Participants are required to use the Pearl claim charting tool.",
      "Start Date: Fri Sep 04 2026 05:00:00 GMT+0000 (Coordinated Universal Time)",
      "End Date: Sat Oct 10 2026 04:59:59 GMT+0000 (Coordinated Universal Time)"
    ].join("\n"),
    "Arc Link: US-11563655-B2 (Software Defined Network)"
  );

  assert.equal(result.externalKey, "D7vWADzNGp9JNiQAp");
  assert.equal(result.patentNumber, "11563655");
  assert.equal(result.prizeUsd, 2000);
  assert.equal(result.deadline, "2026-10-10");
  assert.equal(result.status, "active");
  assert.match(result.automation, /Pearl AI-assisted claim chart required/);
});

test("PATROLL parser recognizes finished status and comma-formatted prize", () => {
  const result = parsePatrollContest(
    "https://patroll.unifiedpatents.com/contests/example",
    [
      "Example: US-12345678-B2 (Example)",
      "Finished",
      "Prize: $10,000",
      "End Date: Tue Sep 01 2026 04:59:59 GMT+0000 (Coordinated Universal Time)"
    ].join("\n")
  );

  assert.equal(result.prizeUsd, 10000);
  assert.equal(result.status, "finished");
  assert.equal(result.patentNumber, "12345678");
});

test("PATROLL parser rejects detail text without a public end date", () => {
  assert.throws(
    () => parsePatrollContest(
      "https://patroll.unifiedpatents.com/contests/example",
      "Example US-12345678-B2\nActive\nPrize: $2000"
    ),
    /patroll_end_date_missing/
  );
});
