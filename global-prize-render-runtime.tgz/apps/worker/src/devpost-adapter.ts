import puppeteer from "puppeteer-core";

export type DevpostHackathon = {
  externalKey: string;
  sourceUrl: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  participants: number;
  status: "active" | "ended";
  fitStatus: "review" | "blocked";
  fitReasons: string[];
  eligibility: string;
  automation: string;
};

export type DevpostScanResult = {
  hackathons: DevpostHackathon[];
  discoveredCards: number;
};

export type DevpostRenderedCard = {
  href: string;
  text: string;
};

function monthNumber(name: string): string {
  const months: Record<string, string> = {
    jan: "01", feb: "02", mar: "03", apr: "04",
    may: "05", jun: "06", jul: "07", aug: "08",
    sep: "09", oct: "10", nov: "11", dec: "12"
  };
  const value = months[name.slice(0, 3).toLowerCase()];
  if (!value) throw new Error("devpost_month_invalid:" + name);
  return value;
}

function parseDateRange(text: string): string {
  const match = text.match(
    /(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s*-\s*((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec))\s+(\d{1,2}),\s+(\d{4})/i
  );
  if (!match) throw new Error("devpost_deadline_missing");
  return `${match[3]}-${monthNumber(match[1])}-${match[2].padStart(2, "0")}`;
}

function prize(text: string): number {
  const match = text.match(/\$([\d,]+)\s+in prizes/i);
  if (!match) throw new Error("devpost_prize_missing");
  return Number(match[1].replaceAll(",", ""));
}

function participants(text: string): number {
  const match = text.match(/([\d,]+)\s+participants/i);
  return match ? Number(match[1].replaceAll(",", "")) : 0;
}

function titleFromLines(lines: string[]): string {
  const onlineIndex = lines.findIndex((line) => /^Online$/i.test(line));
  const candidate = lines[onlineIndex + 1] ?? lines[0] ?? "";
  if (!candidate.trim()) throw new Error("devpost_title_missing");
  return candidate.trim();
}

function externalKey(sourceUrl: string): string {
  const url = new URL(sourceUrl);
  const host = url.hostname.toLowerCase();
  if (!host.endsWith(".devpost.com")) throw new Error("devpost_invalid_hackathon_host");
  return host.slice(0, -".devpost.com".length);
}

export function parseDevpostRenderedCard(
  card: DevpostRenderedCard,
  now = new Date(),
  minimumPrizeUsd = 20_000
): DevpostHackathon | null {
  const lines = card.text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (!lines.some((line) => /^Online$/i.test(line))) return null;
  if (!/Managed by Devpost/i.test(card.text)) return null;

  const sourceUrl = new URL(card.href);
  sourceUrl.search = "";
  sourceUrl.hash = "";

  let parsedPrize: number;
  let deadline: string;
  let key: string;
  let title: string;

  try {
    parsedPrize = prize(card.text);
    deadline = parseDateRange(card.text);
    key = externalKey(sourceUrl.toString());
    title = titleFromLines(lines);
  } catch {
    return null;
  }

  if (parsedPrize < minimumPrizeUsd) return null;

  const ended =
    lines.some((line) => /^Ended$/i.test(line)) ||
    deadline < now.toISOString().slice(0, 10);
  const status: DevpostHackathon["status"] = ended ? "ended" : "active";

  const fitReasons = [
    "hackathon-specific eligibility, submission requirements, judging criteria and AI/tool rules must be reviewed",
    "a working project, source code, demo material or other submission assets may be required"
  ];

  const participantCount = participants(card.text);
  if (participantCount >= 5000) {
    fitReasons.push("high participation indicates strong competition density");
  }

  return {
    externalKey: key,
    sourceUrl: sourceUrl.toString(),
    title,
    prizeUsd: parsedPrize,
    deadline,
    participants: participantCount,
    status,
    fitStatus: status === "active" ? "review" : "blocked",
    fitReasons,
    eligibility:
      status === "active"
        ? "Project fit requires review: verify current Devpost official rules, geography, eligibility, team requirements and submission obligations before committing work."
        : "Project fit blocked: submission period has ended.",
    automation:
      "AI-assisted development may be used only where the hackathon rules permit it; verify required human participation, original-work, demo, repository and judging rules before submission."
  };
}

export function parseDevpostRenderedCards(
  cards: DevpostRenderedCard[],
  now = new Date(),
  minimumPrizeUsd = 20_000
): DevpostHackathon[] {
  const unique = new Map<string, DevpostHackathon>();

  for (const card of cards) {
    const parsed = parseDevpostRenderedCard(card, now, minimumPrizeUsd);
    if (!parsed || parsed.status !== "active") continue;
    unique.set(parsed.externalKey, parsed);
  }

  return [...unique.values()].sort((a, b) => b.prizeUsd - a.prizeUsd);
}

export async function scanDevpostHighValueHackathons(
  now = new Date(),
  minimumPrizeUsd = 20_000
): Promise<DevpostScanResult> {
  const executablePath =
    process.env.CHROMIUM_PATH ??
    process.env.PUPPETEER_EXECUTABLE_PATH ??
    "/usr/bin/chromium-browser";

  const browser = await puppeteer.launch({
    executablePath,
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"]
  });

  try {
    const page = await browser.newPage();
    await page.setUserAgent("GlobalPrizeResearchEngine/1.0");
    await page.goto(
      "https://devpost.com/hackathons?challenge_type%5B%5D=online&managed_by_devpost_badge=1",
      { waitUntil: "networkidle2", timeout: 30_000 }
    );

    const cards = await page.evaluate(() =>
      Array.from(document.querySelectorAll<HTMLAnchorElement>("a"))
        .map((anchor) => ({
          href: anchor.href,
          text: (anchor.innerText || "").trim()
        }))
        .filter(
          (item) =>
            item.href.includes(".devpost.com/") &&
            item.text.includes("Managed by Devpost") &&
            item.text.includes("in prizes")
        )
    );

    const hackathons = parseDevpostRenderedCards(cards, now, minimumPrizeUsd);

    if (hackathons.length === 0) {
      throw new Error("devpost_no_active_high_value_hackathons");
    }

    return {
      hackathons,
      discoveredCards: cards.length
    };
  } finally {
    await browser.close();
  }
}
