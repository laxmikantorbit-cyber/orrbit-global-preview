export type MetaculusTournament = {
  externalKey: string;
  sourceUrl: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  status: "upcoming" | "active" | "closed";
  eligibility: string;
  automation: string;
};

export type MetaculusScanResult = {
  tournaments: MetaculusTournament[];
  discoveredProjects: number;
};

type MetaculusProject = {
  id?: number | string | null;
  slug?: string | null;
  name?: string | null;
  prize_pool?: string | number | null;
  start_date?: string | null;
  close_date?: string | null;
  is_ongoing?: boolean | null;
  bot_leaderboard_status?: string | null;
  type?: string | null;
};

type FetchLike = (
  input: string | URL | Request,
  init?: RequestInit
) => Promise<Response>;

const BOT_ELIGIBLE = new Set(["bots_only", "include"]);

function isoDate(value: string | null | undefined, field: string): string {
  if (!value) throw new Error("metaculus_" + field + "_missing");
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error("metaculus_" + field + "_invalid");
  }
  return parsed.toISOString().slice(0, 10);
}

function prizeNumber(value: string | number | null | undefined): number {
  const parsed = typeof value === "number"
    ? value
    : Number(String(value ?? "").replace(/[$,]/g, ""));

  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error("metaculus_prize_invalid");
  }

  return Math.round(parsed);
}

export function parseMetaculusFutureEvalProject(
  raw: MetaculusProject,
  now = new Date()
): MetaculusTournament {
  const externalKey = String(raw.slug ?? "").trim();
  const title = String(raw.name ?? "").trim();

  if (!externalKey) throw new Error("metaculus_slug_missing");
  if (!title) throw new Error("metaculus_title_missing");

  const isFutureEval =
    /FutureEval Bot Tournament|AI Forecasting Benchmark Tournament/i.test(title) ||
    /futureeval|(?:^|-)aib(?:-|$)/i.test(externalKey);

  if (!isFutureEval) throw new Error("metaculus_not_futureeval");

  const botStatus = String(raw.bot_leaderboard_status ?? "").trim();
  if (!BOT_ELIGIBLE.has(botStatus)) {
    throw new Error("metaculus_bots_not_prize_eligible");
  }

  const prizeUsd = prizeNumber(raw.prize_pool);
  const start = isoDate(raw.start_date, "start_date");
  const deadline = isoDate(raw.close_date, "close_date");
  const today = now.toISOString().slice(0, 10);

  const status: MetaculusTournament["status"] =
    deadline < today
      ? "closed"
      : start > today
        ? "upcoming"
        : "active";

  return {
    externalKey,
    sourceUrl: "https://www.metaculus.com/tournament/" + externalKey + "/",
    title,
    prizeUsd,
    deadline,
    status,
    eligibility:
      "Metaculus FutureEval bot account/API token required; live API reports bot_leaderboard_status=" +
      botStatus +
      "; verify current tournament rules before participation",
    automation:
      "Autonomous forecasting bot is prize-eligible for this tournament; use official Metaculus API/bot workflow and current disclosure rules"
  };
}

export async function scanMetaculusFutureEvalTournaments(
  fetchImpl: FetchLike = fetch,
  token = process.env.METACULUS_TOKEN?.trim() ?? ""
): Promise<MetaculusScanResult> {
  if (!token) {
    throw new Error("metaculus_token_not_configured");
  }

  const apiBase =
    process.env.METACULUS_API_BASE_URL?.replace(/\/$/, "") ??
    "https://www.metaculus.com/api";

  const response = await fetchImpl(apiBase + "/projects/tournaments/", {
    headers: {
      accept: "application/json",
      authorization: "Token " + token,
      "user-agent": "GlobalPrizeResearchEngine/1.0"
    },
    signal: AbortSignal.timeout(30_000)
  });

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error("metaculus_api_auth_failed:" + response.status);
    }
    throw new Error("metaculus_api_failed:" + response.status);
  }

  const data = await response.json() as unknown;
  const rows = Array.isArray(data)
    ? data
    : data && typeof data === "object" && Array.isArray((data as { results?: unknown }).results)
      ? (data as { results: unknown[] }).results
      : [];

  if (rows.length === 0) {
    throw new Error("metaculus_no_tournament_projects_returned");
  }

  const tournaments: MetaculusTournament[] = [];

  for (const row of rows) {
    if (!row || typeof row !== "object") continue;

    try {
      const tournament = parseMetaculusFutureEvalProject(row as MetaculusProject);
      if (tournament.status !== "closed") tournaments.push(tournament);
    } catch {
      // Ignore non-FutureEval, bot-excluded, zero-prize and archived projects.
    }
  }

  if (tournaments.length === 0) {
    throw new Error("metaculus_no_open_bot_eligible_futureeval_tournaments");
  }

  return {
    tournaments,
    discoveredProjects: rows.length
  };
}
