export type JobOutcome = {
  status: "ok" | "warning";
  message: string;
  summary: Record<string, unknown>;
};

export type DeadlineOpportunity = {
  id: string;
  title: string;
  platform: string;
  deadline: string;
  score: number;
};

export type SubmissionViolation = {
  id: string;
  status: string;
  issue: string;
};

export function deadlineWatchOutcome(
  items: DeadlineOpportunity[],
  windowDays = 21
): JobOutcome {
  return {
    status: "ok",
    message: `${items.length} opportunit${items.length === 1 ? "y" : "ies"} due within ${windowDays} days`,
    summary: {
      windowDays,
      count: items.length,
      items
    }
  };
}

export function submissionIntegrityOutcome(
  violations: SubmissionViolation[]
): JobOutcome {
  if (violations.length === 0) {
    return {
      status: "ok",
      message: "Submission lifecycle states are internally consistent",
      summary: {
        violations: 0,
        items: []
      }
    };
  }

  return {
    status: "warning",
    message: `${violations.length} submission lifecycle violation${violations.length === 1 ? "" : "s"} detected`,
    summary: {
      violations: violations.length,
      items: violations
    }
  };
}


export type BackupOutcomeInput = {
  backupKey: string;
  databaseBytes: number;
  filesBytes: number;
  retentionCount: number;
  prunedCount: number;
};

export function backupOutcome(input: BackupOutcomeInput): JobOutcome {
  return {
    status: "ok",
    message: `Backup ${input.backupKey} completed and verified`,
    summary: {
      backupKey: input.backupKey,
      databaseBytes: input.databaseBytes,
      filesBytes: input.filesBytes,
      retentionCount: input.retentionCount,
      prunedCount: input.prunedCount,
      verified: true
    }
  };
}
