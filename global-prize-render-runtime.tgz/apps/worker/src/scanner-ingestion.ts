import { createHash } from "node:crypto";
import type pg from "pg";

type Pool = pg.Pool;

export type WorkerScannedOpportunity = {
  sourceId: string;
  externalKey: string;
  platform: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  eligibility: string;
  automation: string;
  sourceStatus: string;
  sourceUrl: string;
  initialStatus: string;
  canonicalHint?: string;
  extra?: Record<string, unknown>;
};

type ExistingRow = {
  id: string;
  source_id: string | null;
  external_key: string | null;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: Date | string;
  eligibility: string;
  automation: string;
  source_status: string | null;
  source_url: string | null;
  source_hash: string | null;
};

export type WorkerIngestionResult = {
  canonicalOpportunityId: string;
  action: "created" | "updated" | "unchanged";
  changedFields: string[];
};

function dateOnly(value: Date | string): string {
  return value instanceof Date ? value.toISOString().slice(0, 10) : String(value).slice(0, 10);
}

function canonicalId(item: WorkerScannedOpportunity): string {
  return "scan-" + item.sourceId.replace(/[^a-z0-9-]+/gi, "-").toLowerCase() + "-" +
    createHash("sha256").update(item.sourceId + ":" + item.externalKey).digest("hex").slice(0, 14);
}

function payload(item: WorkerScannedOpportunity): Record<string, unknown> {
  return {
    sourceId: item.sourceId,
    externalKey: item.externalKey,
    platform: item.platform,
    title: item.title,
    prizeUsd: item.prizeUsd,
    deadline: item.deadline,
    eligibility: item.eligibility,
    automation: item.automation,
    sourceStatus: item.sourceStatus,
    sourceUrl: item.sourceUrl,
    initialStatus: item.initialStatus,
    ...item.extra
  };
}

export function workerChangedFields(
  current: ExistingRow,
  item: WorkerScannedOpportunity,
  snapshotHash?: string
): string[] {
  const changes: string[] = [];
  if (current.platform !== item.platform) changes.push("platform");
  if (current.title !== item.title) changes.push("title");
  if (Number(current.prize_usd) !== Math.trunc(item.prizeUsd)) changes.push("prizeUsd");
  if (dateOnly(current.deadline) !== item.deadline) changes.push("deadline");
  if (current.eligibility !== item.eligibility) changes.push("eligibility");
  if (current.automation !== item.automation) changes.push("automation");
  if ((current.source_status ?? "") !== item.sourceStatus) changes.push("sourceStatus");
  if ((current.source_url ?? "") !== item.sourceUrl) changes.push("sourceUrl");
  if (!current.source_id || !current.external_key) changes.unshift("sourceLink");
  if (snapshotHash !== undefined && (current.source_hash ?? "") !== snapshotHash && changes.length === 0) {
    changes.push("sourceSnapshot");
  }
  return changes;
}

export async function ingestWorkerScannedOpportunity(
  pool: Pool,
  item: WorkerScannedOpportunity
): Promise<WorkerIngestionResult> {
  const observedAt = new Date();
  const body = payload(item);
  const hash = createHash("sha256").update(JSON.stringify(body)).digest("hex");
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const source = await client.query(
      "SELECT 1 FROM opportunity_sources WHERE id=$1 AND enabled=TRUE",
      [item.sourceId]
    );
    if (!source.rowCount) throw new Error("scanner_source_not_found_or_disabled:" + item.sourceId);

    let existing = await client.query<ExistingRow>(
      "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url,source_hash FROM opportunities WHERE source_id=$1 AND external_key=$2 LIMIT 1 FOR UPDATE",
      [item.sourceId, item.externalKey]
    );

    if (!existing.rows[0] && item.canonicalHint) {
      existing = await client.query<ExistingRow>(
        "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,source_status,source_url,source_hash FROM opportunities WHERE id=$1 LIMIT 1 FOR UPDATE",
        [item.canonicalHint]
      );
    }

    const current = existing.rows[0];
    let id: string;
    let action: WorkerIngestionResult["action"];
    let changes: string[];

    if (!current) {
      id = canonicalId(item);
      action = "created";
      changes = ["platform","title","prizeUsd","deadline","eligibility","automation","sourceStatus","sourceUrl"];

      await client.query(
        "INSERT INTO opportunities (id,platform,title,prize_usd,deadline,eligibility,automation,score,status,source_status,source_id,external_key,source_url,first_seen_at,last_seen_at,source_hash,source_observed_at,verification_status) VALUES ($1,$2,$3,$4,$5,$6,$7,50,$8,$9,$10,$11,$12,$13,$13,$14,$13,'source-observed')",
        [id,item.platform,item.title,Math.trunc(item.prizeUsd),item.deadline,item.eligibility,item.automation,item.initialStatus,item.sourceStatus,item.sourceId,item.externalKey,item.sourceUrl,observedAt,hash]
      );
    } else {
      if (current.source_id && (current.source_id !== item.sourceId || current.external_key !== item.externalKey)) {
        throw new Error("scanner_canonical_opportunity_already_linked:" + current.id);
      }

      id = current.id;
      changes = workerChangedFields(current, item, hash);
      action = changes.length ? "updated" : "unchanged";

      await client.query(
        "UPDATE opportunities SET source_id=$2,external_key=$3,platform=$4,title=$5,prize_usd=$6,deadline=$7,eligibility=$8,automation=$9,source_status=$10,source_url=$11,last_seen_at=$12,source_hash=$13,source_observed_at=$12,verification_status='source-observed',updated_at=CASE WHEN $14::boolean THEN NOW() ELSE updated_at END WHERE id=$1",
        [id,item.sourceId,item.externalKey,item.platform,item.title,Math.trunc(item.prizeUsd),item.deadline,item.eligibility,item.automation,item.sourceStatus,item.sourceUrl,observedAt,hash,changes.length > 0]
      );
    }

    await client.query(
      "INSERT INTO opportunity_observations (source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb) ON CONFLICT (source_id,external_key,snapshot_hash) DO NOTHING",
      [item.sourceId,item.externalKey,id,observedAt,hash,action === "created",JSON.stringify(changes),JSON.stringify(body)]
    );

    await client.query("COMMIT");
    return { canonicalOpportunityId: id, action, changedFields: changes };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
