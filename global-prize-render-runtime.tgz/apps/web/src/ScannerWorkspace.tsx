import { useEffect, useMemo, useState } from "react";
import { fetchScannerObservations, fetchScannerSources } from "./api";
import type { OpportunityObservation, OpportunitySource } from "./types";

function formatDateTime(value: string | null): string {
  if (!value) return "Not yet";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function sourceTone(source: OpportunitySource): string {
  if (!source.enabled) return "disabled";
  if (source.lastStatus === "ok") return "ok";
  if (source.lastStatus === "warning") return "warning";
  if (source.lastStatus === "error") return "error";
  if (source.lastStatus === "running") return "running";
  return "pending";
}

function observationTitle(item: OpportunityObservation): string {
  const title = item.payload.title;
  return typeof title === "string" && title.trim() ? title : item.externalKey;
}

function observationPrize(item: OpportunityObservation): string {
  const value = item.payload.prizeUsd;
  if (typeof value !== "number") return "—";
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

export default function ScannerWorkspace() {
  const [sources, setSources] = useState<OpportunitySource[]>([]);
  const [observations, setObservations] = useState<OpportunityObservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    Promise.all([
      fetchScannerSources(controller.signal),
      fetchScannerObservations(50, controller.signal)
    ])
      .then(([sourceResponse, observationResponse]) => {
        setSources(sourceResponse.items);
        setObservations(observationResponse.items);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load scanner state");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  const stats = useMemo(() => ({
    enabled: sources.filter((source) => source.enabled).length,
    healthy: sources.filter((source) => source.lastStatus === "ok").length,
    newItems: observations.filter((item) => item.isNew).length,
    changedItems: observations.filter((item) => !item.isNew && item.changedFields.length > 0).length
  }), [sources, observations]);

  return (
    <section className="scannerPage">
      <div className="scannerHero">
        <div>
          <span className="eyebrow">LIVE OPPORTUNITY INGESTION</span>
          <h1>Observe public sources. Keep provenance. Never silently overwrite history.</h1>
          <p>
            Public-source adapters feed normalized observations into one audited pipeline.
            New and changed opportunities are tracked separately from internal scoring.
          </p>
        </div>

        <div className="scannerHeroStats">
          <div><strong>{stats.enabled}</strong><span>Enabled sources</span></div>
          <div><strong>{stats.healthy}</strong><span>Healthy</span></div>
          <div><strong>{stats.newItems}</strong><span>New observations</span></div>
          <div><strong>{stats.changedItems}</strong><span>Changed</span></div>
        </div>
      </div>

      {loading && <div className="dataState info">Loading scanner state…</div>}
      {error && <div className="dataState error">{error}</div>}

      <div className="scannerGrid">
        <article className="panel scannerSourcesPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">SOURCES</span>
              <h2>Public Source Adapters</h2>
            </div>
          </div>

          <div className="scannerSourceList">
            {sources.map((source) => (
              <div className="scannerSourceCard" key={source.id}>
                <div className="scannerSourceTop">
                  <div>
                    <span className="scannerAdapter">{source.adapterType.replaceAll("-", " ")}</span>
                    <strong>{source.name}</strong>
                  </div>
                  <span className={`scannerSourceStatus ${sourceTone(source)}`}>
                    {source.enabled ? (source.lastStatus ?? "pending") : "disabled"}
                  </span>
                </div>

                <div className="scannerSourceMeta">
                  <div><span>Platform</span><strong>{source.platform}</strong></div>
                  <div><span>Interval</span><strong>{source.scanIntervalMinutes} min</strong></div>
                  <div><span>Last finished</span><strong>{formatDateTime(source.lastFinishedAt)}</strong></div>
                  <div><span>Next scan</span><strong>{formatDateTime(source.nextScanAt)}</strong></div>
                </div>

                <p>{source.lastMessage ?? "No scanner message yet."}</p>
                <a href={source.sourceUrl} target="_blank" rel="noreferrer">Open official source ↗</a>
              </div>
            ))}

            {!loading && sources.length === 0 && (
              <div className="scannerEmpty">No scanner sources are configured.</div>
            )}
          </div>
        </article>

        <article className="panel scannerRulesPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">INGESTION RULES</span>
              <h2>Safety & Data Integrity</h2>
            </div>
          </div>

          <div className="scannerRules">
            <Rule title="Official public sources" detail="Adapters read only public pages/feeds. No login bypass or private endpoint dependency." />
            <Rule title="Provenance required" detail="Every normalized item keeps source ID, external key, source URL, observation time and content hash." />
            <Rule title="Deduplicated updates" detail="Same source item maps to one canonical opportunity; unchanged snapshots do not create duplicate opportunity rows." />
            <Rule title="Change history" detail="Prize, deadline, rules, eligibility, status and title changes are recorded as changed fields." />
            <Rule title="Score isolation" detail="Source updates never overwrite an existing internal priority score. New items enter triage at score 50." />
          </div>
        </article>

        <article className="panel scannerObservationsPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">PROVENANCE LOG</span>
              <h2>Recent Observations</h2>
            </div>
          </div>

          <div className="scannerObservationTable">
            <div className="scannerObservationHeader">
              <span>Observed</span><span>Source</span><span>Opportunity</span><span>Prize</span><span>Change</span><span>Canonical ID</span>
            </div>

            {observations.map((item) => (
              <div className="scannerObservationRow" key={item.id}>
                <span>{formatDateTime(item.observedAt)}</span>
                <strong>{item.sourceId}</strong>
                <span className="scannerObservationTitle">{observationTitle(item)}</span>
                <span>{observationPrize(item)}</span>
                <span className={item.isNew ? "scannerChange new" : item.changedFields.length > 0 ? "scannerChange changed" : "scannerChange same"}>
                  {item.isNew
                    ? "new"
                    : item.changedFields.length > 0
                      ? item.changedFields.join(", ")
                      : "unchanged"}
                </span>
                <code>{item.canonicalOpportunityId ?? "unlinked"}</code>
              </div>
            ))}

            {!loading && observations.length === 0 && (
              <div className="scannerEmpty">No source observation has been recorded yet.</div>
            )}
          </div>
        </article>
      </div>
    </section>
  );
}

function Rule({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="scannerRule">
      <i>✓</i>
      <div>
        <strong>{title}</strong>
        <p>{detail}</p>
      </div>
    </div>
  );
}
