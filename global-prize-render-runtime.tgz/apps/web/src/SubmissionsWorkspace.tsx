import { useEffect, useMemo, useState } from "react";
import { fetchSubmission, fetchSubmissionReadiness, fetchSubmissions } from "./api";
import type { SubmissionItem, SubmissionReadinessAssessment } from "./types";

function money(value: number | null): string {
  if (value === null) return "—";
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

function label(value: string | null): string {
  if (!value) return "Not set";
  return value.replaceAll("-", " ");
}

function formatDate(value: string | null): string {
  if (!value) return "Not set";
  return new Date(value.length === 10 ? `${value}T12:00:00` : value).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

export default function SubmissionsWorkspace() {
  const params = new URLSearchParams(window.location.search);
  const [items, setItems] = useState<SubmissionItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(params.get("submission"));
  const [selected, setSelected] = useState<SubmissionItem | null>(null);
  const [readiness, setReadiness] = useState<SubmissionReadinessAssessment | null>(null);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    fetchSubmissions(controller.signal)
      .then((response) => {
        setItems(response.items);
        setSelectedId((current) =>
          current && response.items.some((item) => item.id === current)
            ? current
            : response.items[0]?.id ?? null
        );
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load submission tracker");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingList(false);
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setSelected(null);
      setReadiness(null);
      return;
    }

    const controller = new AbortController();
    setLoadingDetail(true);

    Promise.all([
      fetchSubmission(selectedId, controller.signal),
      fetchSubmissionReadiness(selectedId, controller.signal)
    ])
      .then(([response, readinessResponse]) => {
        setSelected(response);
        setReadiness(readinessResponse);
        setError(null);

        const next = new URL(window.location.href);
        next.searchParams.set("view", "submissions");
        next.searchParams.set("submission", selectedId);
        window.history.replaceState({}, "", next);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load submission");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingDetail(false);
      });

    return () => controller.abort();
  }, [selectedId]);

  const stats = useMemo(() => ({
    drafts: items.filter((item) => item.status === "draft").length,
    ready: items.filter((item) => item.status === "ready").length,
    submitted: items.filter((item) => item.status === "submitted").length,
    awarded: items.filter((item) => item.resultStatus === "won" && item.awardUsd !== null).length
  }), [items]);

  return (
    <section className="submissionPage">
      <div className="submissionHero">
        <div>
          <span className="eyebrow">SUBMISSION TRACKER</span>
          <h1>Track every submission without overstating progress.</h1>
          <p>Draft, ready, submitted, result and award states stay separate and auditable.</p>
        </div>
        <div className="submissionHeroStats">
          <div><strong>{stats.drafts}</strong><span>Draft</span></div>
          <div><strong>{stats.ready}</strong><span>Ready</span></div>
          <div><strong>{stats.submitted}</strong><span>Submitted</span></div>
          <div><strong>{stats.awarded}</strong><span>Awarded</span></div>
        </div>
      </div>

      {error && <div className="dataState error">{error}</div>}

      <div className="submissionLayout">
        <aside className="panel submissionQueue">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">PIPELINE</span>
              <h2>Tracked Submissions</h2>
            </div>
          </div>

          {loadingList && <div className="submissionEmpty">Loading submission tracker…</div>}
          {!loadingList && items.length === 0 && (
            <div className="submissionEmpty">
              No internal draft or external submission is tracked yet.
            </div>
          )}

          <div className="submissionCards">
            {items.map((item) => (
              <button
                key={item.id}
                className={selectedId === item.id ? "submissionCard selected" : "submissionCard"}
                onClick={() => setSelectedId(item.id)}
              >
                <div className="submissionCardTop">
                  <span>{item.platform}</span>
                  <strong className={`submissionStatus ${item.status}`}>{label(item.status)}</strong>
                </div>
                <b>{item.title}</b>
                <small>{formatDate(item.deadline)} · {item.resultStatus ? label(item.resultStatus) : "No result yet"}</small>
              </button>
            ))}
          </div>
        </aside>

        <div className="submissionDetail">
          {loadingDetail && <div className="panel submissionEmpty">Loading submission detail…</div>}

          {!loadingDetail && selected && (
            <>
              <article className="panel submissionSummary">
                <div className="submissionSummaryTop">
                  <div>
                    <span className="eyebrow">CURRENT TRACKER ITEM</span>
                    <h2>{selected.title}</h2>
                    <p>{selected.notes}</p>
                  </div>
                  <span className={`submissionStatus large ${selected.status}`}>{label(selected.status)}</span>
                </div>

                <div className="submissionMetaGrid">
                  <div><span>Platform</span><strong>{selected.platform}</strong></div>
                  <div><span>Deadline</span><strong>{formatDate(selected.deadline)}</strong></div>
                  <div><span>Submitted at</span><strong>{formatDate(selected.submittedAt)}</strong></div>
                  <div><span>Award</span><strong>{money(selected.awardUsd)}</strong></div>
                </div>
              </article>

              {readiness && (
                <article className="panel submissionReadinessPanel">
                  <div className="panelHead researchPanelHead">
                    <div>
                      <span className="eyebrow">READINESS GATE</span>
                      <h2>Submission Readiness</h2>
                    </div>
                    <span className={`readinessState ${readiness.state}`}>
                      {label(readiness.state)}
                    </span>
                  </div>

                  <div className="readinessSummary">
                    <div className="readinessScore">
                      <strong>{readiness.score}</strong>
                      <span>Process score</span>
                    </div>
                    <div>
                      <p>{readiness.note}</p>
                      <div className="readinessMeta">
                        <span>Deadline: <b>{label(readiness.deadlineState)}</b></span>
                        <span>Days: <b>{readiness.daysRemaining ?? "—"}</b></span>
                        <span>Research: <b>{readiness.researchReadiness ? label(readiness.researchReadiness) : "not linked"}</b></span>
                      </div>
                    </div>
                  </div>

                  <div className="readinessChecks">
                    {readiness.checks.map((check) => (
                      <div className={check.passed ? "readinessCheck pass" : check.blocking ? "readinessCheck block" : "readinessCheck review"} key={check.key}>
                        <i>{check.passed ? "✓" : check.blocking ? "!" : "?"}</i>
                        <div>
                          <strong>{check.label}</strong>
                          <span>{check.detail}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {readiness.issues.length > 0 && (
                    <div className="readinessIssues">
                      {readiness.issues.map((issue) => (
                        <div className={`readinessIssue ${issue.severity}`} key={issue.code}>
                          <strong>{issue.title}</strong>
                          <span>{issue.detail}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </article>
              )}

              <article className="panel lifecyclePanel">
                <div className="panelHead researchPanelHead">
                  <div>
                    <span className="eyebrow">LIFECYCLE</span>
                    <h2>Submission State</h2>
                  </div>
                </div>
                <div className="lifecycleSteps">
                  <LifecycleStep label="Draft" active={["draft","ready","submitted","result"].includes(selected.status)} />
                  <LifecycleStep label="Ready" active={["ready","submitted","result"].includes(selected.status)} />
                  <LifecycleStep label="Submitted" active={["submitted","result"].includes(selected.status)} />
                  <LifecycleStep label="Result" active={selected.resultStatus !== null} />
                </div>
                <div className="submissionGuardrail">
                  <strong>External-submission guardrail</strong>
                  <p>
                    This item is currently <b>{label(selected.status)}</b>.
                    {selected.submittedAt
                      ? ` External submission time is recorded as ${formatDate(selected.submittedAt)}.`
                      : " No external submission timestamp is recorded, so this must not be described as submitted."}
                  </p>
                </div>
              </article>

              <article className="panel submissionLinks">
                <div className="panelHead researchPanelHead">
                  <div>
                    <span className="eyebrow">TRACEABILITY</span>
                    <h2>Linked Work</h2>
                  </div>
                </div>
                <div className="guardrailRows">
                  <div><span>Opportunity</span><strong>{selected.opportunityId}</strong></div>
                  <div><span>Research project</span><strong>{selected.researchProjectId ?? "Not linked"}</strong></div>
                  <div><span>External reference</span><strong>{selected.externalReference ?? "Not recorded"}</strong></div>
                  <div><span>Result</span><strong>{label(selected.resultStatus)}</strong></div>
                </div>
              </article>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

function LifecycleStep({ label: text, active }: { label: string; active: boolean }) {
  return (
    <div className={active ? "lifecycleStep active" : "lifecycleStep"}>
      <i />
      <span>{text}</span>
    </div>
  );
}
