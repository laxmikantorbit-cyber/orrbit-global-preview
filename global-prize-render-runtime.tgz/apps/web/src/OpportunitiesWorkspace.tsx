import { useEffect, useMemo, useState } from "react";
import {
  fetchOpportunities,
  fetchOpportunity,
  fetchOpportunityAssessment
} from "./api";
import type { Opportunity, OpportunityAssessment } from "./types";

function money(value: number): string {
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

function label(value: string): string {
  return value.replaceAll("-", " ");
}

function formatDate(value: string): string {
  return new Date(`${value}T12:00:00`).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function eligibilityClass(value: string): string {
  const text = value.toLowerCase();
  if (text.includes("account") || text.includes("token")) return "action";
  if (text.includes("review") || text.includes("check")) return "review";
  return "ready";
}

export default function OpportunitiesWorkspace({
  defaultPlatform
}: {
  defaultPlatform?: string;
} = {}) {
  const params = new URLSearchParams(window.location.search);
  const [items, setItems] = useState<Opportunity[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(
    params.get("opportunity")
  );
  const [opportunity, setOpportunity] = useState<Opportunity | null>(null);
  const [assessment, setAssessment] = useState<OpportunityAssessment | null>(null);
  const [platformFilter, setPlatformFilter] = useState(
    defaultPlatform ?? params.get("platform") ?? "all"
  );
  const [minimumScore, setMinimumScore] = useState(0);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    fetchOpportunities(controller.signal)
      .then((response) => {
        setItems(response.items);
        const requestedPlatform = defaultPlatform ?? params.get("platform") ?? "all";
        const firstVisible =
          requestedPlatform === "all"
            ? response.items[0]
            : response.items.find((item) => item.platform === requestedPlatform);

        setSelectedId((current) =>
          current && response.items.some((item) => item.id === current)
            ? current
            : firstVisible?.id ?? response.items[0]?.id ?? null
        );
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load opportunities");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingList(false);
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setOpportunity(null);
      setAssessment(null);
      return;
    }

    const controller = new AbortController();
    setLoadingDetail(true);

    Promise.all([
      fetchOpportunity(selectedId, controller.signal),
      fetchOpportunityAssessment(selectedId, controller.signal)
    ])
      .then(([opportunityResponse, assessmentResponse]) => {
        setOpportunity(opportunityResponse);
        setAssessment(assessmentResponse);
        setError(null);

        const next = new URL(window.location.href);
        next.searchParams.set("view", "opportunities");
        next.searchParams.set("opportunity", selectedId);
        window.history.replaceState({}, "", next);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load opportunity detail");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingDetail(false);
      });

    return () => controller.abort();
  }, [selectedId]);

  const platforms = useMemo(
    () => [...new Set(items.map((item) => item.platform))].sort(),
    [items]
  );

  const filtered = useMemo(
    () =>
      items.filter((item) =>
        (platformFilter === "all" || item.platform === platformFilter) &&
        item.score >= minimumScore
      ),
    [items, platformFilter, minimumScore]
  );

  const stats = useMemo(() => {
    const scoped = platformFilter === "all"
      ? items
      : items.filter((item) => item.platform === platformFilter);

    return {
      tracked: scoped.length,
      top: scoped.filter((item) => item.score >= 85).length,
      high: scoped.filter((item) => item.score >= 70).length,
      prize: scoped.reduce((sum, item) => sum + item.prizeUsd, 0)
    };
  }, [items, platformFilter]);

  return (
    <section className="opportunityPage">
      <div className="opportunityHero">
        <div>
          <span className="eyebrow">{defaultPlatform ? "PLATFORM OPPORTUNITIES" : "OPPORTUNITIES"}</span>
          <h1>{defaultPlatform ? defaultPlatform : "Choose where the next hour matters most."}</h1>
          <p>
            Prize, deadline, eligibility and automation constraints are evaluated before research time is committed.
          </p>
        </div>
        <div className="opportunityHeroStats">
          <div><strong>{stats.tracked}</strong><span>Tracked</span></div>
          <div><strong>{stats.top}</strong><span>Top priority</span></div>
          <div><strong>{stats.high}</strong><span>Score 70+</span></div>
          <div><strong>{money(stats.prize)}</strong><span>Visible pool</span></div>
        </div>
      </div>

      {error && <div className="dataState error">{error}</div>}

      <div className="opportunityLayout">
        <aside className="panel opportunityQueue">
          <div className="panelHead opportunityQueueHead">
            <div>
              <span className="eyebrow">EXECUTION QUEUE</span>
              <h2>Ranked Opportunities</h2>
            </div>
          </div>

          <div className="opportunityFilters">
            <label>
              <span>Platform</span>
              <select value={platformFilter} onChange={(event) => setPlatformFilter(event.target.value)}>
                <option value="all">All platforms</option>
                {platforms.map((platform) => <option key={platform}>{platform}</option>)}
              </select>
            </label>
            <label>
              <span>Minimum score</span>
              <select value={minimumScore} onChange={(event) => setMinimumScore(Number(event.target.value))}>
                <option value={0}>Any</option>
                <option value={55}>55+</option>
                <option value={70}>70+</option>
                <option value={85}>85+</option>
              </select>
            </label>
          </div>

          {loadingList && <div className="opportunityEmpty">Loading ranked queue…</div>}
          {!loadingList && filtered.length === 0 && (
            <div className="opportunityEmpty">No opportunities match the current filters.</div>
          )}

          <div className="opportunityCards">
            {filtered.map((item) => (
              <button
                key={item.id}
                className={selectedId === item.id ? "opportunityCard selected" : "opportunityCard"}
                onClick={() => setSelectedId(item.id)}
              >
                <div className="opportunityCardTop">
                  <span className="queuePlatform">{item.platform}</span>
                  <span className={`queueScore score-${item.score >= 85 ? "top" : item.score >= 70 ? "high" : "selective"}`}>
                    {item.score}
                  </span>
                </div>
                <strong>{item.title}</strong>
                <div className="opportunityCardMeta">
                  <span>{money(item.prizeUsd)}</span>
                  <span>{formatDate(item.deadline)}</span>
                  <span>{label(item.status)}</span>
                </div>
              </button>
            ))}
          </div>
        </aside>

        <div className="opportunityDetail">
          {loadingDetail && <div className="panel opportunityEmpty detailLoading">Loading opportunity detail…</div>}

          {!loadingDetail && opportunity && assessment && (
            <>
              <article className="panel opportunitySummary">
                <div className="opportunitySummaryTop">
                  <div>
                    <div className="opportunityBadges">
                      <span className="queuePlatform">{opportunity.platform}</span>
                      <span className={`eligibilityBadge ${eligibilityClass(opportunity.eligibility)}`}>
                        {label(assessment.eligibilityState)}
                      </span>
                    </div>
                    <h2>{opportunity.title}</h2>
                    <p>
                      Current execution status: <strong>{label(opportunity.status)}</strong>
                    </p>
                  </div>

                  <div className={`priorityGauge ${assessment.priorityBand}`}>
                    <strong>{assessment.priorityScore}</strong>
                    <span>Priority score</span>
                    <small>{label(assessment.priorityBand)}</small>
                  </div>
                </div>

                <div className="opportunityMetaGrid">
                  <div><span>Prize</span><strong>{money(opportunity.prizeUsd)}</strong></div>
                  <div><span>Deadline</span><strong>{formatDate(opportunity.deadline)}</strong></div>
                  <div><span>Days remaining</span><strong>{assessment.daysRemaining}</strong></div>
                  <div><span>Execution lane</span><strong>{label(assessment.executionLane)}</strong></div>
                </div>
              </article>

              <section className="signalGrid">
                <SignalCard
                  eyebrow="REWARD"
                  value={label(assessment.rewardTier)}
                  detail={`${money(opportunity.prizeUsd)} advertised prize`}
                  tone="blue"
                />
                <SignalCard
                  eyebrow="DEADLINE"
                  value={label(assessment.deadlineState)}
                  detail={assessment.daysRemaining < 0 ? "Deadline has passed" : `${assessment.daysRemaining} days remaining`}
                  tone={assessment.deadlineState === "urgent" ? "rose" : "gold"}
                />
                <SignalCard
                  eyebrow="ELIGIBILITY"
                  value={label(assessment.eligibilityState)}
                  detail={opportunity.eligibility}
                  tone="violet"
                />
                <SignalCard
                  eyebrow="AUTOMATION"
                  value={label(assessment.automationState)}
                  detail={opportunity.automation}
                  tone="green"
                />
              </section>

              <article className="panel opportunityRules">
                <div className="panelHead researchPanelHead">
                  <div>
                    <span className="eyebrow">DECISION GUARDRAILS</span>
                    <h2>What this score means</h2>
                  </div>
                </div>
                <div className="guardrailBody">
                  <div className="guardrailNote">
                    <strong>Priority score is not a win probability.</strong>
                    <p>{assessment.note}</p>
                  </div>
                  <div className="guardrailRows">
                    <div><span>Eligibility requirement</span><strong>{opportunity.eligibility}</strong></div>
                    <div><span>Automation rule</span><strong>{opportunity.automation}</strong></div>
                    <div><span>Current status</span><strong>{label(opportunity.status)}</strong></div>
                    <div><span>Research commitment</span><strong>Only after eligibility and rule checks pass</strong></div>
                  </div>
                </div>
              </article>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

function SignalCard({
  eyebrow,
  value,
  detail,
  tone
}: {
  eyebrow: string;
  value: string;
  detail: string;
  tone: string;
}) {
  return (
    <article className={`signalCard ${tone}`}>
      <span>{eyebrow}</span>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}
