import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import {
  fetchResearchEvidence,
  fetchResearchExecution,
  fetchResearchLimitations,
  fetchResearchProject,
  fetchResearchProjects
} from "./api";
import type {
  EvidenceItem,
  ResearchExecutionAssessment,
  ResearchLimitation,
  ResearchProject
} from "./types";

function formatDate(value: string | null): string {
  if (!value) return "Not verified";
  return new Date(`${value}T12:00:00`).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function statusLabel(value: string): string {
  return value.replaceAll("-", " ");
}

export default function ResearchWorkspace() {
  const [projects, setProjects] = useState<ResearchProject[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [project, setProject] = useState<ResearchProject | null>(null);
  const [limitations, setLimitations] = useState<ResearchLimitation[]>([]);
  const [evidence, setEvidence] = useState<EvidenceItem[]>([]);
  const [execution, setExecution] = useState<ResearchExecutionAssessment | null>(null);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    fetchResearchProjects(controller.signal)
      .then((response) => {
        setProjects(response.items);
        setSelectedId((current) => current ?? response.items[0]?.id ?? null);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load research projects");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingProjects(false);
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setProject(null);
      setLimitations([]);
      setEvidence([]);
      setExecution(null);
      return;
    }

    const controller = new AbortController();
    setLoadingDetail(true);

    Promise.all([
      fetchResearchProject(selectedId, controller.signal),
      fetchResearchLimitations(selectedId, controller.signal),
      fetchResearchEvidence(selectedId, controller.signal),
      fetchResearchExecution(selectedId, controller.signal)
    ])
      .then(([projectResponse, limitationResponse, evidenceResponse, executionResponse]) => {
        setProject(projectResponse);
        setLimitations(limitationResponse.items);
        setEvidence(evidenceResponse.items);
        setExecution(executionResponse);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load research workspace");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingDetail(false);
      });

    return () => controller.abort();
  }, [selectedId]);

  const coverage = useMemo(() => {
    const open = limitations.filter((item) => item.status === "open").length;
    const covered = limitations.length - open;
    return { open, covered, total: limitations.length };
  }, [limitations]);

  const verifiedEvidence = evidence.filter((item) => item.status === "verified-lead").length;

  return (
    <section className="researchPage">
      <div className="researchHero">
        <div>
          <span className="eyebrow">RESEARCH WORKSPACE</span>
          <h1>Evidence before submission.</h1>
          <p>
            Claim-level requirements, dated sources, proof gaps and evidence quality in one auditable workspace.
          </p>
        </div>
        <div className="researchHeroStats">
          <div><strong>{projects.length}</strong><span>Active projects</span></div>
          <div><strong>{coverage.open}</strong><span>Open proof gaps</span></div>
          <div><strong>{verifiedEvidence}</strong><span>Verified leads</span></div>
        </div>
      </div>

      {error && <div className="dataState error">{error}</div>}

      <div className="researchLayout">
        <aside className="researchProjectList panel">
          <div className="panelHead">
            <div>
              <span className="eyebrow">PROJECTS</span>
              <h2>Research Queue</h2>
            </div>
          </div>

          {loadingProjects && <div className="researchEmpty">Loading projects…</div>}
          {!loadingProjects && projects.length === 0 && (
            <div className="researchEmpty">No research project has been created yet.</div>
          )}

          <div className="projectCards">
            {projects.map((item) => (
              <button
                key={item.id}
                className={selectedId === item.id ? "projectCard selected" : "projectCard"}
                onClick={() => setSelectedId(item.id)}
              >
                <div className="projectCardTop">
                  <span className="projectType">{item.researchType}</span>
                  <span className={`researchStatus ${item.status}`}>{statusLabel(item.status)}</span>
                </div>
                <strong>{item.title}</strong>
                <span>{item.targetClaim ?? "General research"} · cutoff {formatDate(item.cutoffDate)}</span>
                <div className="miniProgress">
                  <i style={{ width: `${item.progress}%` }} />
                </div>
                <small>{item.progress}% research progress</small>
              </button>
            ))}
          </div>
        </aside>

        <div className="researchDetail">
          {loadingDetail && <div className="panel researchEmpty researchLoading">Loading research detail…</div>}

          {!loadingDetail && project && (
            <>
              <article className="panel researchSummary">
                <div className="researchSummaryHead">
                  <div>
                    <span className="eyebrow">CURRENT PROJECT</span>
                    <h2>{project.title}</h2>
                    <p>{project.notes}</p>
                  </div>
                  <div className="progressRing" style={{ "--progress": `${project.progress * 3.6}deg` } as CSSProperties}>
                    <div><strong>{project.progress}%</strong><span>Progress</span></div>
                  </div>
                </div>

                <div className="researchMeta">
                  <div><span>Opportunity</span><strong>{project.opportunityId}</strong></div>
                  <div><span>Target</span><strong>{project.targetClaim ?? "—"}</strong></div>
                  <div><span>Prior-art cutoff</span><strong>{formatDate(project.cutoffDate)}</strong></div>
                  <div><span>Status</span><strong>{statusLabel(project.status)}</strong></div>
                </div>
              </article>

              {execution && (
                <article className="panel executionPanel">
                  <div className="panelHead researchPanelHead">
                    <div>
                      <span className="eyebrow">SUBMISSION READINESS</span>
                      <h2>Research Execution Gate</h2>
                    </div>
                    <div className={`readinessBadge ${execution.readinessStatus}`}>
                      <strong>{execution.readinessScore}%</strong>
                      <span>{statusLabel(execution.readinessStatus)}</span>
                    </div>
                  </div>

                  <div className="executionMetrics">
                    <div><span>Claim coverage</span><strong>{execution.limitationCoveragePercent}%</strong></div>
                    <div><span>Evidence verification</span><strong>{execution.evidenceVerificationPercent}%</strong></div>
                    <div><span>Source traceability</span><strong>{execution.sourceTraceabilityPercent}%</strong></div>
                    <div><span>Hard blockers</span><strong>{execution.blockingIssueCount}</strong></div>
                  </div>

                  <p className="executionFormula">{execution.formula}</p>

                  <div className="executionColumns">
                    <div>
                      <h3>Blocking Issues</h3>
                      <div className="executionList">
                        {execution.issues.slice(0, 8).map((issue) => (
                          <div className={`executionItem ${issue.severity}`} key={issue.code + (issue.relatedId ?? "")}>
                            <strong>{issue.title}</strong>
                            <span>{issue.detail}</span>
                          </div>
                        ))}
                        {execution.issues.length === 0 && <div className="executionEmpty">No execution blockers detected.</div>}
                      </div>
                    </div>
                    <div>
                      <h3>Next Actions</h3>
                      <div className="executionList">
                        {execution.nextActions.slice(0, 8).map((action) => (
                          <div className={`executionItem action ${action.priority}`} key={action.id}>
                            <strong>{action.title}</strong>
                            <span>{action.kind}{action.blocking ? " · blocking" : ""}</span>
                          </div>
                        ))}
                        {execution.nextActions.length === 0 && <div className="executionEmpty">Research is ready for final review.</div>}
                      </div>
                    </div>
                  </div>
                </article>
              )}

              <article className="panel limitationPanel">
                <div className="panelHead researchPanelHead">
                  <div>
                    <span className="eyebrow">CLAIM COVERAGE</span>
                    <h2>Limitations & Proof Gaps</h2>
                  </div>
                  <div className="coverageSummary">
                    <span className="coveredCount">{coverage.covered} covered/leads</span>
                    <span className="openCount">{coverage.open} open</span>
                  </div>
                </div>

                <div className="limitationList">
                  {limitations.map((item) => (
                    <div
                      key={item.id}
                      className={item.status === "open" ? "limitationRow proofGap" : "limitationRow"}
                    >
                      <div className="limitationNumber">{String(item.position).padStart(2, "0")}</div>
                      <div className="limitationBody">
                        <div className="limitationTitle">
                          <strong>{item.limitation}</strong>
                          <span className={`limitationStatus ${item.status}`}>{statusLabel(item.status)}</span>
                        </div>
                        <p>{item.notes}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </article>

              <article className="panel evidencePanel">
                <div className="panelHead researchPanelHead">
                  <div>
                    <span className="eyebrow">EVIDENCE LIBRARY</span>
                    <h2>Current Evidence</h2>
                  </div>
                  <span className="evidenceCount">{evidence.length} items</span>
                </div>

                <div className="tableWrap">
                  <table className="evidenceTable">
                    <thead>
                      <tr>
                        <th>Evidence</th>
                        <th>Source</th>
                        <th>Published</th>
                        <th>Quality</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {evidence.map((item) => (
                        <tr key={item.id}>
                          <td className="evidenceTitle">
                            <strong>{item.title}</strong>
                            <span>{item.relevance}</span>
                          </td>
                          <td><span className="sourceBadge">{item.sourceType}</span></td>
                          <td>{formatDate(item.publishedDate)}</td>
                          <td>
                            <div className="qualityScore">
                              <strong>{item.qualityScore ?? "—"}</strong>
                              {item.qualityScore !== null && <span>/100</span>}
                            </div>
                          </td>
                          <td><span className={`evidenceStatus ${item.status}`}>{statusLabel(item.status)}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </article>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
