import { useEffect, useMemo, useState } from "react";
import { fetchBackups, fetchLatestBackup } from "./api";
import type { BackupRecord } from "./types";

function formatBytes(value: number | null): string {
  if (value === null) return "—";
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${(value / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function formatDateTime(value: string | null): string {
  if (!value) return "Not yet";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function tone(record: BackupRecord): string {
  if (record.status === "failed" || record.verificationStatus === "failed") return "error";
  if (record.status === "pruned") return "pruned";
  if (record.verificationStatus === "verified") return "verified";
  if (record.status === "running") return "running";
  return "pending";
}

export default function BackupWorkspace() {
  const [items, setItems] = useState<BackupRecord[]>([]);
  const [latest, setLatest] = useState<BackupRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    Promise.all([
      fetchBackups(30, controller.signal),
      fetchLatestBackup(controller.signal)
    ])
      .then(([history, latestResponse]) => {
        setItems(history.items);
        setLatest(latestResponse.item);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load backup state");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  const stats = useMemo(() => ({
    retained: items.filter((item) => item.status !== "pruned").length,
    verified: items.filter((item) => item.verificationStatus === "verified").length,
    failed: items.filter((item) => item.status === "failed" || item.verificationStatus === "failed").length,
    totalBytes: items.reduce(
      (sum, item) => sum + (item.databaseBytes ?? 0) + (item.filesBytes ?? 0),
      0
    )
  }), [items]);

  return (
    <section className="backupPage">
      <div className="backupHero">
        <div>
          <span className="eyebrow">BACKUP & RESTORE</span>
          <h1>Protect every research decision before it becomes irreplaceable.</h1>
          <p>
            PostgreSQL data and persistent evidence files are backed up automatically,
            verified, retained, and restorable without a paid cloud dependency.
          </p>
        </div>

        <div className="backupHeroStats">
          <div><strong>{stats.retained}</strong><span>Retained</span></div>
          <div><strong>{stats.verified}</strong><span>Verified</span></div>
          <div><strong>{stats.failed}</strong><span>Failed</span></div>
          <div><strong>{formatBytes(stats.totalBytes)}</strong><span>Tracked size</span></div>
        </div>
      </div>

      {loading && <div className="dataState info">Loading backup state…</div>}
      {error && <div className="dataState error">{error}</div>}

      <div className="backupGrid">
        <article className="panel latestBackupPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">LATEST</span>
              <h2>Latest Backup</h2>
            </div>
          </div>

          {latest ? (
            <div className="latestBackupBody">
              <div className="latestBackupTop">
                <div>
                  <span className="backupKey">{latest.backupKey}</span>
                  <strong>{latest.message}</strong>
                </div>
                <span className={`backupStatus ${tone(latest)}`}>
                  {latest.verificationStatus ?? latest.status}
                </span>
              </div>

              <div className="backupMetaGrid">
                <div><span>Started</span><strong>{formatDateTime(latest.startedAt)}</strong></div>
                <div><span>Finished</span><strong>{formatDateTime(latest.finishedAt)}</strong></div>
                <div><span>Database</span><strong>{formatBytes(latest.databaseBytes)}</strong></div>
                <div><span>Files</span><strong>{formatBytes(latest.filesBytes)}</strong></div>
              </div>

              <div className="backupGuardrail">
                <strong>Restore is intentionally gated.</strong>
                <p>
                  A backup must pass integrity checks and a temporary-database restore
                  verification before any destructive restore is allowed. The system does
                  not expose an unsafe one-click restore button.
                </p>
              </div>
            </div>
          ) : (
            <div className="backupEmpty">No backup has been recorded yet.</div>
          )}
        </article>

        <article className="panel backupPolicyPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">POLICY</span>
              <h2>Protection Rules</h2>
            </div>
          </div>

          <div className="backupPolicyList">
            <Policy title="Automatic schedule" detail="Daily worker job; first run executes as soon as the job is seeded." />
            <Policy title="Retention" detail="Last 10 physical backups retained by default; older backup files are pruned." />
            <Policy title="Database verification" detail="Every pg_dump must pass pg_restore --list before it is marked verified." />
            <Policy title="File verification" detail="Persistent evidence archive must pass tar integrity listing." />
            <Policy title="Restore verification" detail="Selected backup is restored into a temporary PostgreSQL database before production restore." />
            <Policy title="Pre-restore safety copy" detail="A fresh database and files snapshot is created before destructive restore." />
          </div>
        </article>

        <article className="panel backupHistoryPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">HISTORY</span>
              <h2>Backup Records</h2>
            </div>
          </div>

          <div className="backupHistoryTable">
            <div className="backupHistoryHeader">
              <span>Backup</span><span>Status</span><span>Started</span><span>DB</span><span>Files</span><span>Message</span>
            </div>

            {items.map((item) => (
              <div className="backupHistoryRow" key={item.id}>
                <strong>{item.backupKey}</strong>
                <span className={`backupStatus ${tone(item)}`}>
                  {item.verificationStatus ?? item.status}
                </span>
                <span>{formatDateTime(item.startedAt)}</span>
                <span>{formatBytes(item.databaseBytes)}</span>
                <span>{formatBytes(item.filesBytes)}</span>
                <span className="backupMessage">{item.message}</span>
              </div>
            ))}

            {!loading && items.length === 0 && (
              <div className="backupEmpty">Backup history is empty.</div>
            )}
          </div>
        </article>
      </div>
    </section>
  );
}

function Policy({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="backupPolicy">
      <i>✓</i>
      <div>
        <strong>{title}</strong>
        <p>{detail}</p>
      </div>
    </div>
  );
}
