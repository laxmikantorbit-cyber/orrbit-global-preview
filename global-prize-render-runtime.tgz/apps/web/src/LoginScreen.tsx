import { FormEvent, useState } from "react";
import { ownerLogin } from "./api";
import type { AuthSession } from "./types";

export default function LoginScreen({
  onAuthenticated
}: {
  onAuthenticated: (session: AuthSession) => void;
}) {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const session = await ownerLogin(login.trim(), password);
      onAuthenticated(session);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to sign in");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="loginPage">
      <section className="loginCard">
        <div className="loginBrand">
          <div className="brandIcon">◎</div>
          <div>
            <span className="eyebrow">PRIVATE OWNER ACCESS</span>
            <h1>Global Prize Research Engine</h1>
          </div>
        </div>

        <p>
          Sign in to the private command center. Research, submissions,
          automation state and earnings data are not exposed publicly.
        </p>

        <form onSubmit={submit} className="loginForm">
          <label>
            <span>Owner ID</span>
            <input
              autoComplete="username"
              value={login}
              onChange={(event) => setLogin(event.target.value)}
              placeholder="Owner ID"
              required
            />
          </label>

          <label>
            <span>Password</span>
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Password"
              required
            />
          </label>

          {error && <div className="loginError">{error}</div>}

          <button type="submit" disabled={submitting}>
            {submitting ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <div className="loginSecurity">
          <span>● Self-hosted session</span>
          <span>● HttpOnly cookie</span>
          <span>● No third-party auth dependency</span>
        </div>
      </section>
    </main>
  );
}
