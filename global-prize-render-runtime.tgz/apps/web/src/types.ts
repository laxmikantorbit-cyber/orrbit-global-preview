export type Opportunity = {
  id: string;
  platform: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  eligibility: string;
  automation: string;
  score: number;
  status: string;
};

export type OpportunityListResponse = {
  count: number;
  items: Opportunity[];
};

export type PlatformStat = {
  platform: string;
  count: number;
  value: number;
};

export type ResearchProject = {
  id: string;
  opportunityId: string;
  title: string;
  researchType: string;
  status: string;
  progress: number;
  targetClaim: string | null;
  cutoffDate: string | null;
  notes: string;
};

export type ResearchLimitation = {
  id: string;
  researchProjectId: string;
  position: number;
  limitation: string;
  status: string;
  notes: string;
};

export type EvidenceItem = {
  id: string;
  researchProjectId: string;
  limitationId: string | null;
  title: string;
  sourceType: string;
  sourceUrl: string | null;
  publishedDate: string | null;
  relevance: string;
  qualityScore: number | null;
  status: string;
  notes: string;
};

export type ResearchProjectListResponse = {
  count: number;
  items: ResearchProject[];
};

export type ResearchLimitationListResponse = {
  projectId: string;
  count: number;
  items: ResearchLimitation[];
};

export type EvidenceListResponse = {
  projectId: string;
  count: number;
  items: EvidenceItem[];
};

export type OpportunityAssessment = {
  opportunityId: string;
  priorityScore: number;
  priorityBand: "top" | "high" | "selective" | "watch";
  rewardTier: "major" | "high" | "medium" | "base";
  daysRemaining: number;
  deadlineState: "overdue" | "urgent" | "near" | "runway";
  eligibilityState: "account-action" | "review-required" | "stated-ready";
  automationState: "autonomous" | "ai-assisted" | "rules-review";
  executionLane: "patent-prior-art" | "innovation-challenge" | "forecasting" | "general";
  note: string;
};

export type SubmissionItem = {
  id: string;
  opportunityId: string;
  researchProjectId: string | null;
  title: string;
  platform: string;
  status: string;
  deadline: string | null;
  submittedAt: string | null;
  resultStatus: string | null;
  awardUsd: number | null;
  externalReference: string | null;
  notes: string;
};

export type SubmissionListResponse = {
  count: number;
  items: SubmissionItem[];
};

export type AutomationJob = {
  id: string;
  name: string;
  jobType: string;
  enabled: boolean;
  scheduleMinutes: number;
  lastStartedAt: string | null;
  lastFinishedAt: string | null;
  nextRunAt: string;
  lastStatus: string | null;
  lastMessage: string | null;
};

export type AutomationRun = {
  id: number;
  jobId: string;
  startedAt: string;
  finishedAt: string;
  status: string;
  message: string;
  summary: Record<string, unknown>;
};

export type AutomationJobListResponse = {
  count: number;
  items: AutomationJob[];
};

export type AutomationRunListResponse = {
  count: number;
  items: AutomationRun[];
};

export type AuthSession = {
  authenticated: boolean;
  ownerLogin?: string;
  expiresAt?: string;
};

export type BackupRecord = {
  id: number;
  backupKey: string;
  status: string;
  databaseFile: string | null;
  filesArchive: string | null;
  databaseBytes: number | null;
  filesBytes: number | null;
  startedAt: string;
  finishedAt: string | null;
  verifiedAt: string | null;
  verificationStatus: string | null;
  message: string;
};

export type BackupListResponse = {
  count: number;
  items: BackupRecord[];
};

export type LatestBackupResponse = {
  item: BackupRecord | null;
};

export type OpportunitySource = {
  id: string;
  name: string;
  platform: string;
  sourceUrl: string;
  adapterType: string;
  enabled: boolean;
  scanIntervalMinutes: number;
  lastStartedAt: string | null;
  lastFinishedAt: string | null;
  nextScanAt: string;
  lastStatus: string | null;
  lastMessage: string | null;
};

export type OpportunityObservation = {
  id: number;
  sourceId: string;
  externalKey: string;
  canonicalOpportunityId: string | null;
  observedAt: string;
  snapshotHash: string;
  isNew: boolean;
  changedFields: string[];
  payload: Record<string, unknown>;
};

export type ScannerSourceListResponse = {
  count: number;
  items: OpportunitySource[];
};

export type ScannerObservationListResponse = {
  count: number;
  items: OpportunityObservation[];
};

export type ResearchExecutionIssue = {
  code: string;
  title: string;
  detail: string;
  relatedId: string | null;
  severity: "blocking" | "warning";
};

export type ResearchExecutionAction = {
  id: string;
  title: string;
  kind: string;
  priority: "critical" | "high" | "normal";
  blocking: boolean;
  relatedId: string | null;
};

export type ResearchExecutionAssessment = {
  projectId: string;
  readinessScore: number;
  readinessStatus: "blocked" | "researching" | "review-ready" | "submission-ready";
  limitationCoveragePercent: number;
  evidenceVerificationPercent: number;
  sourceTraceabilityPercent: number;
  totalLimitations: number;
  openProofGaps: number;
  totalEvidence: number;
  verifiedEvidence: number;
  blockingIssueCount: number;
  issues: ResearchExecutionIssue[];
  nextActions: ResearchExecutionAction[];
  formula: string;
};

export type SubmissionReadinessIssue = {
  code: string;
  title: string;
  detail: string;
  severity: "blocking" | "review";
};

export type SubmissionReadinessAssessment = {
  submissionId: string;
  state: "blocked" | "review-required" | "ready" | "already-submitted" | "resolved";
  score: number;
  deadlineState: "overdue" | "urgent" | "near" | "runway" | "unknown";
  daysRemaining: number | null;
  researchReadiness: string | null;
  eligibilityReviewRequired: boolean;
  automationReviewRequired: boolean;
  issues: SubmissionReadinessIssue[];
  checks: Array<{
    key: string;
    label: string;
    passed: boolean;
    blocking: boolean;
    detail: string;
  }>;
  note: string;
};

export type ResultsSummary = {
  trackedSubmissions: number;
  submitted: number;
  resolved: number;
  wins: number;
  losses: number;
  pendingResults: number;
  awardedUsd: number;
  averageAwardUsd: number;
  winRatePercent: number | null;
  note: string;
};

export type PlatformReport = {
  platform: string;
  opportunities: number;
  visiblePrizeUsd: number;
  submissions: number;
  submitted: number;
  resolved: number;
  wins: number;
  losses: number;
  awardedUsd: number;
};

export type PortfolioReport = {
  generatedAt: string;
  results: ResultsSummary;
  platforms: PlatformReport[];
  totalVisiblePrizeUsd: number;
  totalOpportunities: number;
};
