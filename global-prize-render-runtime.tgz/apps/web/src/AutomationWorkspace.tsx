import { useEffect, useMemo, useState } from "react";
import { fetchAutomationJobs, fetchAutomationRuns } from "./api";
import type { AutomationJob, AutomationRun } from "./types";

function formatDateTime(value: string | null): string {
  if (!value) return "Not yet";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function statusTone(status: string | null): string {
  if (!status) return "pending";
  if (status === "ok") return "ok";
  if (status === "warning") return "warning";
  if (status === "error") return "error";
  if (status === "running") return "running";
  return "pending";
}

function summaryText(run: AutomationRun): string {
  const summary = run.summary ?? {};
  if (typeof summary.count === "number") return `${summary.count} item(s)`;
  if (typeof summary.violations === "number") return `${summary.violations} violation(s)`;
  return "Recorded";
}

export default function AutomationWorkspace() {
  const [jobs, setJobs] = useState<AutomationJob[]>([]);
  const [runs, setRuns] = useState<AutomationRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    Promise.all([
      fetchAutomationJobs(controller.signal),
      fetchAutomationRuns(25, controller.signal)
    ])
      .then(([jobResponse, runResponse]) => {
        setJobs(jobResponse.items);
        setRuns(runResponse.items);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load automation state");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  const stats = useMemo(() => ({
    enabled: jobs.filter((job) => job.enabled).length,
    healthy: jobs.filter((job) => job.lastStatus === "ok").length,
    warnings: jobs.filter((job) => job.lastStatus === "warning" || job.lastStatus === "error").length,
    runs: runs.length
  }), [jobs, runs]);

  return (
    <section className="automationPage">
      <div className="automationHero">
        <div>
          <span className="eyebrow">SELF-HOSTED AUTOMATION</span>
          <h1>Background work that is visible, auditable and safe.</h1>
          <p>
            Internal worker jobs monitor deadlines and lifecycle integrity. External discovery remains separately governed by platform rules.
          </p>
        </div>
        <div className="automationHeroStats">
          <div><strong>{stats.enabled}</strong><span>Enabled jobs</span></div>
          <div><strong>{stats.healthy}</strong><span>Healthy</span></div>
          <div><strong>{stats.warnings}</strong><span>Warnings</span></div>
          <div><strong>{stats.runs}</strong><span>Recent runs</span></div>
        </div>
      </div>

      {loading && <div className="dataState info">Loading automation state…</div>}
      {error && <div className="dataState error">{error}</div>}

      <div className="automationGrid">
        <article className="panel automationJobsPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">JOBS</span>
              <h2>Worker Schedule</h2>
            </div>
          </div>

          <div className="automationJobList">
            {jobs.map((job) => (
              <div className="automationJobCard" key={job.id}>
                <div className="automationJobTop">
                  <div>
                    <span className="jobType">{job.jobType.replaceAll("-", " ")}</span>
                    <strong>{job.name}</strong>
                  </div>
                  <span className={`jobStatus ${statusTone(job.lastStatus)}`}>
                    {job.enabled ? (job.lastStatus ?? "pending") : "disabled"}
                  </span>
                </div>

                <div className="automationJobMeta">
                  <div><span>Schedule</span><strong>Every {job.scheduleMinutes} min</strong></div>
                  <div><span>Last finished</span><strong>{formatDateTime(job.lastFinishedAt)}</strong></div>
                  <div><span>Next run</span><strong>{formatDateTime(job.nextRunAt)}</strong></div>
                </div>

                <p>{job.lastMessage ?? "No worker message yet."}</p>
              </div>
            ))}

            {!loading && jobs.length === 0 && (
              <div className="automationEmpty">No automation jobs are configured.</div>
            )}
          </div>
        </article>

        <article className="panel automationRulesPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">GUARDRAILS</span>
              <h2>What the worker is allowed to do</h2>
            </div>
          </div>

          <div className="automationRules">
            <Rule
              title="Deadline Watch"
              detail="Reads tracked opportunity deadlines and records due items. It does not predict wins or fabricate urgency."
            />
            <Rule
              title="Submission Integrity"
              detail="Detects inconsistent draft/submitted/result states so the system never overstates an external submission or award."
            />
            <Rule
              title="External Discovery"
              detail="Not performed by this local worker yet. Platform research and AI/automation compliance are handled separately."
            />
          </div>
        </article>

        <article className="panel automationRunsPanel">
          <div className="panelHead researchPanelHead">
            <div>
              <span className="eyebrow">AUDIT LOG</span>
              <h2>Recent Worker Runs</h2>
            </div>
          </div>

          <div className="automationRunsTable">
            <div className="automationRunsHeader">
              <span>Job</span><span>Status</span><span>Finished</span><span>Summary</span><span>Message</span>
            </div>
            {runs.map((run) => (
              <div className="automationRunRow" key={run.id}>
                <strong>{run.jobId}</strong>
                <span className={`jobStatus ${statusTone(run.status)}`}>{run.status}</span>
                <span>{formatDateTime(run.finishedAt)}</span>
                <span>{summaryText(run)}</span>
                <span className="runMessage">{run.message}</span>
              </div>
            ))}
            {!loading && runs.length === 0 && (
              <div className="automationEmpty">No worker run has been recorded yet.</div>
            )}
          </div>
        </article>
      </div>
    </section>
  );
}

function Rule({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="automationRule">
      <i>✓</i>
      <div><strong>{title}</strong><p>{detail}</p></div>
    </div>
  );
}
