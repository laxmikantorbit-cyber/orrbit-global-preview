import { useEffect, useMemo, useState } from "react";
import { fetchResearchEvidence, fetchResearchProjects } from "./api";
import type { EvidenceItem, ResearchProject } from "./types";

type IndexedEvidence = EvidenceItem & {
  projectId: string;
  projectTitle: string;
};

function formatDate(value: string | null): string {
  if (!value) return "Undated";
  return new Date(`${value}T12:00:00`).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function label(value: string): string {
  return value.replaceAll("-", " ");
}

export default function KnowledgeBaseWorkspace() {
  const [projects, setProjects] = useState<ResearchProject[]>([]);
  const [evidence, setEvidence] = useState<IndexedEvidence[]>([]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    fetchResearchProjects(controller.signal)
      .then(async (response) => {
        setProjects(response.items);

        const evidenceResponses = await Promise.all(
          response.items.map(async (project) => {
            const result = await fetchResearchEvidence(project.id, controller.signal);
            return result.items.map((item) => ({
              ...item,
              projectId: project.id,
              projectTitle: project.title
            }));
          })
        );

        setEvidence(evidenceResponses.flat());
        setError(null);
      })
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load knowledge base");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    return evidence.filter((item) => {
      const statusMatch = statusFilter === "all" || item.status === statusFilter;
      if (!statusMatch) return false;
      if (!q) return true;

      return [
        item.title,
        item.relevance,
        item.sourceType,
        item.notes,
        item.projectTitle,
        item.sourceUrl ?? ""
      ].join(" ").toLowerCase().includes(q);
    });
  }, [evidence, query, statusFilter]);

  const statuses = useMemo(
    () => [...new Set(evidence.map((item) => item.status))].sort(),
    [evidence]
  );

  const verified = evidence.filter((item) =>
    ["verified", "verified-lead"].includes(item.status)
  ).length;
  const traceable = evidence.filter((item) => Boolean(item.sourceUrl)).length;

  return (
    <section className="knowledgePage">
      <div className="knowledgeHero">
        <div>
          <span className="eyebrow">KNOWLEDGE BASE</span>
          <h1>Reuse verified evidence instead of researching the same ground twice.</h1>
          <p>
            Research evidence, provenance, dates, quality and project context are indexed
            into one internal corpus for future prize work.
          </p>
        </div>
        <div className="knowledgeHeroStats">
          <div><strong>{projects.length}</strong><span>Projects</span></div>
          <div><strong>{evidence.length}</strong><span>Evidence items</span></div>
          <div><strong>{verified}</strong><span>Verified</span></div>
          <div><strong>{traceable}</strong><span>Source-linked</span></div>
        </div>
      </div>

      {loading && <div className="dataState info">Indexing research evidence…</div>}
      {error && <div className="dataState error">{error}</div>}

      <article className="panel knowledgePanel">
        <div className="knowledgeFilters">
          <label className="knowledgeSearch">
            <span>⌕</span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search evidence, project, source, notes or URL…"
            />
          </label>

          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
            <option value="all">All statuses</option>
            {statuses.map((status) => (
              <option value={status} key={status}>{label(status)}</option>
            ))}
          </select>
        </div>

        <div className="knowledgeTable">
          <div className="knowledgeRow knowledgeHeader">
            <span>Evidence</span><span>Project</span><span>Source</span><span>Date</span><span>Quality</span><span>Status</span>
          </div>

          {filtered.map((item) => (
            <div className="knowledgeRow" key={item.id}>
              <div className="knowledgeEvidence">
                <strong>{item.title}</strong>
                <span>{item.relevance}</span>
              </div>
              <span>{item.projectTitle}</span>
              <div>
                <strong>{item.sourceType}</strong>
                {item.sourceUrl ? (
                  <a href={item.sourceUrl} target="_blank" rel="noreferrer">Open source ↗</a>
                ) : (
                  <small>No URL recorded</small>
                )}
              </div>
              <span>{formatDate(item.publishedDate)}</span>
              <span>{item.qualityScore === null ? "—" : `${item.qualityScore}/100`}</span>
              <span className={`knowledgeStatus ${item.status}`}>{label(item.status)}</span>
            </div>
          ))}

          {!loading && filtered.length === 0 && (
            <div className="knowledgeEmpty">No evidence matches the current filters.</div>
          )}
        </div>
      </article>
    </section>
  );
}
