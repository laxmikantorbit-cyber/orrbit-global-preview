import { useEffect, useState } from "react";
import { fetchResultsSummary } from "./api";
import type { ResultsSummary } from "./types";

function money(value: number): string {
  return `$${value.toLocaleString()}`;
}

export default function ResultsWorkspace() {
  const [summary, setSummary] = useState<ResultsSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    fetchResultsSummary(controller.signal)
      .then(setSummary)
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load results");
      });
    return () => controller.abort();
  }, []);

  if (error) return <section className="resultsPage"><div className="dataState error">{error}</div></section>;
  if (!summary) return <section className="resultsPage"><div className="dataState info">Loading recorded results…</div></section>;

  return (
    <section className="resultsPage">
      <div className="resultsHero">
        <div>
          <span className="eyebrow">RESULTS & EARNINGS</span>
          <h1>Count only recorded outcomes. Never confuse prize pool with earnings.</h1>
          <p>{summary.note}</p>
        </div>
        <div className="resultsHeroStats">
          <div><strong>{summary.submitted}</strong><span>Submitted</span></div>
          <div><strong>{summary.resolved}</strong><span>Resolved</span></div>
          <div><strong>{summary.wins}</strong><span>Wins</span></div>
          <div><strong>{money(summary.awardedUsd)}</strong><span>Recorded awards</span></div>
        </div>
      </div>

      <div className="resultsGrid">
        <article className="panel resultCard"><span>Tracked submissions</span><strong>{summary.trackedSubmissions}</strong><small>Includes drafts and active work.</small></article>
        <article className="panel resultCard"><span>Pending results</span><strong>{summary.pendingResults}</strong><small>Submitted but no result recorded yet.</small></article>
        <article className="panel resultCard"><span>Losses</span><strong>{summary.losses}</strong><small>Only explicit recorded lost results.</small></article>
        <article className="panel resultCard"><span>Average award</span><strong>{money(summary.averageAwardUsd)}</strong><small>Across recorded wins only.</small></article>
        <article className="panel resultCard"><span>Win rate</span><strong>{summary.winRatePercent === null ? "—" : `${summary.winRatePercent}%`}</strong><small>Resolved submissions only; not a forecast.</small></article>
      </div>

      <article className="panel earningsGuardrail">
        <span className="eyebrow">ACCOUNTING GUARDRAIL</span>
        <h2>What is treated as earnings</h2>
        <p>
          Only submissions with a recorded <b>won</b> result and an award amount are counted.
          Visible prize pools, research scores, readiness scores, pending contests and estimates are excluded.
        </p>
      </article>
    </section>
  );
}
