import { useEffect, useMemo, useState } from "react";
import { fetchAuthSession, fetchOpportunities, fetchResearchProjects, fetchResultsSummary, ownerLogout } from "./api";
import AutomationWorkspace from "./AutomationWorkspace";
import BackupWorkspace from "./BackupWorkspace";
import KnowledgeBaseWorkspace from "./KnowledgeBaseWorkspace";
import LoginScreen from "./LoginScreen";
import OpportunitiesWorkspace from "./OpportunitiesWorkspace";
import ResearchWorkspace from "./ResearchWorkspace";
import ReportsWorkspace from "./ReportsWorkspace";
import ResultsWorkspace from "./ResultsWorkspace";
import ScannerWorkspace from "./ScannerWorkspace";
import SubmissionsWorkspace from "./SubmissionsWorkspace";
import type { AuthSession, Opportunity, PlatformStat, ResearchProject, ResultsSummary } from "./types";
import "./styles.css";

const navItems = [
  "Dashboard", "Opportunities", "Scanner", "Research Workspace", "PATROLL",
  "Wazoku / InnoCentive", "Metaculus", "DrivenData", "Devpost",
  "Knowledge Base", "Automation", "Backup & Restore", "Submissions", "Results & Earnings", "Reports"
];

const platformNavMap: Record<string, string> = {
  "PATROLL": "PATROLL",
  "Wazoku / InnoCentive": "InnoCentive/Wazoku",
  "Metaculus": "Metaculus FutureEval",
  "DrivenData": "DrivenData",
  "Devpost": "Devpost"
};

const navByPlatform = Object.fromEntries(
  Object.entries(platformNavMap).map(([nav, platform]) => [platform, nav])
) as Record<string, string>;

function money(value: number): string {
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

function platformClass(platform: string): string {
  return platform.toLowerCase().replace(/[^a-z]+/g, "-");
}

function daysRemaining(deadline: string): number {
  const end = new Date(`${deadline}T23:59:59`);
  const now = new Date();
  return Math.ceil((end.getTime() - now.getTime()) / 86_400_000);
}

export default function App() {
  const [authSession, setAuthSession] = useState<AuthSession | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [activeNav, setActiveNav] = useState(() => {
    const view = new URLSearchParams(window.location.search).get("view");
    if (view === "research") return "Research Workspace";
    if (view === "opportunities") {
      const platform = new URLSearchParams(window.location.search).get("platform");
      return platform ? (navByPlatform[platform] ?? "Opportunities") : "Opportunities";
    }
    if (view === "scanner") return "Scanner";
    if (view === "automation") return "Automation";
    if (view === "backups") return "Backup & Restore";
    if (view === "knowledge") return "Knowledge Base";
    if (view === "submissions") return "Submissions";
    if (view === "results") return "Results & Earnings";
    if (view === "reports") return "Reports";
    return "Dashboard";
  });
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [researchProjects, setResearchProjects] = useState<ResearchProject[]>([]);
  const [resultsSummary, setResultsSummary] = useState<ResultsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    fetchAuthSession(controller.signal)
      .then((session) => {
        setAuthSession(session);
        setAuthError(null);
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setAuthSession({ authenticated: false });
        setAuthError(error instanceof Error ? error.message : "Unable to check owner session");
      })
      .finally(() => {
        if (!controller.signal.aborted) setAuthLoading(false);
      });

    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!authSession?.authenticated) {
      setOpportunities([]);
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    setLoading(true);

    Promise.all([
      fetchOpportunities(controller.signal),
      fetchResultsSummary(controller.signal),
      fetchResearchProjects(controller.signal)
    ])
      .then(([opportunityResponse, resultsResponse, researchResponse]) => {
        setOpportunities(opportunityResponse.items);
        setResultsSummary(resultsResponse);
        setResearchProjects(researchResponse.items);
        setLoadError(null);
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setLoadError(error instanceof Error ? error.message : "Unable to load opportunities");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [authSession?.authenticated]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q
      ? opportunities.filter((x) => [x.title, x.platform, x.status].join(" ").toLowerCase().includes(q))
      : opportunities;
  }, [search, opportunities]);

  const stats = useMemo<PlatformStat[]>(() => {
    const map = new Map<string, PlatformStat>();
    for (const item of opportunities) {
      const current = map.get(item.platform) ?? { platform: item.platform, count: 0, value: 0 };
      current.count += 1;
      current.value += item.prizeUsd;
      map.set(item.platform, current);
    }
    return [...map.values()].sort((a, b) => b.value - a.value);
  }, [opportunities]);

  const totalPool = opportunities.reduce((sum, x) => sum + x.prizeUsd, 0);
  const inProgress = opportunities.filter((x) => !["watch", "done"].includes(x.status.toLowerCase())).length;

  function handleNav(item: string): void {
    setActiveNav(item);
    setMobileNavOpen(false);
    const next = new URL(window.location.href);

    if (!platformNavMap[item]) {
      next.searchParams.delete("platform");
    }

    if (item === "Research Workspace") {
      next.searchParams.set("view", "research");
      next.searchParams.delete("platform");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Opportunities") {
      next.searchParams.set("view", "opportunities");
      next.searchParams.delete("platform");
      next.searchParams.delete("submission");
    } else if (platformNavMap[item]) {
      next.searchParams.set("view", "opportunities");
      next.searchParams.set("platform", platformNavMap[item]);
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Scanner") {
      next.searchParams.set("view", "scanner");
      next.searchParams.delete("platform");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Automation") {
      next.searchParams.set("view", "automation");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Knowledge Base") {
      next.searchParams.set("view", "knowledge");
      next.searchParams.delete("platform");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Backup & Restore") {
      next.searchParams.set("view", "backups");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Submissions") {
      next.searchParams.set("view", "submissions");
      next.searchParams.delete("opportunity");
    } else if (item === "Results & Earnings") {
      next.searchParams.set("view", "results");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Reports") {
      next.searchParams.set("view", "reports");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    } else if (item === "Dashboard") {
      next.searchParams.delete("view");
      next.searchParams.delete("opportunity");
      next.searchParams.delete("submission");
    }

    window.history.replaceState({}, "", next);
  }

  async function handleLogout(): Promise<void> {
    try {
      await ownerLogout();
      setAuthSession({ authenticated: false });
      setOpportunities([]);
      setActiveNav("Dashboard");

      const next = new URL(window.location.href);
      next.search = "";
      window.history.replaceState({}, "", next);
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : "Unable to sign out");
    }
  }

  if (authLoading) {
    return (
      <main className="loginPage">
        <section className="loginCard loginLoading">
          <div className="brandIcon">◎</div>
          <span>Checking private owner session…</span>
        </section>
      </main>
    );
  }

  if (!authSession?.authenticated) {
    return (
      <>
        <LoginScreen
          onAuthenticated={(session) => {
            setAuthSession(session);
            setAuthError(null);
          }}
        />
        {authError && <div className="loginSystemError">{authError}</div>}
      </>
    );
  }

  return (
    <div className="shell">
      <aside className={mobileNavOpen ? "sidebar mobileOpen" : "sidebar"}>
        <button className="mobileNavClose" type="button" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)}>×</button>
        <div className="brand">
          <div className="brandIcon">◎</div>
          <div>
            <strong>Global Prize</strong>
            <span>Research Engine</span>
          </div>
        </div>
        <div className="brandTag">Find · Research · Solve · Win</div>

        <nav>
          {navItems.map((item, index) => (
            <button
              className={activeNav === item ? "navItem active" : "navItem"}
              key={item}
              onClick={() => handleNav(item)}
            >
              <span>{["⌂","🏆","⌁","▤","🛡","◉","↗","◫","⌘","▱","⚙","⇩","⇧","▥","☷"][index]}</span>
              {item}
            </button>
          ))}
        </nav>

        <div className="sideNote">
          <strong>Zero-budget · Global-first</strong>
          <span>Compound knowledge creates leverage.</span>
        </div>
      </aside>
      <button
        className={mobileNavOpen ? "mobileBackdrop show" : "mobileBackdrop"}
        type="button"
        aria-label="Close navigation"
        onClick={() => setMobileNavOpen(false)}
      />

      <main className="main">
        <header className="topbar">
          <button
            className="mobileMenuButton"
            type="button"
            aria-label="Open navigation"
            aria-expanded={mobileNavOpen}
            onClick={() => setMobileNavOpen(true)}
          >
            ☰
          </button>
          <label className="searchBox">
            <span>⌕</span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search opportunities, patents, datasets or documents..."
            />
          </label>
          <div className="topActions">
            <span className="online"><i />AI + DC Online</span>
            <span className="ownerPill">{authSession.ownerLogin ?? "Owner"}</span>
            <button className="logoutButton" onClick={() => void handleLogout()}>Sign out</button>
            <span className="date">{new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date())}</span>
          </div>
        </header>

        {activeNav === "Research Workspace" ? (
          <ResearchWorkspace />
        ) : activeNav === "Opportunities" ? (
          <OpportunitiesWorkspace />
        ) : platformNavMap[activeNav] ? (
          <OpportunitiesWorkspace key={activeNav} defaultPlatform={platformNavMap[activeNav]} />
        ) : activeNav === "Scanner" ? (
          <ScannerWorkspace />
        ) : activeNav === "Automation" ? (
          <AutomationWorkspace />
        ) : activeNav === "Knowledge Base" ? (
          <KnowledgeBaseWorkspace />
        ) : activeNav === "Backup & Restore" ? (
          <BackupWorkspace />
        ) : activeNav === "Submissions" ? (
          <SubmissionsWorkspace />
        ) : activeNav === "Results & Earnings" ? (
          <ResultsWorkspace />
        ) : activeNav === "Reports" ? (
          <ReportsWorkspace />
        ) : (
          <>
        <section className="hero">
          <div>
            <span className="eyebrow">GLOBAL RESEARCH COMMAND CENTER</span>
            <h1>Find the best problems.<br />Build the strongest evidence.</h1>
            <p>One worldwide pipeline for prizes, bounties, prior-art research and autonomous forecasting.</p>
          </div>
          <div className="mission">
            <span>Current mission</span>
            <strong>Maximize Prize Capture</strong>
            <small>No sales · No ads · Zero-budget-first</small>
          </div>
        </section>

        {loading && <div className="dataState info">Loading live opportunity data…</div>}
        {loadError && <div className="dataState error">Opportunity API unavailable: {loadError}</div>}

        <section className="kpis">
          <Kpi tone="blue" label="Active Opportunities" value={String(opportunities.length)} meta="Live tracked queue" />
          <Kpi tone="green" label="In Progress" value={String(inProgress)} meta="Research + setup" />
          <Kpi tone="violet" label="Tracked Submissions" value={String(resultsSummary?.trackedSubmissions ?? 0)} meta="Drafts + submitted + results" />
          <Kpi tone="gold" label="Wins" value={String(resultsSummary?.wins ?? 0)} meta="Recorded results only" />
          <Kpi tone="rose" label="Visible Prize Pool" value={money(totalPool)} meta="Current tracked queue" />
        </section>

        <section className="grid">
          <article className="panel opportunities">
            <PanelTitle eyebrow="PRIORITIZED" title="Top Opportunities" action="View all →" />
            <div className="tableWrap">
              <table>
                <thead>
                  <tr><th>#</th><th>Opportunity</th><th>Platform</th><th>Prize</th><th>Deadline</th><th>Score</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {filtered.map((item, index) => (
                    <tr key={item.id}>
                      <td>{index + 1}</td>
                      <td className="opTitle">{item.title}</td>
                      <td><span className={`platform ${platformClass(item.platform)}`}>{item.platform}</span></td>
                      <td><strong>{money(item.prizeUsd)}</strong></td>
                      <td>{new Date(item.deadline).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}</td>
                      <td className="score">{item.score}</td>
                      <td><span className="status">{item.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </article>

          <article className="panel pipeline">
            <PanelTitle eyebrow="VALUE MIX" title="Opportunity Pipeline" />
            <div className="donut" style={{ "--wazoku": "42%", "--patroll": "8%" } as React.CSSProperties}>
              <div><strong>{money(totalPool)}</strong><small>Total tracked</small></div>
            </div>
            <div className="legend">
              {stats.map((stat) => (
                <div key={stat.platform}>
                  <i className={platformClass(stat.platform)} />
                  <span>{stat.platform}</span>
                  <strong>{totalPool ? Math.round((stat.value / totalPool) * 100) : 0}%</strong>
                </div>
              ))}
            </div>
          </article>

          <article className="panel quick">
            <PanelTitle eyebrow="CONTROL" title="Quick Actions" />
            {[
              { label: "⚡ View Scanner", nav: "Scanner" },
              { label: "▤ Research Workspace", nav: "Research Workspace" },
              { label: "＋ Knowledge Base", nav: "Knowledge Base" },
              { label: "✓ Track Submission", nav: "Submissions" },
              { label: "▥ View Reports", nav: "Reports" }
            ].map((item, index) => (
              <button
                className={index === 0 ? "primaryAction" : ""}
                key={item.label}
                onClick={() => handleNav(item.nav)}
              >
                {item.label}
              </button>
            ))}
          </article>

          <article className="panel progress">
            <PanelTitle eyebrow="MOMENTUM" title="Research Progress" />
            <div className="dashboardResearchList">
              {researchProjects.slice(0, 6).map((project) => (
                <button
                  className="dashboardResearchRow"
                  key={project.id}
                  onClick={() => handleNav("Research Workspace")}
                >
                  <div>
                    <strong>{project.title}</strong>
                    <span>{project.targetClaim ?? project.researchType} · {project.status.replaceAll("-", " ")}</span>
                  </div>
                  <b>{project.progress}%</b>
                  <div className="dashboardResearchBar"><i style={{ width: `${project.progress}%` }} /></div>
                </button>
              ))}
              {!loading && researchProjects.length === 0 && (
                <div className="dashboardEmpty">No research project is currently tracked.</div>
              )}
            </div>
          </article>

          <article className="panel deadlines">
            <PanelTitle eyebrow="TIME SENSITIVE" title="Upcoming Deadlines" />
            <div className="deadlineList">
              {opportunities
                .filter((item) => daysRemaining(item.deadline) >= 0)
                .slice()
                .sort((a,b) => a.deadline.localeCompare(b.deadline))
                .slice(0,4)
                .map((item) => (
                <div className="deadlineRow" key={item.id}>
                  <div className="calendar"><span>{new Date(`${item.deadline}T12:00:00`).toLocaleDateString("en", { month: "short" }).toUpperCase()}</span><strong>{new Date(`${item.deadline}T12:00:00`).getDate()}</strong></div>
                  <div><strong>{item.title}</strong><span>{item.platform} · {money(item.prizeUsd)}</span></div>
                  <b>{daysRemaining(item.deadline)} days</b>
                </div>
              ))}
            </div>
          </article>

          <article className="panel activity">
            <PanelTitle eyebrow="LIVE STATE" title="Operational Checkpoints" />
            <div className="activityList">
              <Activity tone="green" title="Opportunity queue loaded" detail={`${opportunities.length} tracked opportunity item(s)`} />
              <Activity tone="blue" title="Research queue loaded" detail={`${researchProjects.length} research project(s)`} />
              <Activity tone="violet" title="Submission tracker loaded" detail={`${resultsSummary?.trackedSubmissions ?? 0} tracked submission item(s)`} />
              <Activity tone="gold" title="Recorded awards" detail={money(resultsSummary?.awardedUsd ?? 0)} />
            </div>
          </article>
        </section>

        <section className="bottom">
          <article className="panel platforms">
            <PanelTitle eyebrow="COVERAGE" title="Platforms Overview" />
            <div className="platformCards">
              {stats.map((stat) => (
                <div className="platformCard" key={stat.platform}>
                  <strong>{stat.platform}</strong>
                  <span>{stat.count} tracked</span>
                  <span>{money(stat.value)} visible pool</span>
                </div>
              ))}
            </div>
          </article>

          <article className="automationPanel">
            <div><span className="rocket">↗</span><div><span className="eyebrow">AUTOMATION</span><h2>Global scanner jobs are configured</h2><p>PATROLL · Metaculus · Wazoku · DrivenData · Devpost · deadline watch · backups.</p></div></div>
            <span className="configured">CONFIGURED</span>
          </article>
        </section>
          </>
        )}
      </main>
    </div>
  );
}

function Kpi({ tone, label, value, meta }: { tone: string; label: string; value: string; meta: string }) {
  return <article className={`kpi ${tone}`}><div className="kpiIcon">◎</div><div><span>{label}</span><strong>{value}</strong><small>{meta}</small></div></article>;
}

function PanelTitle({ eyebrow, title, action }: { eyebrow: string; title: string; action?: string }) {
  return <div className="panelHead"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>{action && <span className="panelAction">{action}</span>}</div>;
}

function Activity({ tone, title, detail }: { tone: string; title: string; detail: string }) {
  return <div className="activityRow"><i className={tone} /><div><strong>{title}</strong><span>{detail}</span></div></div>;
}
