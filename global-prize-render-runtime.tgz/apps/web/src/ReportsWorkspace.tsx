import { useEffect, useState } from "react";
import { fetchPortfolioReport } from "./api";
import type { PortfolioReport } from "./types";

function money(value: number): string {
  if (value >= 1000) return `$${Math.round(value / 1000)}K`;
  return `$${value.toLocaleString()}`;
}

export default function ReportsWorkspace() {
  const [report, setReport] = useState<PortfolioReport | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    fetchPortfolioReport(controller.signal)
      .then(setReport)
      .catch((caught: unknown) => {
        if (controller.signal.aborted) return;
        setError(caught instanceof Error ? caught.message : "Unable to load report");
      });
    return () => controller.abort();
  }, []);

  if (error) return <section className="reportsPage"><div className="dataState error">{error}</div></section>;
  if (!report) return <section className="reportsPage"><div className="dataState info">Building portfolio report…</div></section>;

  return (
    <section className="reportsPage">
      <div className="reportsHero">
        <div>
          <span className="eyebrow">PORTFOLIO REPORT</span>
          <h1>Opportunity value, submission activity and realized awards in one view.</h1>
          <p>Generated {new Date(report.generatedAt).toLocaleString("en-GB")}. Visible prize value stays separate from realized awards.</p>
        </div>
        <div className="reportsHeroStats">
          <div><strong>{report.totalOpportunities}</strong><span>Opportunities</span></div>
          <div><strong>{money(report.totalVisiblePrizeUsd)}</strong><span>Visible prize pool</span></div>
          <div><strong>{report.results.wins}</strong><span>Recorded wins</span></div>
          <div><strong>{money(report.results.awardedUsd)}</strong><span>Awards</span></div>
        </div>
      </div>

      <article className="panel reportTablePanel">
        <div className="panelHead researchPanelHead">
          <div><span className="eyebrow">PLATFORM PERFORMANCE</span><h2>Portfolio by Platform</h2></div>
        </div>
        <div className="reportTable">
          <div className="reportRow reportHeader">
            <span>Platform</span><span>Opps</span><span>Visible prize</span><span>Tracked subs</span><span>Submitted</span><span>Resolved</span><span>Wins</span><span>Awards</span>
          </div>
          {report.platforms.map((item) => (
            <div className="reportRow" key={item.platform}>
              <strong>{item.platform}</strong>
              <span>{item.opportunities}</span>
              <span>{money(item.visiblePrizeUsd)}</span>
              <span>{item.submissions}</span>
              <span>{item.submitted}</span>
              <span>{item.resolved}</span>
              <span>{item.wins}</span>
              <span>{money(item.awardedUsd)}</span>
            </div>
          ))}
        </div>
      </article>
    </section>
  );
}
