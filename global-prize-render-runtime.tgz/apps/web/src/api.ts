import type {
  AuthSession,
  AutomationJobListResponse,
  AutomationRunListResponse,
  BackupListResponse,
  LatestBackupResponse,
  EvidenceListResponse,
  Opportunity,
  OpportunityAssessment,
  OpportunityListResponse,
  ResearchExecutionAssessment,
  ResearchLimitationListResponse,
  ResearchProject,
  ResearchProjectListResponse,
  ResultsSummary,
  ScannerObservationListResponse,
  ScannerSourceListResponse,
  SubmissionItem,
  SubmissionListResponse,
  SubmissionReadinessAssessment,
  PortfolioReport
} from "./types";

async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(path, {
    method: "GET",
    headers: {
      accept: "application/json"
    },
    cache: "no-store",
    signal
  });

  if (!response.ok) {
    throw new Error(`API request failed with status ${response.status}: ${path}`);
  }

  return await response.json() as T;
}

export function fetchAuthSession(signal?: AbortSignal): Promise<AuthSession> {
  return getJson<AuthSession>("/api/auth/session", signal);
}

export async function ownerLogin(
  ownerLogin: string,
  password: string
): Promise<AuthSession> {
  const response = await fetch("/api/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json"
    },
    body: JSON.stringify({ ownerLogin, password })
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({})) as { error?: string };
    throw new Error(body.error === "invalid_credentials"
      ? "Invalid owner ID or password"
      : "Unable to sign in");
  }

  return await response.json() as AuthSession;
}

export async function ownerLogout(): Promise<void> {
  const response = await fetch("/api/auth/logout", {
    method: "POST",
    headers: { accept: "application/json" }
  });

  if (!response.ok) {
    throw new Error("Unable to sign out");
  }
}

export function fetchScannerSources(signal?: AbortSignal): Promise<ScannerSourceListResponse> {
  return getJson<ScannerSourceListResponse>("/api/scanner/sources", signal);
}

export function fetchScannerObservations(
  limit = 50,
  signal?: AbortSignal
): Promise<ScannerObservationListResponse> {
  return getJson<ScannerObservationListResponse>(
    `/api/scanner/observations?limit=${encodeURIComponent(String(limit))}`,
    signal
  );
}

export function fetchOpportunities(signal?: AbortSignal): Promise<OpportunityListResponse> {
  return getJson<OpportunityListResponse>("/api/opportunities", signal);
}

export function fetchOpportunity(
  opportunityId: string,
  signal?: AbortSignal
): Promise<Opportunity> {
  return getJson<Opportunity>(
    `/api/opportunities/${encodeURIComponent(opportunityId)}`,
    signal
  );
}

export function fetchOpportunityAssessment(
  opportunityId: string,
  signal?: AbortSignal
): Promise<OpportunityAssessment> {
  return getJson<OpportunityAssessment>(
    `/api/opportunities/${encodeURIComponent(opportunityId)}/assessment`,
    signal
  );
}

export function fetchBackups(
  limit = 20,
  signal?: AbortSignal
): Promise<BackupListResponse> {
  return getJson<BackupListResponse>(
    `/api/backups?limit=${encodeURIComponent(String(limit))}`,
    signal
  );
}

export function fetchLatestBackup(signal?: AbortSignal): Promise<LatestBackupResponse> {
  return getJson<LatestBackupResponse>("/api/backups/latest", signal);
}

export function fetchAutomationJobs(signal?: AbortSignal): Promise<AutomationJobListResponse> {
  return getJson<AutomationJobListResponse>("/api/automation/jobs", signal);
}

export function fetchAutomationRuns(
  limit = 20,
  signal?: AbortSignal
): Promise<AutomationRunListResponse> {
  return getJson<AutomationRunListResponse>(
    `/api/automation/runs?limit=${encodeURIComponent(String(limit))}`,
    signal
  );
}

export function fetchSubmissions(signal?: AbortSignal): Promise<SubmissionListResponse> {
  return getJson<SubmissionListResponse>("/api/submissions", signal);
}

export function fetchSubmission(
  submissionId: string,
  signal?: AbortSignal
): Promise<SubmissionItem> {
  return getJson<SubmissionItem>(
    `/api/submissions/${encodeURIComponent(submissionId)}`,
    signal
  );
}

export function fetchSubmissionReadiness(
  submissionId: string,
  signal?: AbortSignal
): Promise<SubmissionReadinessAssessment> {
  return getJson<SubmissionReadinessAssessment>(
    `/api/submissions/${encodeURIComponent(submissionId)}/readiness`,
    signal
  );
}

export function fetchResultsSummary(signal?: AbortSignal): Promise<ResultsSummary> {
  return getJson<ResultsSummary>("/api/results/summary", signal);
}

export function fetchPortfolioReport(signal?: AbortSignal): Promise<PortfolioReport> {
  return getJson<PortfolioReport>("/api/reports/portfolio", signal);
}

export function fetchResearchProjects(signal?: AbortSignal): Promise<ResearchProjectListResponse> {
  return getJson<ResearchProjectListResponse>("/api/research/projects", signal);
}

export function fetchResearchProject(
  projectId: string,
  signal?: AbortSignal
): Promise<ResearchProject> {
  return getJson<ResearchProject>(
    `/api/research/projects/${encodeURIComponent(projectId)}`,
    signal
  );
}

export function fetchResearchLimitations(
  projectId: string,
  signal?: AbortSignal
): Promise<ResearchLimitationListResponse> {
  return getJson<ResearchLimitationListResponse>(
    `/api/research/projects/${encodeURIComponent(projectId)}/limitations`,
    signal
  );
}

export function fetchResearchEvidence(
  projectId: string,
  signal?: AbortSignal
): Promise<EvidenceListResponse> {
  return getJson<EvidenceListResponse>(
    `/api/research/projects/${encodeURIComponent(projectId)}/evidence`,
    signal
  );
}

export function fetchResearchExecution(
  projectId: string,
  signal?: AbortSignal
): Promise<ResearchExecutionAssessment> {
  return getJson<ResearchExecutionAssessment>(
    `/api/research/projects/${encodeURIComponent(projectId)}/execution`,
    signal
  );
}
