UPDATE research_projects
SET
  progress = 68,
  status = 'researching',
  notes = 'Issued Claim 1 corrected to seven limitations. Pre-cutoff FlowVisor paper/source code strongly maps most limitations. Shared-resource determination/isolated-consumption mapping and PATROLL known-reference review remain required.',
  updated_at = NOW()
WHERE id = 'research-arc-link-claim1';

DELETE FROM research_limitations
WHERE id = 'arc-l1-08'
  AND research_project_id = 'research-arc-link-claim1';

UPDATE research_limitations SET
  limitation = 'Computing apparatus implemented with a network hypervisor implementing SDN-based network virtualization.',
  status = 'covered',
  notes = 'FlowVisor is documented as a network hypervisor/proxy and slicing layer.',
  updated_at = NOW()
WHERE id = 'arc-l1-01';

UPDATE research_limitations SET
  limitation = 'Multiple separately managed virtual networks operate over shared physical network resources.',
  status = 'covered',
  notes = 'FlowVisor delegates slices to separate controllers while sharing physical forwarding infrastructure.',
  updated_at = NOW()
WHERE id = 'arc-l1-02';
UPDATE research_limitations SET
  limitation = 'Receive a request for individual physical-resource consumption statistics for a first virtual network.',
  status = 'covered',
  notes = 'FlowVisor source handles statistics requests from an individual slice controller and maps replies back to that slice.',
  updated_at = NOW()
WHERE id = 'arc-l1-03';

UPDATE research_limitations SET
  limitation = 'Determine whether at least one physical resource is shared between the first virtual network and at least one other virtual network.',
  status = 'open',
  notes = 'FlowSpace can associate the same physical flowspace with multiple slices, but an explicit statistics-time shared-resource determination is not yet submit-ready.',
  updated_at = NOW()
WHERE id = 'arc-l1-04';

UPDATE research_limitations SET
  limitation = 'Isolatedly provide individual physical-resource consumption statistics to the first virtual network based on that shared-resource determination.',
  status = 'partial',
  notes = 'FlowVisor partitions flow statistics by slice and filters port statistics by slice, but the claimed dependency on the shared-resource determination needs tighter proof.',
  updated_at = NOW()
WHERE id = 'arc-l1-05';

UPDATE research_limitations SET
  limitation = 'Provide virtual flow-entry statistics for the first virtual network.',
  status = 'covered',
  notes = 'FlowVisor classifies physical flow statistics by translated cookie/slice and returns only the requesting slice''s flow statistics.',
  updated_at = NOW()
WHERE id = 'arc-l1-06';
UPDATE research_limitations SET
  limitation = 'Provide virtual-port statistics based on the physical resource for the first virtual network.',
  status = 'covered',
  notes = 'FlowVisor filters physical port-stat replies so a slice receives only ports present in its sliced topology.',
  updated_at = NOW()
WHERE id = 'arc-l1-07';

UPDATE evidence_items SET
  quality_score = 60,
  status = 'background-lead',
  notes = 'Background only. Current documentation is not relied on for the pre-cutoff chart because durable pre-cutoff provenance is not verified in the present clone.',
  updated_at = NOW()
WHERE id IN ('arc-ev-ovx-flowstats', 'arc-ev-ovx-portstats');

UPDATE evidence_items SET
  notes = 'Public USENIX source verified. Supports the network-hypervisor and shared-infrastructure context; code-level statistics behavior is mapped separately.',
  updated_at = NOW()
WHERE id = 'arc-ev-flowvisor-paper';

INSERT INTO evidence_items
  (id, research_project_id, limitation_id, title, source_type, source_url, published_date, relevance, quality_score, status, notes)
VALUES
  ('arc-ev-flowvisor-slices-paper','research-arc-link-claim1','arc-l1-02','FlowVisor shared physical infrastructure and separate slice controllers','paper','https://www.usenix.org/conference/osdi10/can-production-network-be-testbed',DATE '2010-10-06','USENIX OSDI 2010 describes FlowVisor slicing production network hardware into isolated slices controlled by different controllers.',90,'verified-lead','Pre-cutoff public conference record; supports multiple separately managed virtual networks sharing physical infrastructure.'),
  ('arc-ev-flowvisor-stats-request-code','research-arc-link-claim1','arc-l1-03','FlowVisor per-slice statistics request path','source-code','https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/message/statistics/FVFlowStatisticsRequest.java',DATE '2013-08-30','The pre-cutoff source routes a flow-statistics request from an individual FVSlicer through the physical classifier and returns that slice''s statistics.',94,'verified-lead','Verified locally at public repository commit b45b58f1afc674d8cd79126e0652aef2563838b2.'),
  ('arc-ev-flowvisor-flowspace-code','research-arc-link-claim1','arc-l1-04','FlowVisor FlowSpace multi-slice physical-resource mapping','source-code','https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/flows/FlowSpaceUtil.java',DATE '2013-08-30','FlowSpace rules enumerate slice actions for a physical switch/flowspace and can associate multiple slices with the same physical rule.',91,'verified-lead','Verified code proves shareability/mapping, but not yet the exact claimed statistics-time determination; limitation remains open.'),
  ('arc-ev-flowvisor-isolation-code','research-arc-link-claim1','arc-l1-05','FlowVisor per-slice physical flow-statistics isolation','source-code','https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/classifier/FVClassifier.java',DATE '2013-08-30','Physical flow statistics are classified by translated cookie into slice-keyed stores and responses are built from the requesting slice''s store.',94,'verified-lead','Strong isolation evidence; exact dependency on an explicit shared-resource determination remains a mapping issue.'),
  ('arc-ev-flowvisor-flowstats-code','research-arc-link-claim1','arc-l1-06','FlowVisor virtual flow-entry statistics by slice','source-code','https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/classifier/FVClassifier.java',DATE '2013-08-30','Flow statistics are classified to the owning slice, restored to the slice cookie, filtered by the request, and returned only to that slicer.',95,'verified-lead','Verified locally at the exact pre-cutoff public commit.'),
  ('arc-ev-flowvisor-portstats-code','research-arc-link-claim1','arc-l1-07','FlowVisor per-slice virtualized port statistics','source-code','https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/message/statistics/FVPortStatisticsReply.java',DATE '2013-08-30','Physical port-stat replies expose packet/byte counters and are filtered so ports outside the requesting slice are removed before the reply is sent.',95,'verified-lead','Matches the documented FlowVisor port-stat virtualization behavior and is pre-cutoff.')
ON CONFLICT (id) DO UPDATE SET
  limitation_id = EXCLUDED.limitation_id,
  title = EXCLUDED.title,
  source_type = EXCLUDED.source_type,
  source_url = EXCLUDED.source_url,
  published_date = EXCLUDED.published_date,
  relevance = EXCLUDED.relevance,
  quality_score = EXCLUDED.quality_score,
  status = EXCLUDED.status,
  notes = EXCLUDED.notes,
  updated_at = NOW();
