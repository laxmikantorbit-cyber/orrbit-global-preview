CREATE TABLE IF NOT EXISTS opportunity_sources (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  platform TEXT NOT NULL,
  source_url TEXT NOT NULL,
  adapter_type TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  scan_interval_minutes INTEGER NOT NULL DEFAULT 1440
    CHECK (scan_interval_minutes >= 60),
  last_started_at TIMESTAMPTZ,
  last_finished_at TIMESTAMPTZ,
  next_scan_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_status TEXT,
  last_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS opportunity_observations (
  id BIGSERIAL PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES opportunity_sources(id) ON DELETE CASCADE,
  external_key TEXT NOT NULL,
  canonical_opportunity_id TEXT,
  observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  snapshot_hash TEXT NOT NULL,
  is_new BOOLEAN NOT NULL DEFAULT FALSE,
  changed_fields JSONB NOT NULL DEFAULT '[]'::jsonb,
  payload JSONB NOT NULL,
  UNIQUE (source_id, external_key, snapshot_hash)
);

CREATE INDEX IF NOT EXISTS idx_opportunity_observations_recent
  ON opportunity_observations (observed_at DESC);

CREATE INDEX IF NOT EXISTS idx_opportunity_observations_source
  ON opportunity_observations (source_id, external_key, observed_at DESC);

ALTER TABLE opportunities
  ADD COLUMN IF NOT EXISTS source_id TEXT REFERENCES opportunity_sources(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS external_key TEXT,
  ADD COLUMN IF NOT EXISTS source_url TEXT,
  ADD COLUMN IF NOT EXISTS first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS source_hash TEXT,
  ADD COLUMN IF NOT EXISTS source_observed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS verification_status TEXT NOT NULL DEFAULT 'seeded';

CREATE UNIQUE INDEX IF NOT EXISTS uq_opportunities_source_external
  ON opportunities (source_id, external_key)
  WHERE source_id IS NOT NULL AND external_key IS NOT NULL;

INSERT INTO opportunity_sources
  (id,name,platform,source_url,adapter_type,enabled,scan_interval_minutes,next_scan_at,last_status,last_message)
VALUES
  ('patroll-public','PATROLL Public Contests','PATROLL','https://patroll.unifiedpatents.com/contests?category=all','browser-public-page',TRUE,360,NOW(),'pending','Waiting for first scanner adapter run'),
  ('metaculus-public','Metaculus Public Feed','Metaculus FutureEval','https://www.metaculus.com/questions/','public-feed',TRUE,360,NOW(),'pending','API documentation incomplete; use public-feed adapter only'),
  ('wazoku-public','Wazoku Public Challenges','InnoCentive/Wazoku','https://www.wazoku.com/challenges/','browser-public-page',TRUE,720,NOW(),'pending','Public challenge adapter pending'),
  ('drivendata-public','DrivenData Competitions','DrivenData','https://www.drivendata.org/competitions/','public-page',TRUE,720,NOW(),'pending','Public competition adapter pending')
ON CONFLICT (id) DO NOTHING;
