CREATE TABLE IF NOT EXISTS opportunities (
  id TEXT PRIMARY KEY,
  platform TEXT NOT NULL,
  title TEXT NOT NULL,
  prize_usd INTEGER NOT NULL CHECK (prize_usd >= 0),
  deadline DATE NOT NULL,
  eligibility TEXT NOT NULL DEFAULT '',
  automation TEXT NOT NULL DEFAULT '',
  score SMALLINT NOT NULL CHECK (score >= 0 AND score <= 100),
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_opportunities_score
  ON opportunities (score DESC);

CREATE INDEX IF NOT EXISTS idx_opportunities_deadline
  ON opportunities (deadline ASC);

CREATE INDEX IF NOT EXISTS idx_opportunities_status
  ON opportunities (status);
