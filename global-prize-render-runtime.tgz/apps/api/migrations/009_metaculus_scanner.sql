UPDATE opportunity_sources
SET
  source_url = 'https://www.metaculus.com/futureeval/participate/',
  adapter_type = 'authenticated-official-api',
  scan_interval_minutes = 360,
  next_scan_at = NOW(),
  last_status = 'pending',
  last_message = 'Official Metaculus API adapter ready; METACULUS_TOKEN is required for live scans',
  updated_at = NOW()
WHERE id = 'metaculus-public';
