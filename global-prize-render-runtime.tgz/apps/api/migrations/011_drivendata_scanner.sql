UPDATE opportunity_sources
SET
  source_url = 'https://www.drivendata.org/competitions/',
  adapter_type = 'public-html',
  scan_interval_minutes = 720,
  next_scan_at = NOW(),
  last_status = 'pending',
  last_message = 'DrivenData active prize competition adapter ready; waiting for first scan',
  updated_at = NOW()
WHERE id = 'drivendata-public';
