UPDATE opportunity_sources
SET
  source_url = 'https://www.innocentive.com/challenges/',
  adapter_type = 'public-html',
  scan_interval_minutes = 720,
  next_scan_at = NOW(),
  last_status = 'pending',
  last_message = 'Public Innocentive challenge adapter ready; waiting for first scan',
  updated_at = NOW()
WHERE id = 'wazoku-public';

UPDATE opportunities
SET status = 'blocked'
WHERE id = 'wazoku-aircraftfuel-2026';
