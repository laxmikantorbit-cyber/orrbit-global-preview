INSERT INTO opportunity_sources
  (id,name,platform,source_url,adapter_type,enabled,scan_interval_minutes,next_scan_at,last_status,last_message)
VALUES
  (
    'devpost-public',
    'Devpost High-Value Online Hackathons',
    'Devpost',
    'https://devpost.com/hackathons?challenge_type%5B%5D=online&managed_by_devpost_badge=1',
    'browser-public-page',
    TRUE,
    720,
    NOW(),
    'pending',
    'Waiting for first selective Devpost public scan'
  )
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  platform = EXCLUDED.platform,
  source_url = EXCLUDED.source_url,
  adapter_type = EXCLUDED.adapter_type,
  enabled = EXCLUDED.enabled,
  scan_interval_minutes = EXCLUDED.scan_interval_minutes,
  updated_at = NOW();
