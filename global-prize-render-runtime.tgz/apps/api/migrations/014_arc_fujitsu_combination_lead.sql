UPDATE research_projects
SET
  progress = 78,
  notes = 'Issued Claim 1 corrected to seven limitations. FlowVisor provides the primary dated statistics evidence; US9838253B2 provides a pre-cutoff shared-vs-dedicated physical-resource mapping/oversubscription combination lead. PATROLL known-reference review remains blocking.',
  updated_at = NOW()
WHERE id = 'research-arc-link-claim1';

UPDATE research_limitations
SET
  status = 'partial',
  notes = 'US9838253B2 expressly distinguishes dedicated resources from oversubscribed/shared resources using VNO service patterns and mapping state; combined with FlowVisor this is a credible l4 lead, but the combination rationale still needs claim-chart review.',
  updated_at = NOW()
WHERE id = 'arc-l1-04';

INSERT INTO evidence_items
  (id, research_project_id, limitation_id, title, source_type, source_url, published_date, relevance, quality_score, status, notes)
VALUES
  (
    'arc-ev-fujitsu-oonv-sharing',
    'research-arc-link-claim1',
    'arc-l1-04',
    'US9838253B2 Object-oriented network virtualization — shared vs dedicated physical resources',
    'patent',
    'https://patents.google.com/patent/US9838253B2/en',
    DATE '2015-10-15',
    'Pre-cutoff Fujitsu OONV disclosure states that multiple virtual network objects may share the same physical network resources, distinguishes dedicated resources from oversubscribed/shared resources, stores a sharing schedule/policy in a VNO service pattern, and uses virtual-to-physical mapping state.',
    93,
    'verified-lead',
    'Combination lead for limitation 4 with FlowVisor. It supports determining/knowing shared-vs-dedicated resource state, but does not itself supply FlowVisor''s per-slice statistics path; do not represent it as a single-reference anticipation.'
  )
ON CONFLICT (id) DO UPDATE SET
  limitation_id = EXCLUDED.limitation_id,
  title = EXCLUDED.title,
  source_type = EXCLUDED.source_type,
  source_url = EXCLUDED.source_url,
  published_date = EXCLUDED.published_date,
  relevance = EXCLUDED.relevance,
  quality_score = EXCLUDED.quality_score,
  status = EXCLUDED.status,
  notes = EXCLUDED.notes,
  updated_at = NOW();
