CREATE TABLE IF NOT EXISTS research_projects (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  research_type TEXT NOT NULL,
  status TEXT NOT NULL,
  progress SMALLINT NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  target_claim TEXT,
  cutoff_date DATE,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_research_projects_opportunity
  ON research_projects (opportunity_id);

CREATE TABLE IF NOT EXISTS research_limitations (
  id TEXT PRIMARY KEY,
  research_project_id TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  position SMALLINT NOT NULL,
  limitation TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (research_project_id, position)
);

CREATE INDEX IF NOT EXISTS idx_research_limitations_project
  ON research_limitations (research_project_id, position);

CREATE TABLE IF NOT EXISTS evidence_items (
  id TEXT PRIMARY KEY,
  research_project_id TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  limitation_id TEXT REFERENCES research_limitations(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_url TEXT,
  published_date DATE,
  relevance TEXT NOT NULL DEFAULT '',
  quality_score SMALLINT CHECK (quality_score IS NULL OR (quality_score >= 0 AND quality_score <= 100)),
  status TEXT NOT NULL DEFAULT 'lead',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_evidence_project
  ON evidence_items (research_project_id);

CREATE INDEX IF NOT EXISTS idx_evidence_limitation
  ON evidence_items (limitation_id);
