UPDATE evidence_items
SET
  limitation_id = 'arc-l1-01',
  source_url = 'https://www.usenix.org/legacy/event/osdi10/tech/full_papers/Sherwood.pdf',
  published_date = DATE '2010-10-06',
  relevance = 'OSDI 2010 paper directly describes FlowVisor as a slicing layer/network hypervisor enabling multiple isolated slices on shared physical network infrastructure.',
  quality_score = 90,
  status = 'verified-lead',
  notes = 'Dated public USENIX source. Supports hypervisor/slicing limitations; it does not by itself close the unresolved virtual-statistics calculation limitations.',
  updated_at = NOW()
WHERE id = 'arc-ev-flowvisor-paper';

UPDATE evidence_items
SET
  source_url = 'https://openvirtex.com/documentation/architecture/operation-and-subsystems/',
  published_date = NULL,
  relevance = 'Current OpenVirteX architecture documentation describes tenant-keyed flowStats populated by StatisticsManager polling physical datapaths.',
  quality_score = 74,
  status = 'strong-lead',
  notes = 'Functionality is documented, but durable pre-cutoff code provenance is not yet verified. Previously remembered historical commit hash did not resolve in the current clone.',
  updated_at = NOW()
WHERE id = 'arc-ev-ovx-flowstats';

UPDATE evidence_items
SET
  source_url = 'https://openvirtex.com/documentation/architecture/operation-and-subsystems/',
  published_date = NULL,
  relevance = 'Current OpenVirteX architecture documentation describes PhysicalSwitch portStats and OFPortStatisticsRequest polling.',
  quality_score = 74,
  status = 'strong-lead',
  notes = 'Functionality is documented, but durable pre-cutoff code provenance is not yet verified. Previously remembered historical commit hash did not resolve in the current clone.',
  updated_at = NOW()
WHERE id = 'arc-ev-ovx-portstats';
