CREATE TABLE IF NOT EXISTS backup_records (
  id BIGSERIAL PRIMARY KEY,
  backup_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  database_file TEXT,
  files_archive TEXT,
  database_bytes BIGINT,
  files_bytes BIGINT,
  started_at TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ,
  verified_at TIMESTAMPTZ,
  verification_status TEXT,
  message TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_backup_records_started
  ON backup_records (started_at DESC);

CREATE INDEX IF NOT EXISTS idx_backup_records_status
  ON backup_records (status, verification_status);
