CREATE TABLE IF NOT EXISTS submissions (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
  research_project_id TEXT REFERENCES research_projects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  platform TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  deadline DATE,
  submitted_at TIMESTAMPTZ,
  result_status TEXT,
  award_usd INTEGER CHECK (award_usd IS NULL OR award_usd >= 0),
  external_reference TEXT,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_submissions_status
  ON submissions (status);

CREATE INDEX IF NOT EXISTS idx_submissions_deadline
  ON submissions (deadline);

CREATE INDEX IF NOT EXISTS idx_submissions_opportunity
  ON submissions (opportunity_id);
