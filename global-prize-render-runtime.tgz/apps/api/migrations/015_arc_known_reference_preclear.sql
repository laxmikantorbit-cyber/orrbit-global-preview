UPDATE research_projects
SET
  progress = 82,
  notes = 'Issued Claim 1 corrected to seven limitations. FlowVisor plus US9838253B2 supplies a pre-cutoff two-reference combination lead with no open proof gaps. Public citation/PATROLL-index pre-clear found no candidate-reference match, but the authenticated PATROLL Known References attachment txedce-246705.pdf remains login-gated and must be reviewed before Pearl/submission.',
  updated_at = NOW()
WHERE id = 'research-arc-link-claim1';

UPDATE submissions
SET
  notes = 'Internal draft only. Research chart is at 89/100 readiness with no open proof gaps. Public known-reference pre-clear is complete; authenticated PATROLL attachment txedce-246705.pdf must still be reviewed. Do not mark ready or submitted until that login-gated check and final Pearl chart review are complete.',
  updated_at = NOW()
WHERE id = 'submission-arc-link-draft';
