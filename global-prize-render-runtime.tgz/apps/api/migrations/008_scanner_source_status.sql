ALTER TABLE opportunities
  ADD COLUMN IF NOT EXISTS source_status TEXT;

UPDATE opportunities
SET source_status = NULL
WHERE source_status IS NULL;
