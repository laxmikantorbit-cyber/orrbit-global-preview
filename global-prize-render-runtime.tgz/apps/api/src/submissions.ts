import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import type { Database } from "./database.js";

export type SubmissionItem = {
  id: string;
  opportunityId: string;
  researchProjectId: string | null;
  title: string;
  platform: string;
  status: string;
  deadline: string | null;
  submittedAt: string | null;
  resultStatus: string | null;
  awardUsd: number | null;
  externalReference: string | null;
  notes: string;
};

export type SubmissionRepository = {
  list(): Promise<SubmissionItem[]>;
  findById(id: string): Promise<SubmissionItem | undefined>;
};

type SubmissionRow = {
  id: string;
  opportunity_id: string;
  research_project_id: string | null;
  title: string;
  platform: string;
  status: string;
  deadline: Date | string | null;
  submitted_at: Date | string | null;
  result_status: string | null;
  award_usd: number | null;
  external_reference: string | null;
  notes: string;
};

function dateOnly(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date
    ? value.toISOString().slice(0, 10)
    : String(value).slice(0, 10);
}

function isoDateTime(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date
    ? value.toISOString()
    : new Date(value).toISOString();
}

function mapRow(row: SubmissionRow): SubmissionItem {
  return {
    id: row.id,
    opportunityId: row.opportunity_id,
    researchProjectId: row.research_project_id,
    title: row.title,
    platform: row.platform,
    status: row.status,
    deadline: dateOnly(row.deadline),
    submittedAt: isoDateTime(row.submitted_at),
    resultStatus: row.result_status,
    awardUsd: row.award_usd,
    externalReference: row.external_reference,
    notes: row.notes
  };
}

export class PostgresSubmissionRepository implements SubmissionRepository {
  constructor(private readonly db: Database) {}

  async list(): Promise<SubmissionItem[]> {
    const result = await this.db.query<SubmissionRow>(`
      SELECT
        id, opportunity_id, research_project_id, title, platform,
        status, deadline, submitted_at, result_status, award_usd,
        external_reference, notes
      FROM submissions
      ORDER BY
        CASE status
          WHEN 'submitted' THEN 1
          WHEN 'ready' THEN 2
          WHEN 'draft' THEN 3
          ELSE 4
        END,
        deadline ASC NULLS LAST,
        created_at ASC
    `);

    return result.rows.map(mapRow);
  }

  async findById(id: string): Promise<SubmissionItem | undefined> {
    const result = await this.db.query<SubmissionRow>(`
      SELECT
        id, opportunity_id, research_project_id, title, platform,
        status, deadline, submitted_at, result_status, award_usd,
        external_reference, notes
      FROM submissions
      WHERE id = $1
      LIMIT 1
    `, [id]);

    const row = result.rows[0];
    return row ? mapRow(row) : undefined;
  }
}

type PreviewSubmissionState = {
  submissions: SubmissionItem[];
};

async function loadPreviewSubmissions(): Promise<SubmissionItem[]> {
  const path = resolve(process.cwd(), "data/preview-state.json");
  const parsed = JSON.parse(await readFile(path, "utf8")) as PreviewSubmissionState;
  return parsed.submissions;
}

export class FileSubmissionRepository implements SubmissionRepository {
  async list(): Promise<SubmissionItem[]> {
    return await loadPreviewSubmissions();
  }

  async findById(id: string): Promise<SubmissionItem | undefined> {
    return (await loadPreviewSubmissions()).find((item) => item.id === id);
  }
}

export class EmptySubmissionRepository implements SubmissionRepository {
  async list(): Promise<SubmissionItem[]> {
    return [];
  }

  async findById(): Promise<SubmissionItem | undefined> {
    return undefined;
  }
}

export async function seedSubmissionTrackerIfEmpty(db: Database): Promise<number> {
  const existing = await db.query<{ count: string }>(
    "SELECT COUNT(*)::text AS count FROM submissions"
  );

  if (Number(existing.rows[0]?.count ?? "0") > 0) {
    return 0;
  }

  const opportunity = await db.query<{ deadline: Date | string; platform: string }>(
    "SELECT deadline, platform FROM opportunities WHERE id = $1",
    ["patroll-arc-11563655"]
  );

  if (!opportunity.rowCount) {
    return 0;
  }

  const research = await db.query(
    "SELECT 1 FROM research_projects WHERE id = $1",
    ["research-arc-link-claim1"]
  );

  const deadline = opportunity.rows[0]?.deadline;
  const platform = opportunity.rows[0]?.platform ?? "PATROLL";

  await db.query(`
    INSERT INTO submissions
      (id, opportunity_id, research_project_id, title, platform, status, deadline, notes)
    VALUES
      ($1,$2,$3,$4,$5,$6,$7,$8)
    ON CONFLICT (id) DO NOTHING
  `, [
    "submission-arc-link-draft",
    "patroll-arc-11563655",
    research.rowCount ? "research-arc-link-claim1" : null,
    "Arc Link SDN — Claim 1 submission draft",
    platform,
    "draft",
    deadline,
    "Internal draft tracker only. Do not mark submitted until an actual PATROLL submission is completed."
  ]);

  console.log("Seeded Arc Link internal submission draft");
  return 1;
}
