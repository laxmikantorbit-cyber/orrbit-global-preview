import type { EvidenceItem, ResearchLimitation, ResearchProject } from "./research.js";

export type ResearchExecutionIssue = {
  code: string;
  title: string;
  detail: string;
  relatedId: string | null;
  severity: "blocking" | "warning";
};

export type ResearchExecutionAction = {
  id: string;
  title: string;
  kind: string;
  priority: "critical" | "high" | "normal";
  blocking: boolean;
  relatedId: string | null;
};

export type ResearchExecutionAssessment = {
  projectId: string;
  readinessScore: number;
  readinessStatus: "blocked" | "researching" | "review-ready" | "submission-ready";
  limitationCoveragePercent: number;
  evidenceVerificationPercent: number;
  sourceTraceabilityPercent: number;
  totalLimitations: number;
  openProofGaps: number;
  totalEvidence: number;
  verifiedEvidence: number;
  blockingIssueCount: number;
  issues: ResearchExecutionIssue[];
  nextActions: ResearchExecutionAction[];
  formula: string;
};

function limitationCredit(status: string): number {
  const value = status.toLowerCase();
  if (/(verified|covered|complete|proven)/.test(value)) return 1;
  if (/(lead|partial)/.test(value)) return 0.5;
  return 0;
}

function evidenceCredit(status: string): number {
  const value = status.toLowerCase();
  if (/(verified)/.test(value)) return 1;
  if (/(strong)/.test(value)) return 0.6;
  if (/(lead)/.test(value)) return 0.3;
  return 0;
}

function pct(value: number): number {
  return Math.round(value * 100);
}

export function assessResearchExecution(
  project: ResearchProject,
  limitations: ResearchLimitation[],
  evidence: EvidenceItem[]
): ResearchExecutionAssessment {
  const issues: ResearchExecutionIssue[] = [];
  const nextActions: ResearchExecutionAction[] = [];

  const limitationCoverage = limitations.length === 0
    ? 0
    : limitations.reduce((sum, item) => sum + limitationCredit(item.status), 0) / limitations.length;

  const evidenceVerification = evidence.length === 0
    ? 0
    : evidence.reduce((sum, item) => sum + evidenceCredit(item.status), 0) / evidence.length;

  const traceableEvidence = evidence.filter((item) => Boolean(item.sourceUrl)).length;
  const sourceTraceability = evidence.length === 0 ? 0 : traceableEvidence / evidence.length;

  for (const limitation of limitations) {
    if (limitation.status.toLowerCase() === "open") {
      issues.push({
        code: "open-proof-gap",
        title: `Proof gap: limitation ${limitation.position}`,
        detail: limitation.limitation,
        relatedId: limitation.id,
        severity: "blocking"
      });
      nextActions.push({
        id: `prove-${limitation.id}`,
        title: `Find dated proof for limitation ${limitation.position}`,
        kind: "evidence-search",
        priority: "critical",
        blocking: true,
        relatedId: limitation.id
      });
    }
  }

  for (const item of evidence) {
    const important = /(verified|strong)/i.test(item.status);

    if (!item.sourceUrl && important) {
      issues.push({
        code: "source-provenance-missing",
        title: "Source URL/provenance missing",
        detail: `${item.title} needs a durable source reference before submission.`,
        relatedId: item.id,
        severity: "blocking"
      });
      nextActions.push({
        id: `source-${item.id}`,
        title: `Attach durable source URL/provenance: ${item.title}`,
        kind: "source-verification",
        priority: "critical",
        blocking: true,
        relatedId: item.id
      });
    }

    if (!item.publishedDate && important) {
      issues.push({
        code: "publication-date-unverified",
        title: "Publication date not verified",
        detail: `${item.title} cannot be relied on for the cutoff until its public date is verified.`,
        relatedId: item.id,
        severity: "blocking"
      });
      nextActions.push({
        id: `date-${item.id}`,
        title: `Verify pre-cutoff publication date: ${item.title}`,
        kind: "date-verification",
        priority: "critical",
        blocking: true,
        relatedId: item.id
      });
    }

    if (project.cutoffDate && item.publishedDate && item.publishedDate >= project.cutoffDate) {
      issues.push({
        code: "post-cutoff-evidence",
        title: "Evidence is not pre-cutoff",
        detail: `${item.title} is dated ${item.publishedDate}, not before ${project.cutoffDate}.`,
        relatedId: item.id,
        severity: "blocking"
      });
    }

    if (!/(verified)/i.test(item.status)) {
      nextActions.push({
        id: `verify-${item.id}`,
        title: `Upgrade evidence verification: ${item.title}`,
        kind: "evidence-verification",
        priority: important ? "high" : "normal",
        blocking: false,
        relatedId: item.id
      });
    }
  }

  if (/known[-\s]?references?/i.test(project.notes)) {
    issues.push({
      code: "known-reference-check-pending",
      title: "Known-reference duplication check pending",
      detail: "Confirm the candidate references are not already cited/known in the patent, prosecution history, or contest materials.",
      relatedId: project.id,
      severity: "blocking"
    });
    nextActions.push({
      id: `known-reference-${project.id}`,
      title: "Complete patent/prosecution/PATROLL known-reference check",
      kind: "known-reference-check",
      priority: "critical",
      blocking: true,
      relatedId: project.id
    });
  }

  const rawScore =
    limitationCoverage * 50 +
    evidenceVerification * 30 +
    sourceTraceability * 20;

  const blockingIssueCount = issues.filter((item) => item.severity === "blocking").length;
  const readinessScore = Math.max(0, Math.min(100, Math.round(rawScore)));

  const readinessStatus: ResearchExecutionAssessment["readinessStatus"] =
    blockingIssueCount > 0
      ? "blocked"
      : readinessScore >= 90
        ? "submission-ready"
        : readinessScore >= 70
          ? "review-ready"
          : "researching";

  return {
    projectId: project.id,
    readinessScore,
    readinessStatus,
    limitationCoveragePercent: pct(limitationCoverage),
    evidenceVerificationPercent: pct(evidenceVerification),
    sourceTraceabilityPercent: pct(sourceTraceability),
    totalLimitations: limitations.length,
    openProofGaps: limitations.filter((item) => item.status.toLowerCase() === "open").length,
    totalEvidence: evidence.length,
    verifiedEvidence: evidence.filter((item) => /verified/i.test(item.status)).length,
    blockingIssueCount,
    issues,
    nextActions,
    formula: "50% limitation coverage + 30% evidence verification + 20% source traceability; any hard blocker prevents submission-ready status."
  };
}
