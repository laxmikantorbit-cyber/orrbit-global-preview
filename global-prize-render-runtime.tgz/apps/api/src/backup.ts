import type { Database } from "./database.js";

export type BackupRecord = {
  id: number;
  backupKey: string;
  status: string;
  databaseFile: string | null;
  filesArchive: string | null;
  databaseBytes: number | null;
  filesBytes: number | null;
  startedAt: string;
  finishedAt: string | null;
  verifiedAt: string | null;
  verificationStatus: string | null;
  message: string;
};

export type BackupRepository = {
  list(limit?: number): Promise<BackupRecord[]>;
  latest(): Promise<BackupRecord | undefined>;
};

type BackupRow = {
  id: number | string;
  backup_key: string;
  status: string;
  database_file: string | null;
  files_archive: string | null;
  database_bytes: number | string | null;
  files_bytes: number | string | null;
  started_at: Date | string;
  finished_at: Date | string | null;
  verified_at: Date | string | null;
  verification_status: string | null;
  message: string;
};

function iso(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function integer(value: number | string | null): number | null {
  if (value === null) return null;
  return Number(value);
}

function mapRow(row: BackupRow): BackupRecord {
  return {
    id: Number(row.id),
    backupKey: row.backup_key,
    status: row.status,
    databaseFile: row.database_file,
    filesArchive: row.files_archive,
    databaseBytes: integer(row.database_bytes),
    filesBytes: integer(row.files_bytes),
    startedAt: iso(row.started_at) ?? new Date(0).toISOString(),
    finishedAt: iso(row.finished_at),
    verifiedAt: iso(row.verified_at),
    verificationStatus: row.verification_status,
    message: row.message
  };
}

export class PostgresBackupRepository implements BackupRepository {
  constructor(private readonly db: Database) {}

  async list(limit = 20): Promise<BackupRecord[]> {
    const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 100);
    const result = await this.db.query<BackupRow>(
      "SELECT id,backup_key,status,database_file,files_archive,database_bytes,files_bytes,started_at,finished_at,verified_at,verification_status,message FROM backup_records ORDER BY started_at DESC,id DESC LIMIT $1",
      [safeLimit]
    );
    return result.rows.map(mapRow);
  }

  async latest(): Promise<BackupRecord | undefined> {
    const result = await this.db.query<BackupRow>(
      "SELECT id,backup_key,status,database_file,files_archive,database_bytes,files_bytes,started_at,finished_at,verified_at,verification_status,message FROM backup_records ORDER BY started_at DESC,id DESC LIMIT 1"
    );
    const row = result.rows[0];
    return row ? mapRow(row) : undefined;
  }
}

export class EmptyBackupRepository implements BackupRepository {
  async list(): Promise<BackupRecord[]> {
    return [];
  }

  async latest(): Promise<BackupRecord | undefined> {
    return undefined;
  }
}
