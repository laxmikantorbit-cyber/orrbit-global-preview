import type { Opportunity } from "./opportunities.js";
import type { ResearchExecutionAssessment } from "./research-execution.js";
import type { SubmissionItem } from "./submissions.js";

export type SubmissionReadinessIssue = {
  code: string;
  title: string;
  detail: string;
  severity: "blocking" | "review";
};

export type SubmissionReadinessAssessment = {
  submissionId: string;
  state: "blocked" | "review-required" | "ready" | "already-submitted" | "resolved";
  score: number;
  deadlineState: "overdue" | "urgent" | "near" | "runway" | "unknown";
  daysRemaining: number | null;
  researchReadiness: string | null;
  eligibilityReviewRequired: boolean;
  automationReviewRequired: boolean;
  issues: SubmissionReadinessIssue[];
  checks: Array<{
    key: string;
    label: string;
    passed: boolean;
    blocking: boolean;
    detail: string;
  }>;
  note: string;
};

function daysUntil(deadline: string | null, referenceDate: Date): number | null {
  if (!deadline) return null;
  const end = new Date(`${deadline}T23:59:59Z`);
  return Math.ceil((end.getTime() - referenceDate.getTime()) / 86_400_000);
}

function deadlineState(daysRemaining: number | null): SubmissionReadinessAssessment["deadlineState"] {
  if (daysRemaining === null) return "unknown";
  if (daysRemaining < 0) return "overdue";
  if (daysRemaining <= 7) return "urgent";
  if (daysRemaining <= 21) return "near";
  return "runway";
}

function needsEligibilityReview(text: string): boolean {
  return /(review|check|verify|restricted|eligible|eligibility|citizen|resident|country|geograph)/i.test(text);
}

function needsAutomationReview(text: string): boolean {
  return /(review|check|rules|terms|human|manual|not allowed|prohibit|restrict)/i.test(text);
}

export function assessSubmissionReadiness(
  submission: SubmissionItem,
  opportunity: Opportunity,
  research: ResearchExecutionAssessment | null,
  referenceDate = new Date()
): SubmissionReadinessAssessment {
  const issues: SubmissionReadinessIssue[] = [];
  const checks: SubmissionReadinessAssessment["checks"] = [];
  const daysRemaining = daysUntil(submission.deadline ?? opportunity.deadline, referenceDate);
  const deadline = deadlineState(daysRemaining);

  const alreadySubmitted = submission.status === "submitted" || submission.submittedAt !== null;
  const resolved = submission.resultStatus !== null || submission.status === "result";

  if (resolved) {
    return {
      submissionId: submission.id,
      state: "resolved",
      score: 100,
      deadlineState: deadline,
      daysRemaining,
      researchReadiness: research?.readinessStatus ?? null,
      eligibilityReviewRequired: false,
      automationReviewRequired: false,
      issues: [],
      checks: [],
      note: "This tracker item already has a recorded result. Readiness gating no longer applies."
    };
  }

  if (alreadySubmitted) {
    return {
      submissionId: submission.id,
      state: "already-submitted",
      score: 100,
      deadlineState: deadline,
      daysRemaining,
      researchReadiness: research?.readinessStatus ?? null,
      eligibilityReviewRequired: false,
      automationReviewRequired: false,
      issues: [],
      checks: [],
      note: "An external submission is already recorded. The system will not re-label it as merely ready."
    };
  }

  const deadlinePassed = deadline === "overdue";
  checks.push({
    key: "deadline",
    label: "Submission window open",
    passed: !deadlinePassed,
    blocking: true,
    detail: daysRemaining === null ? "No deadline is recorded." : `${daysRemaining} day(s) remaining.`
  });
  if (deadlinePassed) {
    issues.push({
      code: "deadline-overdue",
      title: "Deadline has passed",
      detail: "This submission must not be marked ready unless the platform confirms a valid extension or reopened window.",
      severity: "blocking"
    });
  }

  const hasResearch = submission.researchProjectId !== null && research !== null;
  checks.push({
    key: "research-link",
    label: "Research project linked",
    passed: hasResearch,
    blocking: true,
    detail: hasResearch ? "A research project is linked." : "No research readiness evidence is linked."
  });
  if (!hasResearch) {
    issues.push({
      code: "research-not-linked",
      title: "Research project is not linked",
      detail: "Submission readiness requires an auditable research project and evidence trail.",
      severity: "blocking"
    });
  }

  const researchReady = research?.readinessStatus === "submission-ready";
  checks.push({
    key: "research-ready",
    label: "Research execution gate passed",
    passed: researchReady,
    blocking: true,
    detail: research
      ? `Research readiness: ${research.readinessStatus} at ${research.readinessScore}% with ${research.blockingIssueCount} blocker(s).`
      : "Research execution assessment is unavailable."
  });
  if (research && !researchReady) {
    issues.push({
      code: "research-not-ready",
      title: "Research execution gate is not passed",
      detail: `${research.blockingIssueCount} blocking issue(s) remain; readiness score is ${research.readinessScore}%.`,
      severity: "blocking"
    });
  }

  const eligibilityReviewRequired = needsEligibilityReview(opportunity.eligibility);
  checks.push({
    key: "eligibility",
    label: "Eligibility reviewed",
    passed: !eligibilityReviewRequired,
    blocking: false,
    detail: opportunity.eligibility
  });
  if (eligibilityReviewRequired) {
    issues.push({
      code: "eligibility-review",
      title: "Eligibility needs explicit review",
      detail: opportunity.eligibility,
      severity: "review"
    });
  }

  const automationReviewRequired = needsAutomationReview(opportunity.automation);
  checks.push({
    key: "automation-rules",
    label: "Automation/AI rules reviewed",
    passed: !automationReviewRequired,
    blocking: false,
    detail: opportunity.automation
  });
  if (automationReviewRequired) {
    issues.push({
      code: "automation-review",
      title: "Platform automation/AI rules need review",
      detail: opportunity.automation,
      severity: "review"
    });
  }

  const blocking = issues.filter((issue) => issue.severity === "blocking").length;
  const reviews = issues.filter((issue) => issue.severity === "review").length;
  const weightedPassed = checks.reduce((sum, check) => sum + (check.passed ? (check.blocking ? 30 : 20) : 0), 0);
  const maxWeight = checks.reduce((sum, check) => sum + (check.blocking ? 30 : 20), 0);
  const score = maxWeight ? Math.round((weightedPassed / maxWeight) * 100) : 0;

  const state: SubmissionReadinessAssessment["state"] =
    blocking > 0 ? "blocked" : reviews > 0 ? "review-required" : "ready";

  return {
    submissionId: submission.id,
    state,
    score,
    deadlineState: deadline,
    daysRemaining,
    researchReadiness: research?.readinessStatus ?? null,
    eligibilityReviewRequired,
    automationReviewRequired,
    issues,
    checks,
    note: "Readiness is a process gate, not a prediction of winning or payment."
  };
}
