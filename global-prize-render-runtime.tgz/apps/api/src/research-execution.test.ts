import assert from "node:assert/strict";
import test from "node:test";
import { assessResearchExecution } from "./research-execution.js";

test("research execution assessment exposes Arc-style proof blockers without predicting a win", () => {
  const result = assessResearchExecution(
    {
      id: "research-arc",
      opportunityId: "arc",
      title: "Arc",
      researchType: "patent-prior-art",
      status: "researching",
      progress: 25,
      targetClaim: "Claim 1",
      cutoffDate: "2020-04-28",
      notes: "Authenticated PATROLL Known References review still needs verification"
    },
    [
      { id:"l1",researchProjectId:"research-arc",position:1,limitation:"Hypervisor",status:"lead",notes:"" },
      { id:"l2",researchProjectId:"research-arc",position:2,limitation:"Shared-resource determination",status:"open",notes:"" }
    ],
    [
      { id:"e1",researchProjectId:"research-arc",limitationId:"l1",title:"FlowVisor",sourceType:"paper",sourceUrl:null,publishedDate:null,relevance:"",qualityScore:80,status:"strong-lead",notes:"" },
      { id:"e2",researchProjectId:"research-arc",limitationId:"l1",title:"OpenVirteX",sourceType:"source-code",sourceUrl:"https://example.test/repo",publishedDate:"2013-10-24",relevance:"",qualityScore:82,status:"verified-lead",notes:"" }
    ]
  );

  assert.equal(result.readinessStatus, "blocked");
  assert.equal(result.openProofGaps, 1);
  assert.ok(result.blockingIssueCount >= 3);
  assert.ok(result.nextActions.some((item) => item.kind === "known-reference-check"));
  assert.match(result.formula, /50% limitation coverage/);
});
