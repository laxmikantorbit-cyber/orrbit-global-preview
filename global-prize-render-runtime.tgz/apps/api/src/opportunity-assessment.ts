import type { Opportunity } from "./opportunities.js";

export type OpportunityAssessment = {
  opportunityId: string;
  priorityScore: number;
  priorityBand: "top" | "high" | "selective" | "watch";
  rewardTier: "major" | "high" | "medium" | "base";
  daysRemaining: number;
  deadlineState: "overdue" | "urgent" | "near" | "runway";
  eligibilityState: "account-action" | "review-required" | "stated-ready";
  automationState: "autonomous" | "ai-assisted" | "rules-review";
  executionLane: "patent-prior-art" | "innovation-challenge" | "forecasting" | "general";
  note: string;
};

export function assessOpportunity(
  opportunity: Opportunity,
  referenceDate = new Date()
): OpportunityAssessment {
  const deadline = new Date(`${opportunity.deadline}T23:59:59Z`);
  const reference = new Date(referenceDate);
  const daysRemaining = Math.ceil((deadline.getTime() - reference.getTime()) / 86_400_000);

  const priorityBand =
    opportunity.score >= 85 ? "top" :
    opportunity.score >= 70 ? "high" :
    opportunity.score >= 55 ? "selective" :
    "watch";

  const rewardTier =
    opportunity.prizeUsd >= 50_000 ? "major" :
    opportunity.prizeUsd >= 20_000 ? "high" :
    opportunity.prizeUsd >= 5_000 ? "medium" :
    "base";

  const deadlineState =
    daysRemaining < 0 ? "overdue" :
    daysRemaining <= 7 ? "urgent" :
    daysRemaining <= 21 ? "near" :
    "runway";

  const eligibilityText = opportunity.eligibility.toLowerCase();
  const eligibilityState =
    eligibilityText.includes("account") || eligibilityText.includes("token")
      ? "account-action"
      : eligibilityText.includes("review") || eligibilityText.includes("check")
        ? "review-required"
        : "stated-ready";

  const automationText = opportunity.automation.toLowerCase();
  const automationState =
    automationText.includes("autonomous")
      ? "autonomous"
      : automationText.includes("assisted") || automationText.includes("support")
        ? "ai-assisted"
        : "rules-review";

  const platform = opportunity.platform.toLowerCase();
  const executionLane =
    platform.includes("patroll") || platform.includes("patent")
      ? "patent-prior-art"
      : platform.includes("wazoku") || platform.includes("innocentive")
        ? "innovation-challenge"
        : platform.includes("metaculus")
          ? "forecasting"
          : "general";

  return {
    opportunityId: opportunity.id,
    priorityScore: opportunity.score,
    priorityBand,
    rewardTier,
    daysRemaining,
    deadlineState,
    eligibilityState,
    automationState,
    executionLane,
    note: "Priority score is an internal execution score, not a win probability or guaranteed earning estimate."
  };
}
