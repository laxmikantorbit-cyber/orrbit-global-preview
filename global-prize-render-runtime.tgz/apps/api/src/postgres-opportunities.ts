import type { Database } from "./database.js";
import type { Opportunity, OpportunityRepository } from "./opportunities.js";

type OpportunityRow = {
  id: string;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: string | Date;
  eligibility: string;
  automation: string;
  score: number;
  status: string;
};

function mapRow(row: OpportunityRow): Opportunity {
  const deadline =
    row.deadline instanceof Date
      ? row.deadline.toISOString().slice(0, 10)
      : String(row.deadline).slice(0, 10);

  return {
    id: row.id,
    platform: row.platform,
    title: row.title,
    prizeUsd: row.prize_usd,
    deadline,
    eligibility: row.eligibility,
    automation: row.automation,
    score: row.score,
    status: row.status
  };
}

export class PostgresOpportunityRepository implements OpportunityRepository {
  constructor(private readonly db: Database) {}

  async list(): Promise<Opportunity[]> {
    const result = await this.db.query<OpportunityRow>(`
      SELECT
        id, platform, title, prize_usd, deadline,
        eligibility, automation, score, status
      FROM opportunities
      ORDER BY score DESC, deadline ASC, id ASC
    `);

    return result.rows.map(mapRow);
  }

  async findById(id: string): Promise<Opportunity | undefined> {
    const result = await this.db.query<OpportunityRow>(`
      SELECT
        id, platform, title, prize_usd, deadline,
        eligibility, automation, score, status
      FROM opportunities
      WHERE id = $1
      LIMIT 1
    `, [id]);

    const row = result.rows[0];
    return row ? mapRow(row) : undefined;
  }
}
