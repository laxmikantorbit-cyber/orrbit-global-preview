import type { Opportunity } from "./opportunities.js";
import type { SubmissionItem } from "./submissions.js";

export type ResultsSummary = {
  trackedSubmissions: number;
  submitted: number;
  resolved: number;
  wins: number;
  losses: number;
  pendingResults: number;
  awardedUsd: number;
  averageAwardUsd: number;
  winRatePercent: number | null;
  note: string;
};

export type PlatformReport = {
  platform: string;
  opportunities: number;
  visiblePrizeUsd: number;
  submissions: number;
  submitted: number;
  resolved: number;
  wins: number;
  losses: number;
  awardedUsd: number;
};

export type PortfolioReport = {
  generatedAt: string;
  results: ResultsSummary;
  platforms: PlatformReport[];
  totalVisiblePrizeUsd: number;
  totalOpportunities: number;
};

export function buildResultsSummary(submissions: SubmissionItem[]): ResultsSummary {
  const submittedItems = submissions.filter(
    (item) => item.submittedAt !== null || ["submitted", "result"].includes(item.status)
  );
  const resolvedItems = submissions.filter(
    (item) => item.resultStatus !== null || item.status === "result"
  );
  const wins = resolvedItems.filter((item) => item.resultStatus === "won");
  const losses = resolvedItems.filter((item) => item.resultStatus === "lost");
  const awardedUsd = wins.reduce((sum, item) => sum + (item.awardUsd ?? 0), 0);

  return {
    trackedSubmissions: submissions.length,
    submitted: submittedItems.length,
    resolved: resolvedItems.length,
    wins: wins.length,
    losses: losses.length,
    pendingResults: submittedItems.filter((item) => item.resultStatus === null).length,
    awardedUsd,
    averageAwardUsd: wins.length ? Math.round(awardedUsd / wins.length) : 0,
    winRatePercent: resolvedItems.length
      ? Math.round((wins.length / resolvedItems.length) * 100)
      : null,
    note: "Awards reflect only recorded won results; drafts, visible prize pools and estimates are not counted as earnings."
  };
}

export function buildPortfolioReport(
  opportunities: Opportunity[],
  submissions: SubmissionItem[],
  generatedAt = new Date()
): PortfolioReport {
  const platformNames = new Set<string>([
    ...opportunities.map((item) => item.platform),
    ...submissions.map((item) => item.platform)
  ]);

  const platforms = [...platformNames].sort().map((platform) => {
    const platformOpportunities = opportunities.filter((item) => item.platform === platform);
    const platformSubmissions = submissions.filter((item) => item.platform === platform);
    const submitted = platformSubmissions.filter(
      (item) => item.submittedAt !== null || ["submitted", "result"].includes(item.status)
    );
    const resolved = platformSubmissions.filter(
      (item) => item.resultStatus !== null || item.status === "result"
    );
    const wins = resolved.filter((item) => item.resultStatus === "won");
    const losses = resolved.filter((item) => item.resultStatus === "lost");

    return {
      platform,
      opportunities: platformOpportunities.length,
      visiblePrizeUsd: platformOpportunities.reduce((sum, item) => sum + item.prizeUsd, 0),
      submissions: platformSubmissions.length,
      submitted: submitted.length,
      resolved: resolved.length,
      wins: wins.length,
      losses: losses.length,
      awardedUsd: wins.reduce((sum, item) => sum + (item.awardUsd ?? 0), 0)
    };
  });

  return {
    generatedAt: generatedAt.toISOString(),
    results: buildResultsSummary(submissions),
    platforms,
    totalVisiblePrizeUsd: opportunities.reduce((sum, item) => sum + item.prizeUsd, 0),
    totalOpportunities: opportunities.length
  };
}
