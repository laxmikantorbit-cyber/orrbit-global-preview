import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, resolve } from "node:path";
import { createRequestHandler } from "./app.js";
import {
  createDatabase,
  migrateDatabase,
  seedOpportunitiesIfEmpty,
  type Database
} from "./database.js";
import {
  EmptyAutomationRepository,
  PostgresAutomationRepository,
  seedAutomationJobsIfEmpty,
  type AutomationRepository
} from "./automation.js";
import {
  EmptyBackupRepository,
  PostgresBackupRepository,
  type BackupRepository
} from "./backup.js";
import {
  DisabledAuthService,
  InMemoryOwnerAuthService,
  PostgresOwnerAuthService,
  type AuthService
} from "./auth.js";
import {
  FileOpportunityRepository,
  type OpportunityRepository
} from "./opportunities.js";
import { PostgresOpportunityRepository } from "./postgres-opportunities.js";
import {
  EmptyResearchRepository,
  FileResearchRepository,
  PostgresResearchRepository,
  seedResearchWorkspaceIfEmpty,
  type ResearchRepository
} from "./research.js";
import {
  EmptySubmissionRepository,
  FileSubmissionRepository,
  PostgresSubmissionRepository,
  seedSubmissionTrackerIfEmpty,
  type SubmissionRepository
} from "./submissions.js";
import {
  EmptyScannerRepository,
  PostgresScannerRepository,
  type ScannerRepository
} from "./scanner.js";

const port = Number(process.env.PORT ?? process.env.API_PORT ?? 3001);
const host = process.env.API_HOST ?? "0.0.0.0";
const version = process.env.APP_VERSION ?? "0.1.0";

let database: Database | undefined;
let server: Server | undefined;
let shuttingDown = false;

type Repositories = {
  opportunities: OpportunityRepository;
  research: ResearchRepository;
  submissions: SubmissionRepository;
  automation: AutomationRepository;
  backups: BackupRepository;
  scanner: ScannerRepository;
  auth: AuthService;
};

function createAuthService(db: Database): AuthService {
  const ownerLogin = process.env.OWNER_LOGIN?.trim();
  const passwordHash = process.env.OWNER_PASSWORD_HASH?.trim();

  if (!ownerLogin || !passwordHash) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "OWNER_LOGIN and OWNER_PASSWORD_HASH are required in production"
      );
    }

    console.warn("Owner authentication is disabled outside production");
    return new DisabledAuthService();
  }

  const sessionHours = Math.max(
    1,
    Number(process.env.AUTH_SESSION_HOURS ?? "12")
  );

  return new PostgresOwnerAuthService(db, {
    ownerLogin,
    passwordHash,
    secureCookie: process.env.AUTH_COOKIE_SECURE === "true",
    sessionHours
  });
}

async function createRepositories(): Promise<Repositories> {
  const connectionString = process.env.DATABASE_URL;

  if (!connectionString) {
    const statelessPreview = process.env.STATELESS_PREVIEW === "true";

    if (process.env.NODE_ENV === "production" && !statelessPreview) {
      throw new Error("DATABASE_URL is required in production unless STATELESS_PREVIEW=true");
    }

    if (statelessPreview) {
      const ownerLogin = process.env.OWNER_LOGIN?.trim();
      const passwordHash = process.env.OWNER_PASSWORD_HASH?.trim();
      if (!ownerLogin || !passwordHash) {
        throw new Error("OWNER_LOGIN and OWNER_PASSWORD_HASH are required for stateless preview");
      }

      const sessionHours = Math.max(1, Number(process.env.AUTH_SESSION_HOURS ?? "12"));
      console.warn("Running secure stateless preview: writes, scanner history and backups are not persistent.");
      return {
        opportunities: new FileOpportunityRepository(),
        research: new FileResearchRepository(),
        submissions: new FileSubmissionRepository(),
        automation: new EmptyAutomationRepository(),
        backups: new EmptyBackupRepository(),
        scanner: new EmptyScannerRepository(),
        auth: new InMemoryOwnerAuthService({
          ownerLogin,
          passwordHash,
          secureCookie: process.env.AUTH_COOKIE_SECURE === "true",
          sessionHours
        })
      };
    }

    console.warn("DATABASE_URL is not set; using development file-backed opportunity repository");
    return {
      opportunities: new FileOpportunityRepository(),
      research: new EmptyResearchRepository(),
      submissions: new EmptySubmissionRepository(),
      automation: new EmptyAutomationRepository(),
      backups: new EmptyBackupRepository(),
      scanner: new EmptyScannerRepository(),
      auth: new DisabledAuthService()
    };
  }

  database = createDatabase(connectionString);
  // Seed canonical baseline rows before state-patch migrations that reference them.
  // Existing databases remain idempotent because applied migrations and non-empty seeds are skipped.
  await migrateDatabase(database, "013_arc_claim1_correction.sql");
  await seedOpportunitiesIfEmpty(database);
  await seedResearchWorkspaceIfEmpty(database);
  await seedSubmissionTrackerIfEmpty(database);
  await seedAutomationJobsIfEmpty(database);
  await migrateDatabase(database);

  console.log("PostgreSQL repositories ready");
  return {
    opportunities: new PostgresOpportunityRepository(database),
    research: new PostgresResearchRepository(database),
    submissions: new PostgresSubmissionRepository(database),
    automation: new PostgresAutomationRepository(database),
    backups: new PostgresBackupRepository(database),
    scanner: new PostgresScannerRepository(database),
    auth: createAuthService(database)
  };
}

const webDist = resolve(process.env.WEB_DIST_PATH ?? resolve(process.cwd(), "apps/web/dist"));

const mimeTypes: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon"
};

async function serveWeb(request: IncomingMessage, response: ServerResponse): Promise<void> {
  const pathname = decodeURIComponent(new URL(request.url ?? "/", "http://localhost").pathname);
  const requested = pathname === "/" ? "/index.html" : pathname;
  let target = resolve(webDist, "." + requested);

  if (!target.startsWith(webDist)) {
    response.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
    response.end("Bad request");
    return;
  }

  try {
    const info = await stat(target);
    if (info.isDirectory()) target = resolve(target, "index.html");
  } catch {
    target = resolve(webDist, "index.html");
  }

  try {
    const content = await readFile(target);
    response.writeHead(200, {
      "content-type": mimeTypes[extname(target).toLowerCase()] ?? "application/octet-stream",
      "cache-control": target.endsWith("index.html") ? "no-cache" : "public, max-age=31536000, immutable"
    });
    response.end(content);
  } catch {
    response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    response.end("Not found");
  }
}

async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;

  console.log(`Received ${signal}; shutting down API.`);

  if (server) {
    await new Promise<void>((resolve, reject) => {
      server?.close((error) => error ? reject(error) : resolve());
    });
  }

  if (database) {
    await database.end();
  }
}

async function main(): Promise<void> {
  const repositories = await createRepositories();

  const apiHandler = createRequestHandler(
    version,
    repositories.opportunities,
    repositories.research,
    repositories.submissions,
    repositories.automation,
    repositories.backups,
    repositories.scanner,
    repositories.auth
  );

  server = createServer((request, response) => {
    const pathname = new URL(request.url ?? "/", "http://localhost").pathname;
    const shouldUseApi =
      process.env.NODE_ENV !== "production" ||
      pathname === "/health" ||
      pathname.startsWith("/api");

    if (shouldUseApi) {
      apiHandler(request, response);
      return;
    }

    void serveWeb(request, response).catch((error) => {
      console.error("Failed to serve web asset", error);
      if (!response.headersSent) {
        response.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      }
      response.end("Internal server error");
    });
  });

  server.listen(port, host, () => {
    console.log(`Global Prize API listening on http://${host}:${port}`);
  });

  process.on("SIGTERM", () => {
    void shutdown("SIGTERM");
  });
  process.on("SIGINT", () => {
    void shutdown("SIGINT");
  });
}

main().catch(async (error) => {
  console.error("Failed to start Global Prize API", error);
  if (database) await database.end().catch(() => undefined);
  process.exitCode = 1;
});
