import type { Database } from "./database.js";

export type AutomationJob = {
  id: string;
  name: string;
  jobType: string;
  enabled: boolean;
  scheduleMinutes: number;
  lastStartedAt: string | null;
  lastFinishedAt: string | null;
  nextRunAt: string;
  lastStatus: string | null;
  lastMessage: string | null;
};

export type AutomationRun = {
  id: number;
  jobId: string;
  startedAt: string;
  finishedAt: string;
  status: string;
  message: string;
  summary: Record<string, unknown>;
};

export type AutomationRepository = {
  listJobs(): Promise<AutomationJob[]>;
  listRuns(limit?: number): Promise<AutomationRun[]>;
};

type JobRow = {
  id: string;
  name: string;
  job_type: string;
  enabled: boolean;
  schedule_minutes: number;
  last_started_at: Date | string | null;
  last_finished_at: Date | string | null;
  next_run_at: Date | string;
  last_status: string | null;
  last_message: string | null;
};

type RunRow = {
  id: number | string;
  job_id: string;
  started_at: Date | string;
  finished_at: Date | string;
  status: string;
  message: string;
  summary: Record<string, unknown>;
};

function iso(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function mapJob(row: JobRow): AutomationJob {
  return {
    id: row.id,
    name: row.name,
    jobType: row.job_type,
    enabled: row.enabled,
    scheduleMinutes: row.schedule_minutes,
    lastStartedAt: iso(row.last_started_at),
    lastFinishedAt: iso(row.last_finished_at),
    nextRunAt: iso(row.next_run_at) ?? new Date(0).toISOString(),
    lastStatus: row.last_status,
    lastMessage: row.last_message
  };
}

function mapRun(row: RunRow): AutomationRun {
  return {
    id: Number(row.id),
    jobId: row.job_id,
    startedAt: iso(row.started_at) ?? new Date(0).toISOString(),
    finishedAt: iso(row.finished_at) ?? new Date(0).toISOString(),
    status: row.status,
    message: row.message,
    summary: row.summary ?? {}
  };
}

export class PostgresAutomationRepository implements AutomationRepository {
  constructor(private readonly db: Database) {}

  async listJobs(): Promise<AutomationJob[]> {
    const result = await this.db.query<JobRow>(
      "SELECT id,name,job_type,enabled,schedule_minutes,last_started_at,last_finished_at,next_run_at,last_status,last_message FROM automation_jobs ORDER BY enabled DESC, name ASC"
    );
    return result.rows.map(mapJob);
  }

  async listRuns(limit = 20): Promise<AutomationRun[]> {
    const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 100);
    const result = await this.db.query<RunRow>(
      "SELECT id,job_id,started_at,finished_at,status,message,summary FROM automation_runs ORDER BY started_at DESC, id DESC LIMIT $1",
      [safeLimit]
    );
    return result.rows.map(mapRun);
  }
}

export class EmptyAutomationRepository implements AutomationRepository {
  async listJobs(): Promise<AutomationJob[]> {
    return [];
  }

  async listRuns(): Promise<AutomationRun[]> {
    return [];
  }
}

export async function seedAutomationJobsIfEmpty(db: Database): Promise<number> {
  const jobs = [
    {
      id: "deadline-watch",
      name: "Deadline Watch",
      jobType: "deadline-watch",
      scheduleMinutes: 60
    },
    {
      id: "submission-integrity",
      name: "Submission Integrity",
      jobType: "submission-integrity",
      scheduleMinutes: 60
    },
    {
      id: "daily-backup",
      name: "Daily Backup",
      jobType: "daily-backup",
      scheduleMinutes: 1440
    },
    {
      id: "patroll-public-scan",
      name: "PATROLL Public Scan",
      jobType: "patroll-public-scan",
      scheduleMinutes: 360
    },
    {
      id: "metaculus-public-scan",
      name: "Metaculus FutureEval Scan",
      jobType: "metaculus-public-scan",
      scheduleMinutes: 360
    },
    {
      id: "wazoku-public-scan",
      name: "Wazoku/InnoCentive Public Scan",
      jobType: "wazoku-public-scan",
      scheduleMinutes: 720
    },
    {
      id: "drivendata-public-scan",
      name: "DrivenData Public Scan",
      jobType: "drivendata-public-scan",
      scheduleMinutes: 720
    },
    {
      id: "devpost-public-scan",
      name: "Devpost High-Value Public Scan",
      jobType: "devpost-public-scan",
      scheduleMinutes: 720
    }
  ];

  let inserted = 0;

  for (const job of jobs) {
    const result = await db.query(
      "INSERT INTO automation_jobs (id,name,job_type,enabled,schedule_minutes,next_run_at,last_status,last_message) VALUES ($1,$2,$3,TRUE,$4,NOW(),'pending','Waiting for first worker run') ON CONFLICT (id) DO NOTHING",
      [job.id, job.name, job.jobType, job.scheduleMinutes]
    );
    inserted += result.rowCount ?? 0;
  }

  if (inserted > 0) {
    console.log(`Seeded ${inserted} new automation job(s)`);
  }

  return inserted;
}
