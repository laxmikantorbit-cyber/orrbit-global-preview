import {
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual
} from "node:crypto";
import type { Database } from "./database.js";

export type AuthSession = {
  authenticated: boolean;
  ownerLogin?: string;
  expiresAt?: string;
};

export type LoginResult = {
  token: string;
  ownerLogin: string;
  expiresAt: string;
  maxAgeSeconds: number;
};

export type AuthService = {
  enabled: boolean;
  secureCookie: boolean;
  login(ownerLogin: string, password: string): Promise<LoginResult | undefined>;
  getSession(token: string | undefined): Promise<AuthSession>;
  logout(token: string | undefined): Promise<void>;
};

export type OwnerAuthConfig = {
  ownerLogin: string;
  passwordHash: string;
  secureCookie: boolean;
  sessionHours: number;
};

export function hashPassword(password: string, salt = randomBytes(16)): string {
  const derived = scryptSync(password, salt, 64);
  return [
    "scrypt",
    salt.toString("base64"),
    derived.toString("base64")
  ].join("$");
}

export function verifyPassword(password: string, encoded: string): boolean {
  const [algorithm, saltEncoded, hashEncoded] = encoded.split("$");
  if (algorithm !== "scrypt" || !saltEncoded || !hashEncoded) return false;

  try {
    const salt = Buffer.from(saltEncoded, "base64");
    const expected = Buffer.from(hashEncoded, "base64");
    const actual = scryptSync(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function tokenHash(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export class PostgresOwnerAuthService implements AuthService {
  readonly enabled = true;

  constructor(
    private readonly db: Database,
    private readonly config: OwnerAuthConfig
  ) {}

  get secureCookie(): boolean {
    return this.config.secureCookie;
  }

  async login(ownerLogin: string, password: string): Promise<LoginResult | undefined> {
    const loginMatches = timingSafeEqualText(ownerLogin, this.config.ownerLogin);
    const passwordMatches = verifyPassword(password, this.config.passwordHash);

    if (!loginMatches || !passwordMatches) {
      return undefined;
    }

    const token = randomBytes(32).toString("base64url");
    const hash = tokenHash(token);
    const maxAgeSeconds = Math.max(1, Math.round(this.config.sessionHours * 3600));
    const expiresAt = new Date(Date.now() + maxAgeSeconds * 1000);

    await this.db.query(
      "DELETE FROM auth_sessions WHERE expires_at <= NOW()"
    );

    await this.db.query(
      "INSERT INTO auth_sessions (token_hash,owner_login,expires_at,last_seen_at) VALUES ($1,$2,$3,NOW())",
      [hash, this.config.ownerLogin, expiresAt]
    );

    return {
      token,
      ownerLogin: this.config.ownerLogin,
      expiresAt: expiresAt.toISOString(),
      maxAgeSeconds
    };
  }

  async getSession(token: string | undefined): Promise<AuthSession> {
    if (!token) return { authenticated: false };

    const result = await this.db.query<{
      owner_login: string;
      expires_at: Date | string;
    }>(
      "SELECT owner_login,expires_at FROM auth_sessions WHERE token_hash = $1 AND expires_at > NOW() LIMIT 1",
      [tokenHash(token)]
    );

    const row = result.rows[0];
    if (!row) return { authenticated: false };

    await this.db.query(
      "UPDATE auth_sessions SET last_seen_at = NOW() WHERE token_hash = $1",
      [tokenHash(token)]
    );

    const expiresAt = row.expires_at instanceof Date
      ? row.expires_at.toISOString()
      : new Date(row.expires_at).toISOString();

    return {
      authenticated: true,
      ownerLogin: row.owner_login,
      expiresAt
    };
  }

  async logout(token: string | undefined): Promise<void> {
    if (!token) return;
    await this.db.query(
      "DELETE FROM auth_sessions WHERE token_hash = $1",
      [tokenHash(token)]
    );
  }
}

export class InMemoryOwnerAuthService implements AuthService {
  readonly enabled = true;
  private readonly sessions = new Map<string, { ownerLogin: string; expiresAt: Date }>();

  constructor(private readonly config: OwnerAuthConfig) {}

  get secureCookie(): boolean {
    return this.config.secureCookie;
  }

  async login(ownerLogin: string, password: string): Promise<LoginResult | undefined> {
    const loginMatches = timingSafeEqualText(ownerLogin, this.config.ownerLogin);
    const passwordMatches = verifyPassword(password, this.config.passwordHash);
    if (!loginMatches || !passwordMatches) return undefined;

    const now = Date.now();
    for (const [hash, session] of this.sessions) {
      if (session.expiresAt.getTime() <= now) this.sessions.delete(hash);
    }

    const token = randomBytes(32).toString("base64url");
    const maxAgeSeconds = Math.max(1, Math.round(this.config.sessionHours * 3600));
    const expiresAt = new Date(now + maxAgeSeconds * 1000);
    this.sessions.set(tokenHash(token), { ownerLogin: this.config.ownerLogin, expiresAt });

    return {
      token,
      ownerLogin: this.config.ownerLogin,
      expiresAt: expiresAt.toISOString(),
      maxAgeSeconds
    };
  }

  async getSession(token: string | undefined): Promise<AuthSession> {
    if (!token) return { authenticated: false };
    const session = this.sessions.get(tokenHash(token));
    if (!session || session.expiresAt.getTime() <= Date.now()) {
      if (session) this.sessions.delete(tokenHash(token));
      return { authenticated: false };
    }
    return {
      authenticated: true,
      ownerLogin: session.ownerLogin,
      expiresAt: session.expiresAt.toISOString()
    };
  }

  async logout(token: string | undefined): Promise<void> {
    if (token) this.sessions.delete(tokenHash(token));
  }
}

export class DisabledAuthService implements AuthService {
  readonly enabled = false;
  readonly secureCookie = false;

  async login(): Promise<LoginResult | undefined> {
    return undefined;
  }

  async getSession(): Promise<AuthSession> {
    return { authenticated: true, ownerLogin: "development" };
  }

  async logout(): Promise<void> {}
}

function timingSafeEqualText(left: string, right: string): boolean {
  const leftHash = createHash("sha256").update(left).digest();
  const rightHash = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftHash, rightHash);
}
