import type { Database } from "./database.js";

export type ResearchProject = {
  id: string;
  opportunityId: string;
  title: string;
  researchType: string;
  status: string;
  progress: number;
  targetClaim: string | null;
  cutoffDate: string | null;
  notes: string;
};

export type ResearchLimitation = {
  id: string;
  researchProjectId: string;
  position: number;
  limitation: string;
  status: string;
  notes: string;
};

export type EvidenceItem = {
  id: string;
  researchProjectId: string;
  limitationId: string | null;
  title: string;
  sourceType: string;
  sourceUrl: string | null;
  publishedDate: string | null;
  relevance: string;
  qualityScore: number | null;
  status: string;
  notes: string;
};

export type ResearchRepository = {
  listProjects(): Promise<ResearchProject[]>;
  findProjectById(id: string): Promise<ResearchProject | undefined>;
  listLimitations(projectId: string): Promise<ResearchLimitation[]>;
  listEvidence(projectId: string): Promise<EvidenceItem[]>;
};

type ProjectRow = {
  id: string;
  opportunity_id: string;
  title: string;
  research_type: string;
  status: string;
  progress: number;
  target_claim: string | null;
  cutoff_date: Date | string | null;
  notes: string;
};

type LimitationRow = {
  id: string;
  research_project_id: string;
  position: number;
  limitation: string;
  status: string;
  notes: string;
};

type EvidenceRow = {
  id: string;
  research_project_id: string;
  limitation_id: string | null;
  title: string;
  source_type: string;
  source_url: string | null;
  published_date: Date | string | null;
  relevance: string;
  quality_score: number | null;
  status: string;
  notes: string;
};

function dateOnly(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date
    ? value.toISOString().slice(0, 10)
    : String(value).slice(0, 10);
}

function mapProject(row: ProjectRow): ResearchProject {
  return {
    id: row.id,
    opportunityId: row.opportunity_id,
    title: row.title,
    researchType: row.research_type,
    status: row.status,
    progress: row.progress,
    targetClaim: row.target_claim,
    cutoffDate: dateOnly(row.cutoff_date),
    notes: row.notes
  };
}

function mapLimitation(row: LimitationRow): ResearchLimitation {
  return {
    id: row.id,
    researchProjectId: row.research_project_id,
    position: row.position,
    limitation: row.limitation,
    status: row.status,
    notes: row.notes
  };
}

function mapEvidence(row: EvidenceRow): EvidenceItem {
  return {
    id: row.id,
    researchProjectId: row.research_project_id,
    limitationId: row.limitation_id,
    title: row.title,
    sourceType: row.source_type,
    sourceUrl: row.source_url,
    publishedDate: dateOnly(row.published_date),
    relevance: row.relevance,
    qualityScore: row.quality_score,
    status: row.status,
    notes: row.notes
  };
}

export class PostgresResearchRepository implements ResearchRepository {
  constructor(private readonly db: Database) {}

  async listProjects(): Promise<ResearchProject[]> {
    const result = await this.db.query<ProjectRow>(`
      SELECT
        id, opportunity_id, title, research_type, status, progress,
        target_claim, cutoff_date, notes
      FROM research_projects
      ORDER BY updated_at DESC, id ASC
    `);
    return result.rows.map(mapProject);
  }

  async findProjectById(id: string): Promise<ResearchProject | undefined> {
    const result = await this.db.query<ProjectRow>(`
      SELECT
        id, opportunity_id, title, research_type, status, progress,
        target_claim, cutoff_date, notes
      FROM research_projects
      WHERE id = $1
      LIMIT 1
    `, [id]);

    const row = result.rows[0];
    return row ? mapProject(row) : undefined;
  }

  async listLimitations(projectId: string): Promise<ResearchLimitation[]> {
    const result = await this.db.query<LimitationRow>(`
      SELECT id, research_project_id, position, limitation, status, notes
      FROM research_limitations
      WHERE research_project_id = $1
      ORDER BY position ASC
    `, [projectId]);

    return result.rows.map(mapLimitation);
  }

  async listEvidence(projectId: string): Promise<EvidenceItem[]> {
    const result = await this.db.query<EvidenceRow>(`
      SELECT
        id, research_project_id, limitation_id, title, source_type,
        source_url, published_date, relevance, quality_score, status, notes
      FROM evidence_items
      WHERE research_project_id = $1
      ORDER BY quality_score DESC NULLS LAST, created_at ASC
    `, [projectId]);

    return result.rows.map(mapEvidence);
  }
}

export async function seedResearchWorkspaceIfEmpty(db: Database): Promise<number> {
  const existing = await db.query<{ count: string }>(
    "SELECT COUNT(*)::text AS count FROM research_projects"
  );

  if (Number(existing.rows[0]?.count ?? "0") > 0) {
    return 0;
  }

  const opportunity = await db.query(
    "SELECT 1 FROM opportunities WHERE id = $1",
    ["patroll-arc-11563655"]
  );

  if (!opportunity.rowCount) {
    return 0;
  }

  const projectId = "research-arc-link-claim1";
  const client = await db.connect();

  try {
    await client.query("BEGIN");

    await client.query(`
      INSERT INTO research_projects
        (id, opportunity_id, title, research_type, status, progress, target_claim, cutoff_date, notes)
      VALUES
        ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [
      projectId,
      "patroll-arc-11563655",
      "Arc Link SDN — Claim 1 Prior-Art Research",
      "patent-prior-art",
      "researching",
      78,
      "Claim 1",
      "2020-04-28",
      "Issued Claim 1 corrected to seven limitations. FlowVisor provides the primary dated statistics evidence; US9838253B2 provides a pre-cutoff shared-vs-dedicated physical-resource mapping/oversubscription combination lead. PATROLL known-reference review remains blocking."
    ]);

    const limitations: Array<[string, number, string, string, string]> = [
      ["arc-l1-01", 1, "Computing apparatus implemented with a network hypervisor implementing SDN-based network virtualization.", "covered", "FlowVisor is documented as a network hypervisor/proxy and slicing layer."],
      ["arc-l1-02", 2, "Multiple separately managed virtual networks operate over shared physical network resources.", "covered", "FlowVisor delegates slices to separate controllers while sharing physical forwarding infrastructure."],
      ["arc-l1-03", 3, "Receive a request for individual physical-resource consumption statistics for a first virtual network.", "covered", "FlowVisor source handles statistics requests from an individual slice controller and maps replies back to that slice."],
      ["arc-l1-04", 4, "Determine whether at least one physical resource is shared between the first virtual network and at least one other virtual network.", "partial", "US9838253B2 expressly distinguishes dedicated resources from oversubscribed/shared resources using VNO service patterns and mapping state; combined with FlowVisor this is a credible l4 lead, but the combination rationale still needs claim-chart review."],
      ["arc-l1-05", 5, "Isolatedly provide individual physical-resource consumption statistics to the first virtual network based on that shared-resource determination.", "partial", "FlowVisor partitions flow statistics by slice and filters port statistics by slice, but the claimed dependency on the shared-resource determination needs tighter proof."],
      ["arc-l1-06", 6, "Provide virtual flow-entry statistics for the first virtual network.", "covered", "FlowVisor classifies physical flow statistics by translated cookie/slice and returns only the requesting slice's flow statistics."],
      ["arc-l1-07", 7, "Provide virtual-port statistics based on the physical resource for the first virtual network.", "covered", "FlowVisor filters physical port-stat replies so a slice receives only ports present in its sliced topology."]
    ];

    for (const [id, position, limitation, status, notes] of limitations) {
      await client.query(`
        INSERT INTO research_limitations
          (id, research_project_id, position, limitation, status, notes)
        VALUES ($1,$2,$3,$4,$5,$6)
      `, [id, projectId, position, limitation, status, notes]);
    }

    const evidence: Array<{
      id: string;
      limitationId: string | null;
      title: string;
      sourceType: string;
      sourceUrl: string | null;
      publishedDate: string | null;
      relevance: string;
      qualityScore: number;
      status: string;
      notes: string;
    }> = [
      {
        id: "arc-ev-flowvisor-paper",
        limitationId: "arc-l1-01",
        title: "FlowVisor / Can the Production Network Be the Testbed?",
        sourceType: "paper",
        sourceUrl: "https://www.usenix.org/legacy/event/osdi10/tech/full_papers/Sherwood.pdf",
        publishedDate: "2010-10-06",
        relevance: "Dated OSDI 2010 paper directly describes FlowVisor as a network slicing layer/hypervisor enabling multiple isolated slices on shared physical infrastructure.",
        qualityScore: 90,
        status: "verified-lead",
        notes: "Public USENIX source verified. Supports the network-hypervisor and shared-infrastructure context; code-level statistics behavior is mapped separately."
      },
      {
        id: "arc-ev-flowvisor-slices-paper",
        limitationId: "arc-l1-02",
        title: "FlowVisor shared physical infrastructure and separate slice controllers",
        sourceType: "paper",
        sourceUrl: "https://www.usenix.org/conference/osdi10/can-production-network-be-testbed",
        publishedDate: "2010-10-06",
        relevance: "USENIX OSDI 2010 describes FlowVisor slicing production network hardware into isolated slices controlled by different controllers.",
        qualityScore: 90,
        status: "verified-lead",
        notes: "Pre-cutoff public conference record; supports multiple separately managed virtual networks sharing physical infrastructure."
      },
      {
        id: "arc-ev-flowvisor-stats-request-code",
        limitationId: "arc-l1-03",
        title: "FlowVisor per-slice statistics request path",
        sourceType: "source-code",
        sourceUrl: "https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/message/statistics/FVFlowStatisticsRequest.java",
        publishedDate: "2013-08-30",
        relevance: "The pre-cutoff source routes a flow-statistics request from an individual FVSlicer through the physical classifier and returns that slice's statistics.",
        qualityScore: 94,
        status: "verified-lead",
        notes: "Verified locally at public repository commit b45b58f1afc674d8cd79126e0652aef2563838b2."
      },
      {
        id: "arc-ev-flowvisor-flowspace-code",
        limitationId: "arc-l1-04",
        title: "FlowVisor FlowSpace multi-slice physical-resource mapping",
        sourceType: "source-code",
        sourceUrl: "https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/flows/FlowSpaceUtil.java",
        publishedDate: "2013-08-30",
        relevance: "FlowSpace rules enumerate slice actions for a physical switch/flowspace and can associate multiple slices with the same physical rule.",
        qualityScore: 91,
        status: "verified-lead",
        notes: "Verified code proves shareability/mapping, but not yet the exact claimed statistics-time determination; limitation remains open."
      },
      {
        id: "arc-ev-flowvisor-isolation-code",
        limitationId: "arc-l1-05",
        title: "FlowVisor per-slice physical flow-statistics isolation",
        sourceType: "source-code",
        sourceUrl: "https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/classifier/FVClassifier.java",
        publishedDate: "2013-08-30",
        relevance: "Physical flow statistics are classified by translated cookie into slice-keyed stores and responses are built from the requesting slice's store.",
        qualityScore: 94,
        status: "verified-lead",
        notes: "Strong isolation evidence; exact dependency on an explicit shared-resource determination remains a mapping issue."
      },
      {
        id: "arc-ev-flowvisor-flowstats-code",
        limitationId: "arc-l1-06",
        title: "FlowVisor virtual flow-entry statistics by slice",
        sourceType: "source-code",
        sourceUrl: "https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/classifier/FVClassifier.java",
        publishedDate: "2013-08-30",
        relevance: "Flow statistics are classified to the owning slice, restored to the slice cookie, filtered by the request, and returned only to that slicer.",
        qualityScore: 95,
        status: "verified-lead",
        notes: "Verified locally at the exact pre-cutoff public commit."
      },
      {
        id: "arc-ev-flowvisor-portstats-code",
        limitationId: "arc-l1-07",
        title: "FlowVisor per-slice virtualized port statistics",
        sourceType: "source-code",
        sourceUrl: "https://github.com/opennetworkinglab/flowvisor/blob/b45b58f1afc674d8cd79126e0652aef2563838b2/src/org/flowvisor/message/statistics/FVPortStatisticsReply.java",
        publishedDate: "2013-08-30",
        relevance: "Physical port-stat replies expose packet/byte counters and are filtered so ports outside the requesting slice are removed before the reply is sent.",
        qualityScore: 95,
        status: "verified-lead",
        notes: "Matches the documented FlowVisor port-stat virtualization behavior and is pre-cutoff."
      },
      {
        id: "arc-ev-fujitsu-oonv-sharing",
        limitationId: "arc-l1-04",
        title: "US9838253B2 Object-oriented network virtualization — shared vs dedicated physical resources",
        sourceType: "patent",
        sourceUrl: "https://patents.google.com/patent/US9838253B2/en",
        publishedDate: "2015-10-15",
        relevance: "Pre-cutoff Fujitsu OONV disclosure states that multiple virtual network objects may share the same physical network resources, distinguishes dedicated resources from oversubscribed/shared resources, stores a sharing schedule/policy in a VNO service pattern, and uses virtual-to-physical mapping state.",
        qualityScore: 93,
        status: "verified-lead",
        notes: "Combination lead for limitation 4 with FlowVisor. It supports determining/knowing shared-vs-dedicated resource state, but does not itself supply FlowVisor's per-slice statistics path; do not represent it as a single-reference anticipation."
      },
      {
        id: "arc-ev-ovx-flowstats",
        limitationId: "arc-l1-06",
        title: "OpenVirteX tenant-keyed flow statistics",
        sourceType: "architecture-doc",
        sourceUrl: "https://openvirtex.com/documentation/architecture/operation-and-subsystems/",
        publishedDate: null,
        relevance: "Current OpenVirteX architecture documentation describes tenant-keyed flowStats populated by StatisticsManager polling physical datapaths.",
        qualityScore: 60,
        status: "background-lead",
        notes: "Background only. Current documentation is not relied on for the pre-cutoff chart because durable pre-cutoff provenance is not verified in the present clone."
      },
      {
        id: "arc-ev-ovx-portstats",
        limitationId: "arc-l1-07",
        title: "OpenVirteX physical-switch port statistics",
        sourceType: "architecture-doc",
        sourceUrl: "https://openvirtex.com/documentation/architecture/operation-and-subsystems/",
        publishedDate: null,
        relevance: "Current OpenVirteX architecture documentation describes PhysicalSwitch portStats and OFPortStatisticsRequest polling.",
        qualityScore: 60,
        status: "background-lead",
        notes: "Background only. Current documentation is not relied on for the pre-cutoff chart because durable pre-cutoff provenance is not verified in the present clone."
      }
    ];

    for (const item of evidence) {
      await client.query(`
        INSERT INTO evidence_items
          (id, research_project_id, limitation_id, title, source_type,
           source_url, published_date, relevance, quality_score, status, notes)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      `, [
        item.id,
        projectId,
        item.limitationId,
        item.title,
        item.sourceType,
        item.sourceUrl,
        item.publishedDate,
        item.relevance,
        item.qualityScore,
        item.status,
        item.notes
      ]);
    }

    await client.query("COMMIT");
    console.log("Seeded Arc Link research workspace");
    return 1;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export class EmptyResearchRepository implements ResearchRepository {
  async listProjects(): Promise<ResearchProject[]> {
    return [];
  }

  async findProjectById(): Promise<ResearchProject | undefined> {
    return undefined;
  }

  async listLimitations(): Promise<ResearchLimitation[]> {
    return [];
  }

  async listEvidence(): Promise<EvidenceItem[]> {
    return [];
  }
}
