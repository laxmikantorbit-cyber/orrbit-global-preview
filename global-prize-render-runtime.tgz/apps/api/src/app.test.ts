import assert from "node:assert/strict";
import { createServer } from "node:http";
import test from "node:test";
import { createRequestHandler } from "./app.js";
import type {
  AutomationJob,
  AutomationRepository,
  AutomationRun
} from "./automation.js";
import {
  hashPassword,
  verifyPassword,
  type AuthService
} from "./auth.js";
import type {
  BackupRecord,
  BackupRepository
} from "./backup.js";
import type { OpportunityAssessment } from "./opportunity-assessment.js";
import type { Opportunity, OpportunityRepository } from "./opportunities.js";
import type {
  EvidenceItem,
  ResearchLimitation,
  ResearchProject,
  ResearchRepository
} from "./research.js";
import type {
  SubmissionItem,
  SubmissionRepository
} from "./submissions.js";
import type {
  IngestionResult,
  OpportunityObservation,
  OpportunitySource,
  ScannerRepository,
  VerifiedOpportunityInput
} from "./scanner.js";

const opportunityFixtures: Opportunity[] = [
  {
    id: "low",
    platform: "PATROLL",
    title: "Low score",
    prizeUsd: 2000,
    deadline: "2026-10-10",
    eligibility: "eligible",
    automation: "allowed",
    score: 60,
    status: "queued"
  },
  {
    id: "high",
    platform: "Wazoku",
    title: "High score",
    prizeUsd: 25000,
    deadline: "2026-10-12",
    eligibility: "review",
    automation: "assisted",
    score: 90,
    status: "researching"
  }
];

const opportunityRepo: OpportunityRepository = {
  async list() {
    return opportunityFixtures.slice().sort((a, b) => b.score - a.score);
  },
  async findById(id) {
    return opportunityFixtures.find((item) => item.id === id);
  }
};

const projectFixtures: ResearchProject[] = [
  {
    id: "research-high",
    opportunityId: "high",
    title: "High score research",
    researchType: "patent-prior-art",
    status: "researching",
    progress: 25,
    targetClaim: "Claim 1",
    cutoffDate: "2020-04-28",
    notes: "Fixture project"
  }
];

const limitationFixtures: ResearchLimitation[] = [
  {
    id: "lim-1",
    researchProjectId: "research-high",
    position: 1,
    limitation: "First limitation",
    status: "lead",
    notes: "Lead exists"
  },
  {
    id: "lim-2",
    researchProjectId: "research-high",
    position: 2,
    limitation: "Second limitation",
    status: "open",
    notes: "Proof gap"
  }
];

const evidenceFixtures: EvidenceItem[] = [
  {
    id: "ev-1",
    researchProjectId: "research-high",
    limitationId: "lim-1",
    title: "Prior-art reference",
    sourceType: "paper",
    sourceUrl: null,
    publishedDate: "2013-10-24",
    relevance: "Relevant fixture",
    qualityScore: 82,
    status: "verified-lead",
    notes: "Fixture evidence"
  }
];

const researchRepo: ResearchRepository = {
  async listProjects() {
    return projectFixtures;
  },
  async findProjectById(id) {
    return projectFixtures.find((item) => item.id === id);
  },
  async listLimitations(projectId) {
    return limitationFixtures.filter((item) => item.researchProjectId === projectId);
  },
  async listEvidence(projectId) {
    return evidenceFixtures.filter((item) => item.researchProjectId === projectId);
  }
};

const submissionFixtures: SubmissionItem[] = [
  {
    id: "submission-high-draft",
    opportunityId: "high",
    researchProjectId: "research-high",
    title: "High score submission draft",
    platform: "Wazoku",
    status: "draft",
    deadline: "2026-10-12",
    submittedAt: null,
    resultStatus: null,
    awardUsd: null,
    externalReference: null,
    notes: "Internal draft only."
  }
];

const submissionRepo: SubmissionRepository = {
  async list() {
    return submissionFixtures;
  },
  async findById(id) {
    return submissionFixtures.find((item) => item.id === id);
  }
};

const automationJobFixtures: AutomationJob[] = [
  {
    id: "deadline-watch",
    name: "Deadline Watch",
    jobType: "deadline-watch",
    enabled: true,
    scheduleMinutes: 60,
    lastStartedAt: null,
    lastFinishedAt: null,
    nextRunAt: "2026-09-23T09:00:00.000Z",
    lastStatus: "pending",
    lastMessage: "Waiting for first worker run"
  }
];

const automationRunFixtures: AutomationRun[] = [
  {
    id: 1,
    jobId: "deadline-watch",
    startedAt: "2026-09-23T08:00:00.000Z",
    finishedAt: "2026-09-23T08:00:01.000Z",
    status: "ok",
    message: "2 opportunities due within 21 days",
    summary: { count: 2 }
  }
];

const automationRepo: AutomationRepository = {
  async listJobs() {
    return automationJobFixtures;
  },
  async listRuns(limit = 20) {
    return automationRunFixtures.slice(0, limit);
  }
};

const backupFixtures: BackupRecord[] = [
  {
    id: 1,
    backupKey: "20260923T040000Z",
    status: "completed",
    databaseFile: "/backups/20260923T040000Z/database.dump",
    filesArchive: "/backups/20260923T040000Z/files.tar.gz",
    databaseBytes: 1024,
    filesBytes: 2048,
    startedAt: "2026-09-23T04:00:00.000Z",
    finishedAt: "2026-09-23T04:00:02.000Z",
    verifiedAt: "2026-09-23T04:00:03.000Z",
    verificationStatus: "verified",
    message: "Backup completed and verified"
  }
];

const backupRepo: BackupRepository = {
  async list(limit = 20) {
    return backupFixtures.slice(0, limit);
  },
  async latest() {
    return backupFixtures[0];
  }
};

const scannerSourceFixtures: OpportunitySource[] = [
  {
    id: "patroll-public",
    name: "PATROLL Public Contests",
    platform: "PATROLL",
    sourceUrl: "https://patroll.unifiedpatents.com/contests?category=all",
    adapterType: "browser-public-page",
    enabled: true,
    scanIntervalMinutes: 360,
    lastStartedAt: null,
    lastFinishedAt: null,
    nextScanAt: "2026-09-23T12:00:00.000Z",
    lastStatus: "pending",
    lastMessage: "Waiting for first scanner adapter run"
  }
];

const scannerObservationFixtures: OpportunityObservation[] = [
  {
    id: 1,
    sourceId: "patroll-public",
    externalKey: "contest-1",
    canonicalOpportunityId: "scan-patroll-public-abc123",
    observedAt: "2026-09-23T10:00:00.000Z",
    snapshotHash: "hash-1",
    isNew: true,
    changedFields: ["title", "prizeUsd"],
    payload: {
      title: "Fixture contest",
      prizeUsd: 2000
    }
  }
];

const scannerRepo: ScannerRepository = {
  async listSources() {
    return scannerSourceFixtures;
  },
  async listObservations(limit = 50) {
    return scannerObservationFixtures.slice(0, limit);
  },
  async ingest(input: VerifiedOpportunityInput): Promise<IngestionResult> {
    if (!input.sourceId || !input.externalKey || !input.title) {
      throw new Error("invalid_scanner_fixture_input");
    }

    return {
      canonicalOpportunityId: "scan-patroll-public-fixture",
      action: input.externalKey === "new-contest" ? "created" : "updated",
      changedFields: input.externalKey === "new-contest" ? ["title", "prizeUsd"] : ["deadline"],
      snapshotHash: "fixture-hash"
    };
  }
};

const protectedAuth: AuthService = {
  enabled: true,
  secureCookie: false,
  async login(ownerLogin, password) {
    if (ownerLogin !== "owner" || password !== "correct-password") return undefined;
    return {
      token: "test-session-token",
      ownerLogin: "owner",
      expiresAt: "2026-09-24T00:00:00.000Z",
      maxAgeSeconds: 3600
    };
  },
  async getSession(token) {
    return token === "test-session-token"
      ? {
          authenticated: true,
          ownerLogin: "owner",
          expiresAt: "2026-09-24T00:00:00.000Z"
        }
      : { authenticated: false };
  },
  async logout() {}
};

async function withServer(
  run: (baseUrl: string) => Promise<void>,
  auth?: AuthService
): Promise<void> {
  const handler = auth
    ? createRequestHandler(
        "test-version",
        opportunityRepo,
        researchRepo,
        submissionRepo,
        automationRepo,
        backupRepo,
        scannerRepo,
        auth
      )
    : createRequestHandler(
        "test-version",
        opportunityRepo,
        researchRepo,
        submissionRepo,
        automationRepo,
        backupRepo,
        scannerRepo
      );

  const server = createServer(handler);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address === "object");

  try {
    await run(`http://127.0.0.1:${address.port}`);
  } finally {
    await new Promise<void>((resolve, reject) =>
      server.close((error) => error ? reject(error) : resolve())
    );
  }
}

test("GET /health returns a healthy payload", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/health`);
    const body = await response.json() as {
      service: string;
      status: string;
      version: string;
    };

    assert.equal(response.status, 200);
    assert.equal(body.service, "global-prize-api");
    assert.equal(body.status, "ok");
    assert.equal(body.version, "test-version");
  });
});

test("GET /api/opportunities returns score-ranked items", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/opportunities`);
    const body = await response.json() as {
      count: number;
      items: Opportunity[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 2);
    assert.equal(body.items[0]?.id, "high");
    assert.equal(body.items[1]?.id, "low");
  });
});

test("GET /api/opportunities/:id returns one item", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/opportunities/high`);
    const body = await response.json() as Opportunity;

    assert.equal(response.status, 200);
    assert.equal(body.title, "High score");
    assert.equal(body.prizeUsd, 25000);
  });
});

test("GET /api/opportunities/:id/assessment returns transparent execution signals", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/opportunities/high/assessment`);
    const body = await response.json() as OpportunityAssessment;

    assert.equal(response.status, 200);
    assert.equal(body.opportunityId, "high");
    assert.equal(body.priorityScore, 90);
    assert.equal(body.priorityBand, "top");
    assert.equal(body.rewardTier, "high");
    assert.equal(body.automationState, "ai-assisted");
    assert.equal(body.executionLane, "innovation-challenge");
    assert.match(body.note, /not a win probability/i);
  });
});

test("unknown opportunity returns a specific JSON 404", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/opportunities/missing`);
    const body = await response.json() as { error: string; id: string };

    assert.equal(response.status, 404);
    assert.equal(body.error, "opportunity_not_found");
    assert.equal(body.id, "missing");
  });
});

test("GET /api/research/projects returns research projects", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/research/projects`);
    const body = await response.json() as {
      count: number;
      items: ResearchProject[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.id, "research-high");
    assert.equal(body.items[0]?.progress, 25);
  });
});

test("GET /api/research/projects/:id returns one research project", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/research/projects/research-high`);
    const body = await response.json() as ResearchProject;

    assert.equal(response.status, 200);
    assert.equal(body.targetClaim, "Claim 1");
    assert.equal(body.cutoffDate, "2020-04-28");
  });
});

test("GET research limitations returns ordered project limitations", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/research/projects/research-high/limitations`
    );
    const body = await response.json() as {
      count: number;
      items: ResearchLimitation[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 2);
    assert.equal(body.items[0]?.id, "lim-1");
    assert.equal(body.items[1]?.status, "open");
  });
});

test("GET research evidence returns project evidence", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/research/projects/research-high/evidence`
    );
    const body = await response.json() as {
      count: number;
      items: EvidenceItem[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.qualityScore, 82);
    assert.equal(body.items[0]?.status, "verified-lead");
  });
});

test("GET /api/submissions returns tracked drafts without claiming external submission", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/submissions`);
    const body = await response.json() as {
      count: number;
      items: SubmissionItem[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.status, "draft");
    assert.equal(body.items[0]?.submittedAt, null);
    assert.equal(body.items[0]?.awardUsd, null);
  });
});

test("GET /api/submissions/:id returns one tracked submission", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/submissions/submission-high-draft`
    );
    const body = await response.json() as SubmissionItem;

    assert.equal(response.status, 200);
    assert.equal(body.opportunityId, "high");
    assert.equal(body.researchProjectId, "research-high");
    assert.equal(body.status, "draft");
  });
});

test("GET /api/submissions/:id/readiness returns a process gate", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/submissions/submission-high-draft/readiness`
    );
    const body = await response.json() as {
      submissionId: string;
      state: string;
      score: number;
      note: string;
    };

    assert.equal(response.status, 200);
    assert.equal(body.submissionId, "submission-high-draft");
    assert.ok(["blocked", "review-required", "ready"].includes(body.state));
    assert.ok(body.score >= 0 && body.score <= 100);
    assert.match(body.note, /not a prediction/i);
  });
});

test("GET /api/results/summary counts only recorded outcomes", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/results/summary`);
    const body = await response.json() as {
      trackedSubmissions: number;
      submitted: number;
      wins: number;
      awardedUsd: number;
      note: string;
    };

    assert.equal(response.status, 200);
    assert.equal(body.trackedSubmissions, 1);
    assert.equal(body.submitted, 0);
    assert.equal(body.wins, 0);
    assert.equal(body.awardedUsd, 0);
    assert.match(body.note, /not counted as earnings/i);
  });
});

test("GET /api/reports/portfolio separates visible prize from awards", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/reports/portfolio`);
    const body = await response.json() as {
      totalOpportunities: number;
      totalVisiblePrizeUsd: number;
      results: { awardedUsd: number };
      platforms: Array<{ platform: string }>;
    };

    assert.equal(response.status, 200);
    assert.equal(body.totalOpportunities, 2);
    assert.equal(body.totalVisiblePrizeUsd, 27000);
    assert.equal(body.results.awardedUsd, 0);
    assert.ok(body.platforms.some((item) => item.platform === "PATROLL"));
  });
});

test("unknown submission returns a specific JSON 404", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/submissions/missing`
    );
    const body = await response.json() as { error: string; id: string };

    assert.equal(response.status, 404);
    assert.equal(body.error, "submission_not_found");
    assert.equal(body.id, "missing");
  });
});

test("scrypt owner password hashes verify without storing plaintext", () => {
  const encoded = hashPassword("correct-password", Buffer.alloc(16, 7));

  assert.equal(verifyPassword("correct-password", encoded), true);
  assert.equal(verifyPassword("wrong-password", encoded), false);
  assert.equal(encoded.includes("correct-password"), false);
});

test("protected API rejects requests without an owner session", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/opportunities`);
    const body = await response.json() as { error: string };

    assert.equal(response.status, 401);
    assert.equal(body.error, "authentication_required");
  }, protectedAuth);
});

test("owner login issues an HttpOnly session cookie and unlocks protected APIs", async () => {
  await withServer(async (baseUrl) => {
    const loginResponse = await fetch(`${baseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ownerLogin: "owner",
        password: "correct-password"
      })
    });

    assert.equal(loginResponse.status, 200);
    const cookie = loginResponse.headers.get("set-cookie") ?? "";
    assert.match(cookie, /gpre_session=test-session-token/);
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Strict/);

    const sessionResponse = await fetch(`${baseUrl}/api/auth/session`, {
      headers: { cookie: "gpre_session=test-session-token" }
    });
    const session = await sessionResponse.json() as {
      authenticated: boolean;
      ownerLogin?: string;
    };

    assert.equal(sessionResponse.status, 200);
    assert.equal(session.authenticated, true);
    assert.equal(session.ownerLogin, "owner");

    const protectedResponse = await fetch(`${baseUrl}/api/opportunities`, {
      headers: { cookie: "gpre_session=test-session-token" }
    });
    assert.equal(protectedResponse.status, 200);

    const logoutResponse = await fetch(`${baseUrl}/api/auth/logout`, {
      method: "POST",
      headers: { cookie: "gpre_session=test-session-token" }
    });
    assert.equal(logoutResponse.status, 200);
    assert.match(logoutResponse.headers.get("set-cookie") ?? "", /Max-Age=0/);
  }, protectedAuth);
});

test("invalid owner credentials are rejected without a session cookie", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ownerLogin: "owner",
        password: "wrong-password"
      })
    });

    assert.equal(response.status, 401);
    assert.equal(response.headers.get("set-cookie"), null);
  }, protectedAuth);
});

test("GET /api/automation/jobs returns configured worker jobs", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/automation/jobs`);
    const body = await response.json() as {
      count: number;
      items: AutomationJob[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.jobType, "deadline-watch");
    assert.equal(body.items[0]?.enabled, true);
  });
});

test("GET /api/automation/runs returns recent worker runs", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/automation/runs?limit=5`);
    const body = await response.json() as {
      count: number;
      items: AutomationRun[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.status, "ok");
    assert.equal(body.items[0]?.jobId, "deadline-watch");
  });
});

test("GET /api/backups returns backup history", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/backups?limit=5`);
    const body = await response.json() as {
      count: number;
      items: BackupRecord[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.backupKey, "20260923T040000Z");
    assert.equal(body.items[0]?.verificationStatus, "verified");
  });
});

test("GET /api/backups/latest returns the newest backup", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/backups/latest`);
    const body = await response.json() as {
      item: BackupRecord | null;
    };

    assert.equal(response.status, 200);
    assert.equal(body.item?.status, "completed");
    assert.equal(body.item?.databaseBytes, 1024);
    assert.equal(body.item?.filesBytes, 2048);
  });
});

test("GET /api/scanner/sources returns configured public sources", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/scanner/sources`);
    const body = await response.json() as {
      count: number;
      items: OpportunitySource[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.id, "patroll-public");
    assert.equal(body.items[0]?.adapterType, "browser-public-page");
  });
});

test("GET /api/scanner/observations returns provenance history", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/scanner/observations?limit=10`);
    const body = await response.json() as {
      count: number;
      items: OpportunityObservation[];
    };

    assert.equal(response.status, 200);
    assert.equal(body.count, 1);
    assert.equal(body.items[0]?.sourceId, "patroll-public");
    assert.equal(body.items[0]?.isNew, true);
  });
});

test("POST /api/scanner/ingest normalizes a verified scanner item", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/scanner/ingest`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        sourceId: "patroll-public",
        externalKey: "new-contest",
        platform: "PATROLL",
        title: "New prior-art contest",
        prizeUsd: 2000,
        deadline: "2026-10-18",
        eligibility: "account required",
        automation: "AI-assisted claim chart required",
        status: "active",
        sourceUrl: "https://patroll.unifiedpatents.com/contests/example",
        verificationStatus: "verified"
      })
    });

    const body = await response.json() as IngestionResult;

    assert.equal(response.status, 201);
    assert.equal(body.action, "created");
    assert.equal(body.canonicalOpportunityId, "scan-patroll-public-fixture");
    assert.deepEqual(body.changedFields, ["title", "prizeUsd"]);
  });
});

test("POST /api/scanner/ingest rejects incomplete scanner data", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/scanner/ingest`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        sourceId: "patroll-public"
      })
    });

    const body = await response.json() as {
      error: string;
      reason: string;
    };

    assert.equal(response.status, 400);
    assert.equal(body.error, "scanner_ingest_rejected");
    assert.equal(body.reason, "invalid_scanner_fixture_input");
  });
});

test("unknown research project returns a specific JSON 404", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(
      `${baseUrl}/api/research/projects/missing/limitations`
    );
    const body = await response.json() as { error: string; id: string };

    assert.equal(response.status, 404);
    assert.equal(body.error, "research_project_not_found");
    assert.equal(body.id, "missing");
  });
});

test("unknown routes return JSON 404", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/missing`);
    const body = await response.json() as { error: string };

    assert.equal(response.status, 404);
    assert.equal(body.error, "not_found");
  });
});
