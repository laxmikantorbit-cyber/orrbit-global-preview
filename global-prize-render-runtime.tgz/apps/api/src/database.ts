import { readdir, readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";
import { FileOpportunityRepository, type Opportunity } from "./opportunities.js";

const { Pool } = pg;

export type Database = InstanceType<typeof Pool>;

export function createDatabase(connectionString: string): Database {
  return new Pool({
    connectionString,
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000
  });
}

function migrationsDirectory(): string {
  const here = dirname(fileURLToPath(import.meta.url));
  return resolve(here, "../migrations");
}

export async function migrateDatabase(db: Database, stopBefore?: string): Promise<void> {
  await db.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  const files = (await readdir(migrationsDirectory()))
    .filter((name) => /^\d+_.*\.sql$/.test(name))
    .filter((name) => !stopBefore || name.localeCompare(stopBefore) < 0)
    .sort();

  for (const file of files) {
    const applied = await db.query(
      "SELECT 1 FROM schema_migrations WHERE version = $1",
      [file]
    );

    if (applied.rowCount) continue;

    const sql = await readFile(resolve(migrationsDirectory(), file), "utf8");
    const client = await db.connect();

    try {
      await client.query("BEGIN");
      await client.query(sql);
      await client.query(
        "INSERT INTO schema_migrations(version) VALUES ($1)",
        [file]
      );
      await client.query("COMMIT");
      console.log(`Applied migration ${file}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}

export async function seedOpportunitiesIfEmpty(db: Database): Promise<number> {
  const countResult = await db.query<{ count: string }>(
    "SELECT COUNT(*)::text AS count FROM opportunities"
  );

  if (Number(countResult.rows[0]?.count ?? "0") > 0) {
    return 0;
  }

  const items = await new FileOpportunityRepository().list();

  for (const item of items) {
    await insertOpportunity(db, item);
  }

  console.log(`Seeded ${items.length} opportunities into PostgreSQL`);
  return items.length;
}

async function insertOpportunity(db: Database, item: Opportunity): Promise<void> {
  await db.query(
    `INSERT INTO opportunities
      (id, platform, title, prize_usd, deadline, eligibility, automation, score, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (id) DO NOTHING`,
    [
      item.id,
      item.platform,
      item.title,
      item.prizeUsd,
      item.deadline,
      item.eligibility,
      item.automation,
      item.score,
      item.status
    ]
  );
}
