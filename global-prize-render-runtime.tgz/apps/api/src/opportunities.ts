import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export type Opportunity = {
  id: string;
  platform: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  eligibility: string;
  automation: string;
  score: number;
  status: string;
};

type OpportunityFileRow = {
  id: string;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: string;
  eligibility: string;
  automation: string;
  score: number;
  status: string;
};

export type OpportunityRepository = {
  list(): Promise<Opportunity[]>;
  findById(id: string): Promise<Opportunity | undefined>;
};

function normalize(row: OpportunityFileRow): Opportunity {
  return {
    id: row.id,
    platform: row.platform,
    title: row.title,
    prizeUsd: row.prize_usd,
    deadline: row.deadline,
    eligibility: row.eligibility,
    automation: row.automation,
    score: row.score,
    status: row.status
  };
}

export class FileOpportunityRepository implements OpportunityRepository {
  constructor(private readonly filePath: string = defaultOpportunityFile()) {}

  private async readAll(): Promise<Opportunity[]> {
    const raw = await readFile(this.filePath, "utf8");
    const rows = JSON.parse(raw) as OpportunityFileRow[];
    return rows.map(normalize);
  }

  async list(): Promise<Opportunity[]> {
    const items = await this.readAll();
    return items.sort((a, b) => b.score - a.score);
  }

  async findById(id: string): Promise<Opportunity | undefined> {
    const items = await this.readAll();
    return items.find((item) => item.id === id);
  }
}

export function defaultOpportunityFile(): string {
  if (process.env.OPPORTUNITIES_FILE) {
    return resolve(process.env.OPPORTUNITIES_FILE);
  }

  const here = dirname(fileURLToPath(import.meta.url));
  return resolve(here, "../../../data/opportunities.json");
}
