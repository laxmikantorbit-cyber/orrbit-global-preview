import assert from "node:assert/strict";
import test from "node:test";
import { buildPortfolioReport, buildResultsSummary } from "./analytics.js";
import type { Opportunity } from "./opportunities.js";
import type { SubmissionItem } from "./submissions.js";

const submissions: SubmissionItem[] = [
  {
    id: "draft",
    opportunityId: "opp-a",
    researchProjectId: "r-a",
    title: "Draft",
    platform: "PATROLL",
    status: "draft",
    deadline: "2026-10-10",
    submittedAt: null,
    resultStatus: null,
    awardUsd: null,
    externalReference: null,
    notes: ""
  },
  {
    id: "won",
    opportunityId: "opp-b",
    researchProjectId: "r-b",
    title: "Won",
    platform: "Wazoku",
    status: "result",
    deadline: "2026-10-12",
    submittedAt: "2026-10-01T00:00:00Z",
    resultStatus: "won",
    awardUsd: 25000,
    externalReference: "ref-1",
    notes: ""
  },
  {
    id: "lost",
    opportunityId: "opp-c",
    researchProjectId: "r-c",
    title: "Lost",
    platform: "Wazoku",
    status: "result",
    deadline: "2026-10-19",
    submittedAt: "2026-10-02T00:00:00Z",
    resultStatus: "lost",
    awardUsd: null,
    externalReference: "ref-2",
    notes: ""
  }
];

const opportunities: Opportunity[] = [
  {
    id: "opp-a",
    platform: "PATROLL",
    title: "A",
    prizeUsd: 2000,
    deadline: "2026-10-10",
    eligibility: "Open",
    automation: "Allowed",
    score: 90,
    status: "researching"
  },
  {
    id: "opp-b",
    platform: "Wazoku",
    title: "B",
    prizeUsd: 25000,
    deadline: "2026-10-12",
    eligibility: "Open",
    automation: "Review",
    score: 70,
    status: "submitted"
  }
];

test("results count only recorded awards as earnings", () => {
  const summary = buildResultsSummary(submissions);

  assert.equal(summary.trackedSubmissions, 3);
  assert.equal(summary.submitted, 2);
  assert.equal(summary.resolved, 2);
  assert.equal(summary.wins, 1);
  assert.equal(summary.losses, 1);
  assert.equal(summary.awardedUsd, 25000);
  assert.equal(summary.winRatePercent, 50);
});

test("portfolio report keeps visible prize pool separate from awards", () => {
  const report = buildPortfolioReport(
    opportunities,
    submissions,
    new Date("2026-09-23T09:00:00Z")
  );

  assert.equal(report.totalVisiblePrizeUsd, 27000);
  assert.equal(report.results.awardedUsd, 25000);
  assert.equal(report.totalOpportunities, 2);

  const wazoku = report.platforms.find((item) => item.platform === "Wazoku");
  assert.equal(wazoku?.visiblePrizeUsd, 25000);
  assert.equal(wazoku?.awardedUsd, 25000);
});
