import assert from "node:assert/strict";
import test from "node:test";
import { assessSubmissionReadiness } from "./submission-readiness.js";
import type { Opportunity } from "./opportunities.js";
import type { ResearchExecutionAssessment } from "./research-execution.js";
import type { SubmissionItem } from "./submissions.js";

const opportunity: Opportunity = {
  id: "opp-1",
  platform: "PATROLL",
  title: "Test opportunity",
  prizeUsd: 2000,
  deadline: "2026-10-10",
  eligibility: "Account required; eligibility must be verified",
  automation: "AI-assisted work; review platform rules",
  score: 90,
  status: "researching"
};

const submission: SubmissionItem = {
  id: "sub-1",
  opportunityId: "opp-1",
  researchProjectId: "research-1",
  title: "Submission draft",
  platform: "PATROLL",
  status: "draft",
  deadline: "2026-10-10",
  submittedAt: null,
  resultStatus: null,
  awardUsd: null,
  externalReference: null,
  notes: "Internal draft"
};

const researchReady: ResearchExecutionAssessment = {
  projectId: "research-1",
  readinessScore: 95,
  readinessStatus: "submission-ready",
  limitationCoveragePercent: 100,
  evidenceVerificationPercent: 90,
  sourceTraceabilityPercent: 100,
  totalLimitations: 8,
  openProofGaps: 0,
  totalEvidence: 4,
  verifiedEvidence: 4,
  blockingIssueCount: 0,
  issues: [],
  nextActions: [],
  formula: "test"
};

test("readiness remains review-required when eligibility/rules need explicit review", () => {
  const result = assessSubmissionReadiness(
    submission,
    opportunity,
    researchReady,
    new Date("2026-09-23T09:00:00Z")
  );

  assert.equal(result.state, "review-required");
  assert.equal(result.deadlineState, "near");
  assert.equal(result.eligibilityReviewRequired, true);
  assert.equal(result.automationReviewRequired, true);
  assert.equal(result.issues.filter((x) => x.severity === "blocking").length, 0);
});

test("research blockers keep a draft blocked", () => {
  const blockedResearch: ResearchExecutionAssessment = {
    ...researchReady,
    readinessScore: 40,
    readinessStatus: "blocked",
    blockingIssueCount: 2
  };

  const result = assessSubmissionReadiness(
    submission,
    { ...opportunity, eligibility: "Open worldwide", automation: "AI-assisted permitted" },
    blockedResearch,
    new Date("2026-09-23T09:00:00Z")
  );

  assert.equal(result.state, "blocked");
  assert.ok(result.issues.some((x) => x.code === "research-not-ready"));
});

test("submitted state is never downgraded to ready", () => {
  const result = assessSubmissionReadiness(
    {
      ...submission,
      status: "submitted",
      submittedAt: "2026-09-23T10:00:00Z"
    },
    opportunity,
    researchReady,
    new Date("2026-09-23T11:00:00Z")
  );

  assert.equal(result.state, "already-submitted");
  assert.equal(result.score, 100);
});

test("expired deadlines block unsubmitted drafts", () => {
  const result = assessSubmissionReadiness(
    submission,
    { ...opportunity, eligibility: "Open worldwide", automation: "AI-assisted permitted" },
    researchReady,
    new Date("2026-10-12T00:00:00Z")
  );

  assert.equal(result.state, "blocked");
  assert.equal(result.deadlineState, "overdue");
  assert.ok(result.issues.some((x) => x.code === "deadline-overdue"));
});
