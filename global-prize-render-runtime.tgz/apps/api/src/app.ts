import type { IncomingMessage, ServerResponse } from "node:http";
import { EmptyAutomationRepository, type AutomationRepository } from "./automation.js";
import { EmptyBackupRepository, type BackupRepository } from "./backup.js";
import { DisabledAuthService, type AuthService } from "./auth.js";
import { buildPortfolioReport, buildResultsSummary } from "./analytics.js";
import { assessOpportunity } from "./opportunity-assessment.js";
import { assessResearchExecution } from "./research-execution.js";
import { assessSubmissionReadiness } from "./submission-readiness.js";
import { FileOpportunityRepository, type OpportunityRepository } from "./opportunities.js";
import { EmptyResearchRepository, type ResearchRepository } from "./research.js";
import { EmptySubmissionRepository, type SubmissionRepository } from "./submissions.js";
import {
  EmptyScannerRepository,
  type ScannerRepository,
  type VerifiedOpportunityInput
} from "./scanner.js";

export type HealthPayload = {
  service: "global-prize-api";
  status: "ok";
  version: string;
  environment: string;
  timestamp: string;
};

function sendJson(res: ServerResponse, statusCode: number, payload: unknown): void {
  res.statusCode = statusCode;
  res.setHeader("content-type", "application/json; charset=utf-8");
  res.setHeader("cache-control", "no-store");
  res.end(JSON.stringify(payload));
}

const sessionCookieName = "gpre_session";

function cookieValue(req: IncomingMessage, name: string): string | undefined {
  const header = req.headers.cookie;
  if (!header) return undefined;

  for (const part of header.split(";")) {
    const [rawName, ...rest] = part.trim().split("=");
    if (rawName === name) {
      return decodeURIComponent(rest.join("="));
    }
  }

  return undefined;
}

function sessionCookie(token: string, maxAgeSeconds: number, secure: boolean): string {
  const parts = [
    `${sessionCookieName}=${encodeURIComponent(token)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${maxAgeSeconds}`
  ];

  if (secure) parts.push("Secure");
  return parts.join("; ");
}

function clearSessionCookie(secure: boolean): string {
  const parts = [
    `${sessionCookieName}=`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    "Max-Age=0"
  ];

  if (secure) parts.push("Secure");
  return parts.join("; ");
}

async function readJsonBody(
  req: IncomingMessage,
  maxBytes = 16_384
): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  let total = 0;

  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += buffer.length;
    if (total > maxBytes) {
      throw new Error("request_body_too_large");
    }
    chunks.push(buffer);
  }

  if (chunks.length === 0) return {};

  const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("invalid_json_body");
  }

  return parsed as Record<string, unknown>;
}

function scannerInputFromBody(body: Record<string, unknown>): VerifiedOpportunityInput {
  return {
    sourceId: typeof body.sourceId === "string" ? body.sourceId : "",
    externalKey: typeof body.externalKey === "string" ? body.externalKey : "",
    canonicalOpportunityId:
      typeof body.canonicalOpportunityId === "string" && body.canonicalOpportunityId.trim()
        ? body.canonicalOpportunityId
        : undefined,
    platform: typeof body.platform === "string" ? body.platform : "",
    title: typeof body.title === "string" ? body.title : "",
    prizeUsd: typeof body.prizeUsd === "number" ? body.prizeUsd : Number.NaN,
    deadline: typeof body.deadline === "string" ? body.deadline : "",
    eligibility: typeof body.eligibility === "string" ? body.eligibility : "",
    automation: typeof body.automation === "string" ? body.automation : "",
    status: typeof body.status === "string" ? body.status : "",
    sourceUrl: typeof body.sourceUrl === "string" ? body.sourceUrl : "",
    verificationStatus:
      body.verificationStatus === "verified" || body.verificationStatus === "source-observed"
        ? body.verificationStatus
        : "source-observed"
  };
}

export function createRequestHandler(
  version = "0.1.0",
  opportunities: OpportunityRepository = new FileOpportunityRepository(),
  research: ResearchRepository = new EmptyResearchRepository(),
  submissions: SubmissionRepository = new EmptySubmissionRepository(),
  automation: AutomationRepository = new EmptyAutomationRepository(),
  backups: BackupRepository = new EmptyBackupRepository(),
  scanner: ScannerRepository = new EmptyScannerRepository(),
  auth: AuthService = new DisabledAuthService()
) {
  return async function handler(req: IncomingMessage, res: ServerResponse): Promise<void> {
    try {
      const url = new URL(req.url ?? "/", "http://localhost");

      if (req.method === "GET" && url.pathname === "/health") {
        const payload: HealthPayload = {
          service: "global-prize-api",
          status: "ok",
          version,
          environment: process.env.NODE_ENV ?? "development",
          timestamp: new Date().toISOString()
        };
        sendJson(res, 200, payload);
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/auth/session") {
        const session = await auth.getSession(cookieValue(req, sessionCookieName));
        sendJson(res, 200, session);
        return;
      }

      if (req.method === "POST" && url.pathname === "/api/auth/login") {
        let body: Record<string, unknown>;

        try {
          body = await readJsonBody(req);
        } catch {
          sendJson(res, 400, { error: "invalid_request_body" });
          return;
        }

        const ownerLogin = typeof body.ownerLogin === "string" ? body.ownerLogin : "";
        const password = typeof body.password === "string" ? body.password : "";

        if (!ownerLogin || !password) {
          sendJson(res, 400, { error: "missing_credentials" });
          return;
        }

        const result = await auth.login(ownerLogin, password);
        if (!result) {
          sendJson(res, 401, { error: "invalid_credentials" });
          return;
        }

        res.setHeader(
          "set-cookie",
          sessionCookie(result.token, result.maxAgeSeconds, auth.secureCookie)
        );
        sendJson(res, 200, {
          authenticated: true,
          ownerLogin: result.ownerLogin,
          expiresAt: result.expiresAt
        });
        return;
      }

      if (req.method === "POST" && url.pathname === "/api/auth/logout") {
        const token = cookieValue(req, sessionCookieName);
        await auth.logout(token);
        res.setHeader("set-cookie", clearSessionCookie(auth.secureCookie));
        sendJson(res, 200, { authenticated: false });
        return;
      }

      if (url.pathname.startsWith("/api") && auth.enabled) {
        const session = await auth.getSession(cookieValue(req, sessionCookieName));
        if (!session.authenticated) {
          sendJson(res, 401, { error: "authentication_required" });
          return;
        }
      }

      if (req.method === "GET" && url.pathname === "/api") {
        sendJson(res, 200, {
          name: "Global Prize Research Engine API",
          version,
          docs: "Self-hostable API foundation",
          health: "/health",
          opportunities: "/api/opportunities",
          researchProjects: "/api/research/projects",
          submissions: "/api/submissions",
          automationJobs: "/api/automation/jobs",
          automationRuns: "/api/automation/runs",
          backups: "/api/backups",
          latestBackup: "/api/backups/latest",
          scannerSources: "/api/scanner/sources",
          scannerObservations: "/api/scanner/observations",
          scannerIngest: "/api/scanner/ingest",
          resultsSummary: "/api/results/summary",
          portfolioReport: "/api/reports/portfolio"
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/results/summary") {
        const items = await submissions.list();
        sendJson(res, 200, buildResultsSummary(items));
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/reports/portfolio") {
        const [opportunityItems, submissionItems] = await Promise.all([
          opportunities.list(),
          submissions.list()
        ]);
        sendJson(res, 200, buildPortfolioReport(opportunityItems, submissionItems));
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/scanner/sources") {
        const items = await scanner.listSources();
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/scanner/observations") {
        const requested = Number(url.searchParams.get("limit") ?? "50");
        const limit = Number.isFinite(requested) ? requested : 50;
        const items = await scanner.listObservations(limit);
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "POST" && url.pathname === "/api/scanner/ingest") {
        let body: Record<string, unknown>;

        try {
          body = await readJsonBody(req, 64_000);
          const result = await scanner.ingest(scannerInputFromBody(body));
          sendJson(res, result.action === "created" ? 201 : 200, result);
        } catch (error) {
          const message = error instanceof Error ? error.message : "scanner_ingest_rejected";
          sendJson(res, 400, {
            error: "scanner_ingest_rejected",
            reason: message
          });
        }
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/opportunities") {
        const items = await opportunities.list();
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname.startsWith("/api/opportunities/")) {
        const tail = url.pathname.slice("/api/opportunities/".length);
        const [encodedId, child, ...rest] = tail.split("/");

        if (!encodedId || rest.length > 0) {
          sendJson(res, 404, {
            error: "not_found",
            path: url.pathname
          });
          return;
        }

        const id = decodeURIComponent(encodedId);
        const item = await opportunities.findById(id);

        if (!item) {
          sendJson(res, 404, {
            error: "opportunity_not_found",
            id
          });
          return;
        }

        if (!child) {
          sendJson(res, 200, item);
          return;
        }

        if (child === "assessment") {
          sendJson(res, 200, assessOpportunity(item));
          return;
        }

        sendJson(res, 404, {
          error: "not_found",
          path: url.pathname
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/submissions") {
        const items = await submissions.list();
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname.startsWith("/api/submissions/")) {
        const tail = url.pathname.slice("/api/submissions/".length);
        const [encodedId, child, ...rest] = tail.split("/");

        if (!encodedId || rest.length > 0) {
          sendJson(res, 404, {
            error: "not_found",
            path: url.pathname
          });
          return;
        }

        const id = decodeURIComponent(encodedId);
        const item = await submissions.findById(id);

        if (!item) {
          sendJson(res, 404, {
            error: "submission_not_found",
            id
          });
          return;
        }

        if (!child) {
          sendJson(res, 200, item);
          return;
        }

        if (child === "readiness") {
          const opportunity = await opportunities.findById(item.opportunityId);
          if (!opportunity) {
            sendJson(res, 409, {
              error: "submission_opportunity_missing",
              opportunityId: item.opportunityId
            });
            return;
          }

          let researchAssessment = null;
          if (item.researchProjectId) {
            const project = await research.findProjectById(item.researchProjectId);
            if (project) {
              const [limitations, evidence] = await Promise.all([
                research.listLimitations(project.id),
                research.listEvidence(project.id)
              ]);
              researchAssessment = assessResearchExecution(project, limitations, evidence);
            }
          }

          sendJson(
            res,
            200,
            assessSubmissionReadiness(item, opportunity, researchAssessment)
          );
          return;
        }

        sendJson(res, 404, {
          error: "not_found",
          path: url.pathname
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/automation/jobs") {
        const items = await automation.listJobs();
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/automation/runs") {
        const requested = Number(url.searchParams.get("limit") ?? "20");
        const limit = Number.isFinite(requested) ? requested : 20;
        const items = await automation.listRuns(limit);
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/backups") {
        const requested = Number(url.searchParams.get("limit") ?? "20");
        const limit = Number.isFinite(requested) ? requested : 20;
        const items = await backups.list(limit);
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/backups/latest") {
        const item = await backups.latest();
        sendJson(res, 200, {
          item: item ?? null
        });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/research/projects") {
        const items = await research.listProjects();
        sendJson(res, 200, {
          count: items.length,
          items
        });
        return;
      }

      if (req.method === "GET" && url.pathname.startsWith("/api/research/projects/")) {
        const tail = url.pathname.slice("/api/research/projects/".length);
        const [encodedId, child, ...rest] = tail.split("/");

        if (!encodedId || rest.length > 0) {
          sendJson(res, 404, {
            error: "not_found",
            path: url.pathname
          });
          return;
        }

        const id = decodeURIComponent(encodedId);
        const project = await research.findProjectById(id);

        if (!project) {
          sendJson(res, 404, {
            error: "research_project_not_found",
            id
          });
          return;
        }

        if (!child) {
          sendJson(res, 200, project);
          return;
        }

        if (child === "execution") {
          const [limitations, evidence] = await Promise.all([
            research.listLimitations(id),
            research.listEvidence(id)
          ]);
          sendJson(res, 200, assessResearchExecution(project, limitations, evidence));
          return;
        }

        if (child === "limitations") {
          const items = await research.listLimitations(id);
          sendJson(res, 200, {
            projectId: id,
            count: items.length,
            items
          });
          return;
        }

        if (child === "evidence") {
          const items = await research.listEvidence(id);
          sendJson(res, 200, {
            projectId: id,
            count: items.length,
            items
          });
          return;
        }

        sendJson(res, 404, {
          error: "not_found",
          path: url.pathname
        });
        return;
      }

      sendJson(res, 404, {
        error: "not_found",
        path: url.pathname
      });
    } catch (error) {
      console.error("API request failed", error);
      sendJson(res, 500, {
        error: "internal_error"
      });
    }
  };
}
