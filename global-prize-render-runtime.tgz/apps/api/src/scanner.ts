import { createHash } from "node:crypto";
import type { Database } from "./database.js";

export type OpportunitySource = {
  id: string;
  name: string;
  platform: string;
  sourceUrl: string;
  adapterType: string;
  enabled: boolean;
  scanIntervalMinutes: number;
  lastStartedAt: string | null;
  lastFinishedAt: string | null;
  nextScanAt: string;
  lastStatus: string | null;
  lastMessage: string | null;
};

export type OpportunityObservation = {
  id: number;
  sourceId: string;
  externalKey: string;
  canonicalOpportunityId: string | null;
  observedAt: string;
  snapshotHash: string;
  isNew: boolean;
  changedFields: string[];
  payload: Record<string, unknown>;
};

export type VerifiedOpportunityInput = {
  sourceId: string;
  externalKey: string;
  canonicalOpportunityId?: string;
  platform: string;
  title: string;
  prizeUsd: number;
  deadline: string;
  eligibility: string;
  automation: string;
  status: string;
  sourceUrl: string;
  verificationStatus?: "verified" | "source-observed";
};

export type IngestionResult = {
  canonicalOpportunityId: string;
  action: "created" | "updated" | "unchanged";
  changedFields: string[];
  snapshotHash: string;
};

export type ScannerRepository = {
  listSources(): Promise<OpportunitySource[]>;
  listObservations(limit?: number): Promise<OpportunityObservation[]>;
  ingest(input: VerifiedOpportunityInput): Promise<IngestionResult>;
};

type SourceRow = {
  id: string;
  name: string;
  platform: string;
  source_url: string;
  adapter_type: string;
  enabled: boolean;
  scan_interval_minutes: number;
  last_started_at: Date | string | null;
  last_finished_at: Date | string | null;
  next_scan_at: Date | string;
  last_status: string | null;
  last_message: string | null;
};

type ObservationRow = {
  id: number | string;
  source_id: string;
  external_key: string;
  canonical_opportunity_id: string | null;
  observed_at: Date | string;
  snapshot_hash: string;
  is_new: boolean;
  changed_fields: unknown;
  payload: Record<string, unknown>;
};

type ExistingOpportunityRow = {
  id: string;
  source_id: string | null;
  external_key: string | null;
  platform: string;
  title: string;
  prize_usd: number;
  deadline: Date | string;
  eligibility: string;
  automation: string;
  status: string;
  source_status: string | null;
  source_url: string | null;
  source_hash: string | null;
};

function iso(value: Date | string | null): string | null {
  if (value === null) return null;
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function dateOnly(value: Date | string): string {
  return value instanceof Date
    ? value.toISOString().slice(0, 10)
    : String(value).slice(0, 10);
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : [];
}

function stableSnapshot(input: VerifiedOpportunityInput): Record<string, unknown> {
  return {
    sourceId: input.sourceId,
    externalKey: input.externalKey,
    platform: input.platform.trim(),
    title: input.title.trim(),
    prizeUsd: Math.trunc(input.prizeUsd),
    deadline: input.deadline,
    eligibility: input.eligibility.trim(),
    automation: input.automation.trim(),
    status: input.status.trim(),
    sourceUrl: input.sourceUrl.trim(),
    verificationStatus: input.verificationStatus ?? "source-observed"
  };
}

function snapshotHash(payload: Record<string, unknown>): string {
  return createHash("sha256").update(JSON.stringify(payload)).digest("hex");
}

function canonicalId(sourceId: string, externalKey: string): string {
  const digest = createHash("sha256")
    .update(sourceId + ":" + externalKey)
    .digest("hex")
    .slice(0, 14);
  return "scan-" + sourceId.replace(/[^a-z0-9-]+/gi, "-").toLowerCase() + "-" + digest;
}

function changedFields(
  current: ExistingOpportunityRow,
  input: VerifiedOpportunityInput
): string[] {
  const changes: string[] = [];

  if (current.platform !== input.platform) changes.push("platform");
  if (current.title !== input.title) changes.push("title");
  if (Number(current.prize_usd) !== Math.trunc(input.prizeUsd)) changes.push("prizeUsd");
  if (dateOnly(current.deadline) !== input.deadline) changes.push("deadline");
  if (current.eligibility !== input.eligibility) changes.push("eligibility");
  if (current.automation !== input.automation) changes.push("automation");
  if ((current.source_status ?? "") !== input.status) changes.push("sourceStatus");
  if ((current.source_url ?? "") !== input.sourceUrl) changes.push("sourceUrl");

  return changes;
}

function mapSource(row: SourceRow): OpportunitySource {
  return {
    id: row.id,
    name: row.name,
    platform: row.platform,
    sourceUrl: row.source_url,
    adapterType: row.adapter_type,
    enabled: row.enabled,
    scanIntervalMinutes: row.scan_interval_minutes,
    lastStartedAt: iso(row.last_started_at),
    lastFinishedAt: iso(row.last_finished_at),
    nextScanAt: iso(row.next_scan_at) ?? new Date(0).toISOString(),
    lastStatus: row.last_status,
    lastMessage: row.last_message
  };
}

function mapObservation(row: ObservationRow): OpportunityObservation {
  return {
    id: Number(row.id),
    sourceId: row.source_id,
    externalKey: row.external_key,
    canonicalOpportunityId: row.canonical_opportunity_id,
    observedAt: iso(row.observed_at) ?? new Date(0).toISOString(),
    snapshotHash: row.snapshot_hash,
    isNew: row.is_new,
    changedFields: stringArray(row.changed_fields),
    payload: row.payload ?? {}
  };
}

export class PostgresScannerRepository implements ScannerRepository {
  constructor(private readonly db: Database) {}

  async listSources(): Promise<OpportunitySource[]> {
    const result = await this.db.query<SourceRow>(
      "SELECT id,name,platform,source_url,adapter_type,enabled,scan_interval_minutes,last_started_at,last_finished_at,next_scan_at,last_status,last_message FROM opportunity_sources ORDER BY enabled DESC,name ASC"
    );

    return result.rows.map(mapSource);
  }

  async listObservations(limit = 50): Promise<OpportunityObservation[]> {
    const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 200);
    const result = await this.db.query<ObservationRow>(
      "SELECT id,source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload FROM opportunity_observations ORDER BY observed_at DESC,id DESC LIMIT $1",
      [safeLimit]
    );

    return result.rows.map(mapObservation);
  }

  async ingest(input: VerifiedOpportunityInput): Promise<IngestionResult> {
    validateInput(input);

    const payload = stableSnapshot(input);
    const hash = snapshotHash(payload);
    const client = await this.db.connect();

    try {
      await client.query("BEGIN");

      const source = await client.query(
        "SELECT 1 FROM opportunity_sources WHERE id = $1 AND enabled = TRUE",
        [input.sourceId]
      );

      if (!source.rowCount) {
        throw new Error("scanner_source_not_found_or_disabled");
      }

      const existingResult = await client.query<ExistingOpportunityRow>(
        "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,status,source_status,source_url,source_hash FROM opportunities WHERE source_id = $1 AND external_key = $2 LIMIT 1 FOR UPDATE",
        [input.sourceId, input.externalKey]
      );

      let current = existingResult.rows[0];

      if (!current && input.canonicalOpportunityId) {
        const linkedResult = await client.query<ExistingOpportunityRow>(
          "SELECT id,source_id,external_key,platform,title,prize_usd,deadline,eligibility,automation,status,source_status,source_url,source_hash FROM opportunities WHERE id = $1 LIMIT 1 FOR UPDATE",
          [input.canonicalOpportunityId]
        );

        current = linkedResult.rows[0];

        if (!current) {
          throw new Error("scanner_canonical_opportunity_not_found");
        }

        if (
          current.source_id &&
          (current.source_id !== input.sourceId || current.external_key !== input.externalKey)
        ) {
          throw new Error("scanner_canonical_opportunity_already_linked");
        }
      }

      const observedAt = new Date();
      let opportunityId: string;
      let action: IngestionResult["action"];
      let changes: string[];

      if (!current) {
        opportunityId = canonicalId(input.sourceId, input.externalKey);
        action = "created";
        changes = [
          "platform",
          "title",
          "prizeUsd",
          "deadline",
          "eligibility",
          "automation",
          "sourceStatus",
          "sourceUrl"
        ];

        await client.query(
          "INSERT INTO opportunities (id,platform,title,prize_usd,deadline,eligibility,automation,score,status,source_status,source_id,external_key,source_url,first_seen_at,last_seen_at,source_hash,source_observed_at,verification_status) VALUES ($1,$2,$3,$4,$5,$6,$7,50,'triage',$8,$9,$10,$11,$12,$12,$13,$12,$14)",
          [
            opportunityId,
            input.platform,
            input.title,
            Math.trunc(input.prizeUsd),
            input.deadline,
            input.eligibility,
            input.automation,
            input.status,
            input.sourceId,
            input.externalKey,
            input.sourceUrl,
            observedAt,
            hash,
            input.verificationStatus ?? "source-observed"
          ]
        );
      } else {
        opportunityId = current.id;
        changes = changedFields(current, input);

        if (!current.source_id || !current.external_key) {
          changes.unshift("sourceLink");
        }

        action = changes.length > 0 ? "updated" : "unchanged";

        await client.query(
          "UPDATE opportunities SET source_id=$2,external_key=$3,platform=$4,title=$5,prize_usd=$6,deadline=$7,eligibility=$8,automation=$9,source_status=$10,source_url=$11,last_seen_at=$12,source_hash=$13,source_observed_at=$12,verification_status=$14,updated_at=CASE WHEN $15::boolean THEN NOW() ELSE updated_at END WHERE id=$1",
          [
            opportunityId,
            input.sourceId,
            input.externalKey,
            input.platform,
            input.title,
            Math.trunc(input.prizeUsd),
            input.deadline,
            input.eligibility,
            input.automation,
            input.status,
            input.sourceUrl,
            observedAt,
            hash,
            input.verificationStatus ?? "source-observed",
            changes.length > 0
          ]
        );
      }

      await client.query(
        "INSERT INTO opportunity_observations (source_id,external_key,canonical_opportunity_id,observed_at,snapshot_hash,is_new,changed_fields,payload) VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb) ON CONFLICT (source_id,external_key,snapshot_hash) DO NOTHING",
        [
          input.sourceId,
          input.externalKey,
          opportunityId,
          observedAt,
          hash,
          action === "created",
          JSON.stringify(changes),
          JSON.stringify(payload)
        ]
      );

      await client.query("COMMIT");

      return {
        canonicalOpportunityId: opportunityId,
        action,
        changedFields: changes,
        snapshotHash: hash
      };
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}

export class EmptyScannerRepository implements ScannerRepository {
  async listSources(): Promise<OpportunitySource[]> {
    return [];
  }

  async listObservations(): Promise<OpportunityObservation[]> {
    return [];
  }

  async ingest(): Promise<IngestionResult> {
    throw new Error("scanner_unavailable");
  }
}

function validateInput(input: VerifiedOpportunityInput): void {
  if (!input.sourceId.trim()) throw new Error("source_id_required");
  if (!input.externalKey.trim()) throw new Error("external_key_required");
  if (!input.platform.trim()) throw new Error("platform_required");
  if (!input.title.trim()) throw new Error("title_required");
  if (!Number.isFinite(input.prizeUsd) || input.prizeUsd < 0) throw new Error("invalid_prize");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.deadline)) throw new Error("invalid_deadline");
  if (!input.status.trim()) throw new Error("status_required");

  try {
    const url = new URL(input.sourceUrl);
    if (!["http:", "https:"].includes(url.protocol)) throw new Error();
  } catch {
    throw new Error("invalid_source_url");
  }
}
